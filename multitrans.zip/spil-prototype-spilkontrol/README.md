# spil-prototype-spilkontrol README

To start the application in development mode, import it into your IDE and run the `Application` class. 
You can also start the application from the command line by running: 

```bash
./mvnw
```

To build the application in production mode, run:

```bash
./mvnw -Pproduction package
```

## Getting Started

# Business and code description

This demonstrates a layered transactional architecture with multiple transaction boundaries.

## Configuration 

The code uses plain JDBC in combination with Spring transaction management and Vaadin for the UI 

Insert the following line in application.properties:
```
spring.datasource.hikari.auto-commit=true
```

Application is configured with rollback on all exceptions:
```
@Configuration
@EnableTransactionManagement(rollbackOn=ALL_EXCEPTIONS)
public class AppConfiguration {
}
```

There are three repositories handling the layered transaction boundaries:
```
@Repository
public class ZIPFileRepository

@Repository
public class XMLFileRepository

@Repository
public class XMLFileGameRepository
```

The entry point for handling each ZIP file is at:
```
public class ZIPFileQueueRepository [
...
@Transactional
public void updateZIPFileMultiTransCommit(Integer zipFileId, int COMMIT_BLOCK_MAX_SIZE ) throws SQLException {
```
the next two trancaction boundaries are:
```

public class TalspilTransStdRecordRepository {
...
@Transactional(propagation = Propagation.REQUIRES_NEW)
public boolean processXMLFilesList(XMLFile xmlFile, Integer COMMIT_BLOCK_MAX_SIZE) throws SQLException {
```
and
```
public class XMLFileGameRepository {
...
@Transactional(propagation = Propagation.REQUIRES_NEW)
public Integer processXMLFileGameList(List<XMLFileGame> gameList, Integer counterStart, Integer COMMIT_BLOCK_MAX_SIZE) throws SQLException {
```

## Database schema
There are two schema files that must be set up to have a correct database
 - resources/schema.sql
 - resources/schema-basic-trans.sql
  
Also there are two files with initial demo data
 - resources/data.sql
 - resources/data-basic-trans.sql
 
## XML and XSD files
The XSD files are part of the application resources in
 - resources/xsd/Monopol 
And the following property in application.properties points to the XSD files
 - xsd.root.dir = src/main/resources/xsd/Monopol

During production the XML files are coming in from external sources as a ZIP archive and saved to be locally accessible from the application.
It is assumed that the ZIP file will be unpacked into all the individual files following the directory structure in the ZIP file. 
Hence, the XML files are externalized in a root directory for this application to be close to production.
And the following property in application.properties points to the XML files
 - xml.root.dir = C:/SPM/projects/mf/spil-prototype-spilkontrol/xml


