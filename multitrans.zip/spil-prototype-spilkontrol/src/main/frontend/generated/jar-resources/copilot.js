import { ax as a, aw as i } from "./copilot/copilot-BLh5wx96.js";
export {
  a as _createChildrenDefinitions,
  i as _registerImporter
};
