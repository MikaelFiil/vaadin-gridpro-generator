package dk.skat.spilkontrol.business.model;

import lombok.Data;

@Data
public abstract class AbstractGameStandardRecord extends StandardRecord {
	
	private String spilKategoriNavn;
	private String spilProduktNavn = "";
	private String spilProduktIdentifikation;
	/** 
	 * TODO: it saves typeIdentifikation for all games, 
	 * because 'spilTypeIdentifikation' saves spilIdentifikation for Poker, Kasino and FastOdds (bug 21910) 
	 * */
	private String spilTypeIdentifikation2;
	

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AbstractGameStandardRecord [spilKategoriNavn=");
		builder.append(spilKategoriNavn);
		builder.append(", spilProduktNavn=");
		builder.append(spilProduktNavn);
		builder.append(", spilProduktIdentifikation=");
		builder.append(spilProduktIdentifikation);
		builder.append(", getSpilFilIdentifikation()=");
		builder.append(getSpilFilIdentifikation());
		builder.append(", getSpilFilErstatningIdentifikation()=");
		builder.append(getSpilFilErstatningIdentifikation());
		builder.append(", getSpilCertifikatIdentifikation()=");
		builder.append(getSpilCertifikatIdentifikation());
		builder.append(", getSafeIdentifikation()=");
		builder.append(getSafeIdentifikation());
		builder.append(", getStructureType()=");
		builder.append(getStructureType());
		builder.append("]");
		return builder.toString();
	}

	
	
}
