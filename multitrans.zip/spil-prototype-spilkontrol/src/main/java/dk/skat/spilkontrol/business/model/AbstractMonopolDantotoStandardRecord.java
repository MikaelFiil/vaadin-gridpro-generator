package dk.skat.spilkontrol.business.model;


import org.joda.time.DateTime;

import java.util.Stack;

public abstract class AbstractMonopolDantotoStandardRecord extends
		AbstractGameStandardRecord {

	private String eventIdentifikation;
	private String kategoriNavn;
	private String valutaOplysningKode;
	
	public String getEventIdentifikation() {
		return eventIdentifikation;
	}
	public void setEventIdentifikation(String eventIdentifikation) {
		this.eventIdentifikation = eventIdentifikation;
	}
	public String getKategoriNavn() {
		return kategoriNavn;
	}
	public void setKategoriNavn(String kategoriNavn) {
		this.kategoriNavn = kategoriNavn;
	}
	public String getValutaOplysningKode() {
		return valutaOplysningKode;
	}
	public void setValutaOplysningKode(String valutaOplysningKode) {
		this.valutaOplysningKode = valutaOplysningKode;
	}



	public static class GevinstkategorierOgGevinster {

		private String gevinstPuljeIdentifikation;
		private long gevinstPuljeAntalGevinsterTillIndh;
		private double gevinstPuljeBeloebTillIndh;
		private double gevinstPuljeBeloebPerRaekke;

		private double gevinstPuljeTilfoejetBeloeb;
		private Double gevinstPuljeOverfoerselPrimo;
		private Double gevinstPuljeOverfoerselUltimo;

		private Double gevinstPuljeGevinstProcent;
		private String gevinstPuljeBeskrivelse;
		private Double gevinstPuljeGaranti;

		public String getGevinstPuljeIdentifikation() {
			return gevinstPuljeIdentifikation;
		}
		public void setGevinstPuljeIdentifikation(String gevinstPuljeIdentifikation) {
			this.gevinstPuljeIdentifikation = gevinstPuljeIdentifikation;
		}
		public long getGevinstPuljeAntalGevinsterTillIndh() {
			return gevinstPuljeAntalGevinsterTillIndh;
		}
		public void setGevinstPuljeAntalGevinsterTillIndh(
				long gevinstPuljeAntalGevinsterTillIndh) {
			this.gevinstPuljeAntalGevinsterTillIndh = gevinstPuljeAntalGevinsterTillIndh;
		}
		public double getGevinstPuljeBeloebTillIndh() {
			return gevinstPuljeBeloebTillIndh;
		}
		public void setGevinstPuljeBeloebTillIndh(double gevinstPuljeBeloebTillIndh) {
			this.gevinstPuljeBeloebTillIndh = gevinstPuljeBeloebTillIndh;
		}
		public double getGevinstPuljeBeloebPerRaekke() {
			return gevinstPuljeBeloebPerRaekke;
		}
		public void setGevinstPuljeBeloebPerRaekke(double gevinstPuljeBeloebPerRaekke) {
			this.gevinstPuljeBeloebPerRaekke = gevinstPuljeBeloebPerRaekke;
		}
		public double getGevinstPuljeTilfoejetBeloeb() {
			return gevinstPuljeTilfoejetBeloeb;
		}
		public void setGevinstPuljeTilfoejetBeloeb(double gevinstPuljeTilfoejetBeloeb) {
			this.gevinstPuljeTilfoejetBeloeb = gevinstPuljeTilfoejetBeloeb;
		}
		public Double getGevinstPuljeOverfoerselPrimo() {
			return gevinstPuljeOverfoerselPrimo;
		}
		public void setGevinstPuljeOverfoerselPrimo(Double gevinstPuljeOverfoerselPrimo) {
			this.gevinstPuljeOverfoerselPrimo = gevinstPuljeOverfoerselPrimo;
		}
		public Double getGevinstPuljeOverfoerselUltimo() {
			return gevinstPuljeOverfoerselUltimo;
		}
		public void setGevinstPuljeOverfoerselUltimo(
				Double gevinstPuljeOverfoerselUltimo) {
			this.gevinstPuljeOverfoerselUltimo = gevinstPuljeOverfoerselUltimo;
		}

		public Double getGevinstPuljeGevinstProcent() {
			return gevinstPuljeGevinstProcent;
		}

		public void setGevinstPuljeGevinstProcent(Double gevinstPuljeGevinstProcent) {
			this.gevinstPuljeGevinstProcent = gevinstPuljeGevinstProcent;
		}

		public String getGevinstPuljeBeskrivelse() {
			return gevinstPuljeBeskrivelse;
		}

		public void setGevinstPuljeBeskrivelse(String gevinstPuljeBeskrivelse) {
			this.gevinstPuljeBeskrivelse = gevinstPuljeBeskrivelse;
		}

		public Double getGevinstPuljeGaranti() {
			return gevinstPuljeGaranti;
		}

		public void setGevinstPuljeGaranti(Double gevinstPuljeGaranti) {
			this.gevinstPuljeGaranti = gevinstPuljeGaranti;
		}
	}

	public static class ResultatGrundlag {

		private String puljespilVinderRaekke;

		public final String getPuljespilVinderRaekke() {
			return puljespilVinderRaekke;
		}

		public final void setPuljespilVinderRaekke(String puljespilVinderRaekke) {
			this.puljespilVinderRaekke = puljespilVinderRaekke;
		}
	}

	public static class UdgaaedeHeste {

		private Long puljespilNoegleNummer;

		private Long dantotoLoebNummer;

		/**
		 * tekst lang type, max 500 char
		 */
		private String udgaaedeHeste;

		public final Long getPuljespilNoegleNummer() {
			return puljespilNoegleNummer;
		}

		public final void setPuljespilNoegleNummer(Long puljespilNoegleNummer) {
			this.puljespilNoegleNummer = puljespilNoegleNummer;
		}

		public final Long getDantotoLoebNummer() {
			return dantotoLoebNummer;
		}

		public final void setDantotoLoebNummer(Long dantotoLoebNummer) {
			this.dantotoLoebNummer = dantotoLoebNummer;
		}

		public final String getUdgaaedeHeste() {
			return udgaaedeHeste;
		}

		public final void setUdgaaedeHeste(String udgaaedeHeste) {
			this.udgaaedeHeste = udgaaedeHeste;
		}
	}

	public static class Vinder {
		private String spillerInformationIdentifikation;
		private String spilTransaktionIdentifikation;
		private Long raekkeNummer;
		private double spilGevinstSpil;

		public final String getSpillerInformationIdentifikation() {
			return spillerInformationIdentifikation;
		}

		public final void setSpillerInformationIdentifikation(
				String spillerInformationIdentifikation) {
			this.spillerInformationIdentifikation = spillerInformationIdentifikation;
		}

		public final String getSpilTransaktionIdentifikation() {
			return spilTransaktionIdentifikation;
		}

		public final void setSpilTransaktionIdentifikation(String spillerIdentifikation) {
			this.spilTransaktionIdentifikation = spillerIdentifikation;
		}

		public final Long getRaekkeNummer() {
			return raekkeNummer;
		}

		public final void setRaekkeNummer(Long raekkeNummer) {
			this.raekkeNummer = raekkeNummer;
		}

		public final double getSpilGevinstSpil() {
			return spilGevinstSpil;
		}

		public final void setSpilGevinstSpil(double spilGevinstFraSpil) {
			this.spilGevinstSpil = spilGevinstFraSpil;
		}
	}

	public static class GevinstPulje {

		private String gevinstPuljeIdentifikation;
		private Double gevinstPuljeGevinstProcent;
		private String gevinstPuljeBeskrivelse;
		private Double gevinstPuljeGaranti;

		public final String getGevinstPuljeBeskrivelse() {
			return gevinstPuljeBeskrivelse;
		}

		public final void setGevinstPuljeBeskrivelse(String gevinstPuljeBeskrivelse) {
			this.gevinstPuljeBeskrivelse = gevinstPuljeBeskrivelse;
		}

		public final String getGevinstPuljeIdentifikation() {
			return gevinstPuljeIdentifikation;
		}

		public final void setGevinstPuljeIdentifikation(
				String gevinstPuljeIdentifikation) {
			this.gevinstPuljeIdentifikation = gevinstPuljeIdentifikation;
		}

		public final Double getGevinstPuljeGevinstProcent() {
			return gevinstPuljeGevinstProcent;
		}

		public final void setGevinstPuljeGevinstProcent(
				Double gevinstPuljeGevinstProcent) {
			this.gevinstPuljeGevinstProcent = gevinstPuljeGevinstProcent;
		}

		/**
		 * missing value is allowed. It will then return null.
		 *
		 * @return
		 */
		public final Double getGevinstPuljeGaranti() {
			return gevinstPuljeGaranti;
		}

		public final void setGevinstPuljeGaranti(Double gevinstPuljeGaranti) {
			this.gevinstPuljeGaranti = gevinstPuljeGaranti;
		}

	}

	public static class SpillerOgKuponType {

		private String spillerInformationIdentifikation;
		private String spilTransaktionIdentifikation;
		private DateTime spilKoebDatoTid;
		private String spilKoebDatoTidString;
		private String spilSalgskanal;
		private Long spilAntalRaekker;
		private Double spilIndskud;
		private Double spilIndskudSpil;

		private String dantotoKoponType;

		private String valutaOplysningKode;

		private String spilTerminalidentification;
		private String spilHjemmeside;

		private boolean spilAnnullering;
		private DateTime spilAnnulleringDatoTid;
		private String spilAnnulleringDatoTidString;

		private final Stack<Spilkombinationer> spilkombinationerListe = new Stack<Spilkombinationer>();

		private final Stack<ReservehesteManuelt> reserveHesteListe = new Stack<ReservehesteManuelt>();

		public String getSpillerInformationIdentifikation() {
			return spillerInformationIdentifikation;
		}

		public void setSpillerInformationIdentifikation(
				String spillerInformationIdentifikation) {
			this.spillerInformationIdentifikation = spillerInformationIdentifikation;
		}

		public String getSpilTransaktionIdentifikation() {
			return spilTransaktionIdentifikation;
		}

		public void setSpilTransaktionIdentifikation(
				String spilTransaktionIdentifikation) {
			this.spilTransaktionIdentifikation = spilTransaktionIdentifikation;
		}

		public DateTime getSpilKoebDatoTid() {
			return spilKoebDatoTid;
		}

		public void setSpilKoebDatoTid(DateTime spilKoebDatoTid) {
			this.spilKoebDatoTid = spilKoebDatoTid;
		}

		public String getSpilKoebDatoTidString() {
			return spilKoebDatoTidString;
		}

		public void setSpilKoebDatoTidString(String spilKoebDatoTidString) {
			this.spilKoebDatoTidString = spilKoebDatoTidString;
		}

		public String getSpilSalgskanal() {
			return spilSalgskanal;
		}

		public void setSpilSalgskanal(String spilSalgskanal) {
			this.spilSalgskanal = spilSalgskanal;
		}

		public Long getSpilAntalRaekker() {
			return spilAntalRaekker;
		}

		public void setSpilAntalRaekker(Long spilAntalRaekker) {
			this.spilAntalRaekker = spilAntalRaekker;
		}

		public Double getSpilIndskud() {
			return spilIndskud;
		}

		public void setSpilIndskud(Double spilIndskud) {
			this.spilIndskud = spilIndskud;
		}

		public Double getSpilIndskudSpil() {
			return spilIndskudSpil;
		}

		public void setSpilIndskudSpil(Double spilIndskudSpil) {
			this.spilIndskudSpil = spilIndskudSpil;
		}

		public String getDantotoKoponType() {
			return dantotoKoponType;
		}

		public void setDantotoKoponType(String dantotoKoponType) {
			this.dantotoKoponType = dantotoKoponType;
		}

		public String getValutaOplysningKode() {
			return valutaOplysningKode;
		}

		public void setValutaOplysningKode(String valutaOplysningKode) {
			this.valutaOplysningKode = valutaOplysningKode;
		}

		public String getSpilTerminalidentification() {
			return spilTerminalidentification;
		}

		public void setSpilTerminalidentification(String spilTerminalidentification) {
			this.spilTerminalidentification = spilTerminalidentification;
		}

		public String getSpilHjemmeside() {
			return spilHjemmeside;
		}

		public void setSpilHjemmeside(String spilHjemmeside) {
			this.spilHjemmeside = spilHjemmeside;
		}

		public boolean getSpilAnnullering() {
			return spilAnnullering;
		}

		public void setSpilAnnullering(boolean spilAnnullering) {
			this.spilAnnullering = spilAnnullering;
		}

		public DateTime getSpilAnnulleringDatoTid() {
			return spilAnnulleringDatoTid;
		}

		public void setSpilAnnulleringDatoTid(DateTime spilAnnulleringDatoTid) {
			this.spilAnnulleringDatoTid = spilAnnulleringDatoTid;
		}

		public String getSpilAnnulleringDatoTidString() {
			return spilAnnulleringDatoTidString;
		}

		public void setSpilAnnulleringDatoTidString(String spilAnnulleringDatoTidString) {
			this.spilAnnulleringDatoTidString = spilAnnulleringDatoTidString;
		}

		public Stack<Spilkombinationer> getSpilkombinationerListe() {
			return spilkombinationerListe;
		}

		public void addNewSpilkombinationer() {
			spilkombinationerListe.add(new Spilkombinationer());
		}

		public final Stack<ReservehesteManuelt> getReserveHesteListe() {
			return reserveHesteListe;
		}

		public void addNewReserveHesteManuelt() {
			reserveHesteListe.add(new ReservehesteManuelt());
		}

		public static class Spilkombinationer {

			private Long raekkeNummer;
			private String raekkeSpilkombinationer;

			public final Long getRaekkeNummer() {
				return raekkeNummer;
			}

			public final void setRaekkeNummer(Long raekkeNummer) {
				this.raekkeNummer = raekkeNummer;
			}

			public final String getRaekkeSpilkombinationer() {
				return raekkeSpilkombinationer;
			}

			public final void setRaekkeSpilkombinationer(String raekkeSpilkombinationer) {
				this.raekkeSpilkombinationer = raekkeSpilkombinationer;
			}
		}

		public static class ReservehesteManuelt {

			private Long puljespilNoegleNummer;

			private Long dantotoLoebNummer;

			/**
			 * tekst lang type, max 500 char
			 */
			private String reserveHesteManuelt;

			public final Long getPuljespilNoegleNummer() {
				return puljespilNoegleNummer;
			}

			public final void setPuljespilNoegleNummer(Long puljespilNoegleNummer) {
				this.puljespilNoegleNummer = puljespilNoegleNummer;
			}

			public final Long getDantotoLoebNummer() {
				return dantotoLoebNummer;
			}

			public final void setDantotoLoebNummer(Long dantotoLoebNummer) {
				this.dantotoLoebNummer = dantotoLoebNummer;
			}

			public final String getReserveHesteManuelt() {
				return reserveHesteManuelt;
			}

			public final void setReserveHesteManuelt(String reserveHesteManuelt) {
				this.reserveHesteManuelt = reserveHesteManuelt;
			}

		}
	}

	public static class GenerelSpilNoegle {

		private Long noegleNummer;
		private String noegleBeskrivelse;
		private String noegleValideTal;
		private Long loebNummer;
		private String dantotoReservehesteAutomatisk;

		public final Long getNoegleNummer() {
			return noegleNummer;
		}

		public final void setNoegleNummer(Long noegleNummer) {
			this.noegleNummer = noegleNummer;
		}

		public final String getNoegleBeskrivelse() {
			return noegleBeskrivelse;
		}

		public final void setNoegleBeskrivelse(String noegleBeskrivelse) {
			this.noegleBeskrivelse = noegleBeskrivelse;
		}

		public final String getNoegleValideTal() {
			return noegleValideTal;
		}

		public final void setNoegleValideTal(String noegleValideTal) {
			this.noegleValideTal = noegleValideTal;
		}

		public final Long getLoebNummer() {
			return loebNummer;
		}

		public final void setLoebNummer(Long loebNummer) {
			this.loebNummer = loebNummer;
		}

		public final String getDantotoReservehesteAutomatisk() {
			return dantotoReservehesteAutomatisk;
		}

		public final void setDantotoReservehesteAutomatisk(
				String dantotoReservehesteAutomatisk) {
			this.dantotoReservehesteAutomatisk = dantotoReservehesteAutomatisk;
		}

	}



	}
