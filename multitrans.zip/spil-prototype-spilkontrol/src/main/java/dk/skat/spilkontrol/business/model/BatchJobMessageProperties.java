package dk.skat.spilkontrol.business.model;

public enum BatchJobMessageProperties {
	BatchJobMessageType
}
