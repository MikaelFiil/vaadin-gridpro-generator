package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class EndOfDayStandardRecord extends StandardRecord {

	private DateTime endOfDateRapportDato;
	private String endOfDateRapportDatoString;
	private String valuta;
	private Stack<SpilOpgoerelseType> spilOpgoerelses = new Stack<SpilOpgoerelseType>();
	
	public Stack<SpilOpgoerelseType> getSpilOpgoerelses() {
		return this.spilOpgoerelses;
	}
	
	public SpilOpgoerelseType getLastSpilOpgoerelse() {
		return spilOpgoerelses.peek();
	}
	
	public SpilOpgoerelseType addSpilOpgoerelse(SpilOpgoerelseType spilOpgoerelse) {
		return spilOpgoerelses.push(spilOpgoerelse);
	}
	
	public DateTime getEndOfDateRapportDato() {
		return endOfDateRapportDato;
	}

	public void setEndOfDateRapportDato(DateTime endOfDateRapportDato) {
		this.endOfDateRapportDato = endOfDateRapportDato;
	}

	public final String getEndOfDateRapportDatoString() {
		return endOfDateRapportDatoString;
	}

	public final void setEndOfDateRapportDatoString(
			String endOfDateRapportDatoString) {
		this.endOfDateRapportDatoString = endOfDateRapportDatoString;
	}

	public String getValuta() {
		return valuta;
	}

	public void setValuta(String valuta) {
		this.valuta = valuta;
	}

	public class SpilOpgoerelseType {
		private String spilKategoryNavn;
		private Long endOfDayRapportAntalSpil;
		private Double endOfDayRapportIndskudSpil;
		private Double endOfDayRapportIndskudJackpot;
		private Double endOfDayRapportGevinster;
		private Double endOfDayRapportKommissionRake;
		
		public String getSpilKategoryNavn() {
			return spilKategoryNavn;
		}
		public void setSpilKategoryNavn(String spilKategoryNavn) {
			this.spilKategoryNavn = spilKategoryNavn;
		}
		public Long getEndOfDayRapportAntalSpil() {
			return endOfDayRapportAntalSpil;
		}
		public void setEndOfDayRapportAntalSpil(Long endOfDayRapportAntalSpil) {
			this.endOfDayRapportAntalSpil = endOfDayRapportAntalSpil;
		}
		public Double getEndOfDayRapportIndskudSpil() {
			return endOfDayRapportIndskudSpil;
		}
		public void setEndOfDayRapportIndskudSpil(Double endOfDayRapportIndskudSpil) {
			this.endOfDayRapportIndskudSpil = endOfDayRapportIndskudSpil;
		}
		public Double getEndOfDayRapportIndskudJackpot() {
			return endOfDayRapportIndskudJackpot;
		}
		public void setEndOfDayRapportIndskudJackpot(
				Double endOfDayRapportIndskudJackpot) {
			this.endOfDayRapportIndskudJackpot = endOfDayRapportIndskudJackpot;
		}
		public Double getEndOfDayRapportGevinster() {
			return endOfDayRapportGevinster;
		}
		public void setEndOfDayRapportGevinster(Double endOfDayRapportGevinster) {
			this.endOfDayRapportGevinster = endOfDayRapportGevinster;
		}
		public Double getEndOfDayRapportKommissionRake() {
			return endOfDayRapportKommissionRake;
		}
		public void setEndOfDayRapportKommissionRake(
				Double endOfDayRapportKommissionRake) {
			this.endOfDayRapportKommissionRake = endOfDayRapportKommissionRake;
		}
		
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.EndOfDayRapportStruktur;
	}

}
