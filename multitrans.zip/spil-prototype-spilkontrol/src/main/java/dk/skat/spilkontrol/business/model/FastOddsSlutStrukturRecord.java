package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.PuljespilSlutStandardRecord.TilfaeldighedGenerator;
import dk.skat.spilkontrol.business.model.datafile.Dimensions;
import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class FastOddsSlutStrukturRecord extends AbstractGameStandardRecord {

	private Stack<TransaktionType> transactions = new Stack<TransaktionType>();

	public Stack<TransaktionType> getTransaktions() {
		return this.transactions;
	}
	
	public TransaktionType getLastTransaction() {
		return transactions.peek();
	}
	
	public TransaktionType addTransaction(TransaktionType transaction) {
		return transactions.push(transaction);
	}

	public class TransaktionType {
		private String spillerInformationIdentifikation;
		private String spilTransaktionIdentifikation;
		private Double spilGevinst;
		private Double Lukandel;
		private Double spilKommission;
		private DateTime spilFaktiskSlutDatoTid;
		private String spilFaktiskSlutDatoTidString;
		private String valutaOplysningKode;

		private final Stack<TilfaeldighedGenerator> tilfaeldighedGeneratorListe = new Stack<TilfaeldighedGenerator>();
		
		public String getSpillerInformationIdentifikation() {
			return spillerInformationIdentifikation;
		}
		public void setSpillerInformationIdentifikation(
				String spillerInformationIdentifikation) {
			this.spillerInformationIdentifikation = spillerInformationIdentifikation;
		}
		public String getSpilTransaktionIdentifikation() {
			return spilTransaktionIdentifikation;
		}
		public void setSpilTransaktionIdentifikation(String spilIdentifikation) {
			this.spilTransaktionIdentifikation = spilIdentifikation;
		}
		public Double getSpilGevinst() {
			return spilGevinst;
		}
		public void setSpilGevinst(Double spilGevinst) {
			this.spilGevinst = spilGevinst;
		}
		public Double getLukandel() {
			return Lukandel;
		}
		public void setLukandel(Double Lukandel) {
			this.Lukandel = Lukandel;
		}
		public Double getSpilKommission() {
			return spilKommission;
		}
		public void setSpilKommission(Double spilKommission) {
			this.spilKommission = spilKommission;
		}
		public DateTime getSpilFaktiskSlutDatoTid() {
			return spilFaktiskSlutDatoTid;
		}
		public void setSpilFaktiskSlutDatoTid(DateTime spilFaktiskSlutDatoTid) {
			this.spilFaktiskSlutDatoTid = spilFaktiskSlutDatoTid;
		}		
		public final String getSpilFaktiskSlutDatoTidString() {
			return spilFaktiskSlutDatoTidString;
		}
		public final void setSpilFaktiskSlutDatoTidString(
				String spilFaktiskSlutDatoTidString) {
			this.spilFaktiskSlutDatoTidString = spilFaktiskSlutDatoTidString;
		}
		public String getValutaOplysningKode() {
			return valutaOplysningKode;
		}
		public void setValutaOplysningKode(String valutaOplysningKode) {
			this.valutaOplysningKode = valutaOplysningKode;
		}
		public final void addNewTilfaeldighedGenerator() { tilfaeldighedGeneratorListe.push(new TilfaeldighedGenerator()); }
		public Stack<TilfaeldighedGenerator> getTilfaeldighedGeneratorListe() {
			return this.tilfaeldighedGeneratorListe;
		}
        public TilfaeldighedGenerator addTilfaeldighedGenerator(TilfaeldighedGenerator tilfaeldighedGenerator) {
			return tilfaeldighedGeneratorListe.push(tilfaeldighedGenerator);
		}
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.FastOddsSlutStruktur;
	}

	@Override
	public void collectDimensions(Dimensions cache) {
		super.collectDimensions(cache);
		
		for (TransaktionType t : transactions) {
			cache.addSession(t.getSpilTransaktionIdentifikation());
			cache.addTransaction(t.getSpilTransaktionIdentifikation(), false);
			cache.addDate(t.spilFaktiskSlutDatoTid);
			cache.addValuta(t.valutaOplysningKode);
			cache.addSpiller(t.spillerInformationIdentifikation);
		}
	}
}
