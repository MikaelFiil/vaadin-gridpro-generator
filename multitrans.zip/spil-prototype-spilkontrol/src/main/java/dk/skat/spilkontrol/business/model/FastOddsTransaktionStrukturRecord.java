package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.datafile.Dimensions;
import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class FastOddsTransaktionStrukturRecord extends AbstractGameStandardRecord {

	private Stack<TransaktionType> transactions = new Stack<TransaktionType>();
	
	public Stack<TransaktionType> getTransaktions() {
		return this.transactions;
	}
	
	public TransaktionType getLastTransaction() {
		return transactions.peek();
	}
	
	public TransaktionType addTransaction(TransaktionType transaction) {
		return transactions.push(transaction);
	}

	public class TransaktionType {
		private String spilProduktNavn;
		private String spilProduktIdentifikation;
		private Double odds;
		private String spillerInformationIdentifikation;
		private String spilIdentifikation;
		private DateTime spilKoebDatoTid;
		private DateTime spilForventetSlutDatoTid;
		private String spilKoebDatoTidString;
		private String spilForventetSlutDatoTidString;
		private String spilSalgskanal;
		private String spilTerminalIdentifikation;
		
		//Danish word for homepage
		private String spilHjemmeside;
		
		private Double spilIndskud;
		private String tilfaeldighedGeneratorIdentifikation;
		private String tilfaeldighedGeneratorSoftwareId;
		private String valutaOplysningKode;
		private Boolean spilAnnullering; 
		private DateTime spilAnnulleringDatoTid;
		private String spilAnnulleringDatoTidString;

	    private final Stack<BegivenhedsinformationType> begivenhedsinformationListe = new Stack<BegivenhedsinformationType>();

        public Stack<BegivenhedsinformationType> getBegivenhedsinformations() {
            return this.begivenhedsinformationListe;
        }
	
        public BegivenhedsinformationType getLastBegivenhedsinformation() {
            return begivenhedsinformationListe.peek();
        }
	
        public BegivenhedsinformationType addBegivenhedsinformation(BegivenhedsinformationType begivenhedsinformation) {
            return begivenhedsinformationListe.push(begivenhedsinformation);
        }
	
	    public class BegivenhedsinformationType {
		
	        private Long id;
	        private Long transaktionid;
    	    private Long stdrecordid;
    	    private String begivenhedsnavn;
	        private String landekode;
	        private String sportsgrenskode;
	        private DateTime forventetstarttidspunkt;
	        private String begivenhedsidentifikation;
	        private String udfaldsnavn;
	        private String udfaldsidentifikation;
	        private Double begivenhedsodds;
		
		    public Long getId() {
			    return id;
		    }
		    public void setId(Long id) {
			    this.id = id;
			
		    }
		    public Long getTransaktionid() {
			    return transaktionid;
		    }
		    public void setTransaktionid(Long transaktionid) {
			    this.transaktionid = transaktionid;
			
		    }
		    public Long getStdrecordid() {
			    return stdrecordid;
		    }
		    public void setStdrecordid(Long stdrecordid) {
			    this.stdrecordid = stdrecordid;
			
		    }
		    public String getBegivenhedsnavn() {
			    return begivenhedsnavn;
		    }
		    public void setBegivenhedsnavn(String begivenhedsnavn) {
			    this.begivenhedsnavn = begivenhedsnavn;
			
		    }
		    public String getLandekode() {
			    return landekode;
		    }
		    public void setLandekode(String landekode) {
			    this.landekode = landekode;
			
		    }
		    public String getSportsgrenskode() {
			    return sportsgrenskode;
		    }
		    public void setSportsgrenskode(String sportsgrenskode) {
			    this.sportsgrenskode = sportsgrenskode;
			
		    }
		    public DateTime getForventetstarttidspunkt() {
			    return forventetstarttidspunkt;
		    }
		    public void setForventetstarttidspunkt(DateTime forventetstarttidspunkt) {
			    this.forventetstarttidspunkt = forventetstarttidspunkt;
			
		    }
		    public String getBegivenhedsidentifikation() {
			    return begivenhedsidentifikation;
		    }
		    public void setBegivenhedsidentifikation(String begivenhedsidentifikation) {
			    this.begivenhedsidentifikation = begivenhedsidentifikation;
			
		    }
		    public String getUdfaldsnavn() {
			    return udfaldsnavn;
		    }
		    public void setUdfaldsnavn(String udfaldsnavn) {
			    this.udfaldsnavn = udfaldsnavn;
			
		    }
		    public String getUdfaldsidentifikation() {
			    return udfaldsidentifikation;
		    }
		    public void setUdfaldsidentifikation(String udfaldsidentifikation) {
			    this.udfaldsidentifikation = udfaldsidentifikation;
			
		    }
		    public Double getBegivenhedsodds() {
			    return begivenhedsodds;
		    }
		    public void setBegivenhedsodds(Double begivenhedsodds) {
			    this.begivenhedsodds = begivenhedsodds;
			
		    }
		
	    }
	
	    public final Stack<BegivenhedsinformationType> getBegivenhedsinformationListe() {
		    return begivenhedsinformationListe;
	    }

	    public void addNewBegivenhedsinformation() {
	        begivenhedsinformationListe.push(new BegivenhedsinformationType());
	    }

		public String getSpilProduktNavn() {return spilProduktNavn; }
		public void setSpilProduktNavn(String spilProduktNavn) { this.spilProduktNavn = spilProduktNavn; }

		public String getSpilProduktIdentifikation() { return spilProduktIdentifikation; }
		public void setSpilProduktIdentifikation(String spilProduktIdentifikation) { this.spilProduktIdentifikation = spilProduktIdentifikation; }

		public Double getOdds() { return odds; }
		public void setOdds(Double odds) { this.odds = odds; }

		public String getSpillerInformationIdentifikation() {
			return spillerInformationIdentifikation;
		}
		public void setSpillerInformationIdentifikation(
				String spillerInformationIdentifikation) {
			this.spillerInformationIdentifikation = spillerInformationIdentifikation;
		}
		public String getSpilTransaktionIdentifikation() {
			return spilIdentifikation;
		}
		public void setSpilTransaktionIdentifikation(String spilIdentifikation) {
			this.spilIdentifikation = spilIdentifikation;
		}
		public DateTime getSpilKoebDatoTid() {
			return spilKoebDatoTid;
		}
		public void setSpilKoebDatoTid(DateTime spilKoebDatoTid) {
			this.spilKoebDatoTid = spilKoebDatoTid;
		}
		public DateTime getSpilForventetSlutDatoTid() {
			return spilForventetSlutDatoTid;
		}
		public void setSpilForventetSlutDatoTid(DateTime spilForventetSlutDatoTid) {
			this.spilForventetSlutDatoTid = spilForventetSlutDatoTid;
		}
		public String getSpilSalgskanal() {
			return spilSalgskanal;
		}
		public void setSpilSalgskanal(String spilSalgskanal) {
			this.spilSalgskanal = spilSalgskanal;
		}
		public String getSpilTerminalIdentifikation() {
			return spilTerminalIdentifikation;
		}
		public void setSpilTerminalIdentifikation(String spilTerminalIdentifikation) {
			this.spilTerminalIdentifikation = spilTerminalIdentifikation;
		}
		public Double getSpilIndskud() {
			return spilIndskud;
		}
		public void setSpilIndskud(Double spilIndskud) {
			this.spilIndskud = spilIndskud;
		}
		public String getTilfaeldighedGeneratorIdentifikation() {
			return tilfaeldighedGeneratorIdentifikation;
		}
		public void setTilfaeldighedGeneratorIdentifikation(
				String tilfaeldighedGeneratorIdentifikation) {
			this.tilfaeldighedGeneratorIdentifikation = tilfaeldighedGeneratorIdentifikation;
		}
		public String getTilfaeldighedGeneratorSoftwareId() {
			return tilfaeldighedGeneratorSoftwareId;
		}
		public void setTilfaeldighedGeneratorSoftwareId(
				String tilfaeldighedGeneratorSoftwareId) {
			this.tilfaeldighedGeneratorSoftwareId = tilfaeldighedGeneratorSoftwareId;
		}
		public String getValutaOplysningKode() {
			return valutaOplysningKode;
		}
		public void setValutaOplysningKode(String valutaOplysningKode) {
			this.valutaOplysningKode = valutaOplysningKode;
		}
		public Boolean getSpilAnnullering() {
			return spilAnnullering;
		}
		public void setSpilAnnullering(Boolean spilAnnullering) {
			this.spilAnnullering = spilAnnullering;
		}
		public DateTime getSpilAnnulleringDatoTid() {
			return spilAnnulleringDatoTid;
		}
		public void setSpilAnnulleringDatoTid(DateTime spilAnnulleringDatoTid) {
			this.spilAnnulleringDatoTid = spilAnnulleringDatoTid;
		}
		public String getSpilHjemmeside() {
			return spilHjemmeside;
		}
		public void setSpilHjemmeside(String hjemmeside) {
			this.spilHjemmeside = hjemmeside;
		}
		public final String getSpilKoebDatoTidString() {
			return spilKoebDatoTidString;
		}
		public final void setSpilKoebDatoTidString(String spilKoebDatoTidString) {
			this.spilKoebDatoTidString = spilKoebDatoTidString;
		}
		public final String getSpilForventetSlutDatoTidString() {
			return spilForventetSlutDatoTidString;
		}
		public final void setSpilForventetSlutDatoTidString(
				String spilForventetSlutDatoTidString) {
			this.spilForventetSlutDatoTidString = spilForventetSlutDatoTidString;
		}
		public final String getSpilAnnulleringDatoTidString() {
			return spilAnnulleringDatoTidString;
		}
		public final void setSpilAnnulleringDatoTidString(
				String spilAnnulleringDatoTidString) {
			this.spilAnnulleringDatoTidString = spilAnnulleringDatoTidString;
		}
		
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.FastOddsTransaktionStruktur;
	}
	
	@Override
	public void collectDimensions(Dimensions cache) {
		super.collectDimensions(cache);
		
		for (TransaktionType t : transactions) {
			cache.addSession(t.getSpilTransaktionIdentifikation());
			cache.addTransaction(t.getSpilTransaktionIdentifikation(), t.spilAnnullering);
			cache.addDate(t.spilAnnulleringDatoTid);
			cache.addDate(t.spilForventetSlutDatoTid);
			cache.addDate(t.spilKoebDatoTid);
			cache.addValuta(t.valutaOplysningKode);
			cache.addSpiller(t.spillerInformationIdentifikation);
		}
	}
}
