package dk.skat.spilkontrol.business.model;

import java.util.ArrayList;
import java.util.List;

public class FilInformationType {
	private String spilFilIdentification;
	private final List<String> spilFilErstatningIdentificakations;
	
	public FilInformationType() {
		this.spilFilErstatningIdentificakations = new ArrayList<String>();
	}
	
	public boolean addSpilFilErstatningIdentificakation(String spilFilErstatningIdentificakation) {
		return this.spilFilErstatningIdentificakations.add(spilFilErstatningIdentificakation);
	}

	public void setSpilFilIdentification(String spilFilIdentification) {
		this.spilFilIdentification = spilFilIdentification;
	}
	
	public String getSpilFilIdentification() {
		return spilFilIdentification;
	}

	public List<String> getSpilFilErstatningIdentificakations() {
		return spilFilErstatningIdentificakations;
	}
	
}