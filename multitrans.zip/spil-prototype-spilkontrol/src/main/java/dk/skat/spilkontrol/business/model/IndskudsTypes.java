package dk.skat.spilkontrol.business.model;

public enum IndskudsTypes {

	INDSKUD("INDSKUD");
	
	private String name;
	
	IndskudsTypes(String value) {
		name = value;
	}
	
	public String getStringRepresentation() {
		return name;
	}
	
}
