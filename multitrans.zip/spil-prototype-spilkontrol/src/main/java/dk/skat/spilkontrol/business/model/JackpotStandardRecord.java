package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.datafile.Dimensions;
import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class JackpotStandardRecord extends StandardRecord {
	
	private static final String NO_SPILLER_STRING = "notcustomer";
	
	private String spilKategoriNavn;
	private String jackpotIdentification; // Jackpot table (JackpotIdentification)
	private DateTime jackpotDatoTid; //JackotUdloesning table (JackpotDatoTid)
	private String jackpotDateTimeString; 
	private Double jackpotTotalGevinst; //JackotUdloesning table (JackpotTotalGevinst)
	private Double jackpotKomissionRake; //JackotUdloesning table (JackpotKomissionRake)
	private String valutaOplysningKode; //JackotUdloesning table (ValutaOplysningKode)
	private final Stack<SpillerType> spiller = new Stack<SpillerType>();
	
	public static class SpillerType {
		
		private String spillerInformationIdentifikation;
		private Double jackpotGevinst;
		
		public String getSpillerInformationIdentifikation() {
			if (spillerInformationIdentifikation == null || spillerInformationIdentifikation.equals("")) {
				this.spillerInformationIdentifikation = NO_SPILLER_STRING;
			}
			return spillerInformationIdentifikation;
		}
		public void setSpillerInformationIdentifikation(String spillerInformationIdentifikation) {
			this.spillerInformationIdentifikation = spillerInformationIdentifikation;
			
		}
		public Double getJackpotGevinst() {
			return jackpotGevinst;
		}
		public void setJackpotGevinst(Double jackpotGevinst) {
			this.jackpotGevinst = jackpotGevinst;
		}
		@Override
		public String toString() {
			return "SpillerType [spillerInformationIdentifikation="
					+ spillerInformationIdentifikation + ", jackpotGevinst="
					+ jackpotGevinst + "]";
		}
		
	}
	
	public final Stack<SpillerType> getSpillerListe() {
		return spiller;
	}

	public void addNewSpiller() {
		spiller.push(new SpillerType());
	}
	
	public final String getSpilKategoriNavn() {
		return spilKategoriNavn;
	}

	public final void setSpilKategoriNavn(String spilKategoriNavn) {
		this.spilKategoriNavn = spilKategoriNavn;
	}

	public String getJackpotIdentification() {
		return jackpotIdentification;
	}

	public void setJackpotIdentification(String jackpotIdentification) {
		this.jackpotIdentification = jackpotIdentification;
	}

	public DateTime getJackpotDatoTid() {
		return jackpotDatoTid;
	}

	public void setJackpotDatoTid(DateTime jackpotDatoTid) {
		this.jackpotDatoTid = jackpotDatoTid;
	}

	public final String getJackpotDateTimeString() {
		return jackpotDateTimeString;
	}

	public final void setJackpotDateTimeString(String jackpotDateTimeString) {
		this.jackpotDateTimeString = jackpotDateTimeString;
	}

	public Double getJackpotTotalGevinst() {
		return jackpotTotalGevinst;
	}

	public void setJackpotTotalGevinst(Double jackpotTotalGevinst) {
		this.jackpotTotalGevinst = jackpotTotalGevinst;
	}

	public Double getJackpotKomissionRake() {
		return jackpotKomissionRake;
	}

	public void setJackpotKomissionRake(Double jackpotKomissionRake) {
		this.jackpotKomissionRake = jackpotKomissionRake;
	}

	public String getValutaOplysningKode() {
		return valutaOplysningKode;
	}

	public void setValutaOplysningKode(String valutaOplysningKode) {
		this.valutaOplysningKode = valutaOplysningKode;
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.JackpotUdloesningStruktur;
	}
	
	@Override
	public String toString() {
		return super.toString() 
				+"JackPotStandardRecord [spilKategoriNavn=" + spilKategoriNavn
				+ ", jackpotIdentification=" + jackpotIdentification
				+ ", jackpotDatoTid=" + jackpotDatoTid
				+ ", jackpotTotalGevinst=" + jackpotTotalGevinst
				+ ", jackpotKomissionRake=" + jackpotKomissionRake
				+ ", valutaOplysningKode=" + valutaOplysningKode + ", spiller="
				+ spiller + "]";
	}

	@Override
	public void collectDimensions(Dimensions cache) {
		super.collectDimensions(cache);
		
		cache.addValuta(valutaOplysningKode);
		cache.addDate(jackpotDatoTid);
		cache.addJackpot(jackpotIdentification);
		
		for (SpillerType s : spiller) {
			if (s.spillerInformationIdentifikation != null && !s.spillerInformationIdentifikation.equals("")) {
				cache.addSpiller(s.spillerInformationIdentifikation);
			} else {
				cache.addSpiller(NO_SPILLER_STRING);
			}
		}
		
	}
	
	
	
}
