package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class KasinoSpilleautomatJackpotStandardRecord extends StandardRecord {

	private Stack<JackpotPuljeTransaktion> pujleTransaktions = new Stack<JackpotPuljeTransaktion>();

	private String spilleautomatJackpotIdentifikation;
	private DateTime spilleautomatJackpotUdtraekDatoTid;
	private String jackpotUdtraekDateTimeString;
	private Long spilleautomatJackpotPuljeTotal;
	
	private String gevinstKasinoIdentifikation;
	private String gevinstSpilleautomatNavn;
	private String gevinstSpilleautomatNummer;	
	private Long spilleautomatJackpotUdbetalingGevinst;
	private String spilleautomatFabrikantGevinst;
	
	public String getSpilleautomatFabrikantGevinst() {
		return spilleautomatFabrikantGevinst;
	}

	public void setSpilleautomatFabrikantGevinst(String spilleautomatFabrikantGevinst) {
		this.spilleautomatFabrikantGevinst = spilleautomatFabrikantGevinst;
	}

	/**
	 * in <JackpotPuljeOpstart>
	 */
	private Long spilleautomatJackpotOpstartBeloeb;
	
	public String getSpilleautomatJackpotIdentifikation() {
		return spilleautomatJackpotIdentifikation;
	}

	public void setSpilleautomatJackpotIdentifikation(
			String spilleautomatJackpotIdentifikation) {
		this.spilleautomatJackpotIdentifikation = spilleautomatJackpotIdentifikation;
	}

	public DateTime getSpilleautomatJackpotUdtraekDatoTid() {
		return spilleautomatJackpotUdtraekDatoTid;
	}

	public void setSpilleautomatJackpotUdtraekDatoTid(
			DateTime spilleautomatJackpotUdtraekDatoTid) {
		this.spilleautomatJackpotUdtraekDatoTid = spilleautomatJackpotUdtraekDatoTid;
	}

	public final String getJackpotUdtraekDateTimeString() {
		return jackpotUdtraekDateTimeString;
	}

	public final void setJackpotUdtraekDateTimeString(
			String jackpotUdtraekDateTimeString) {
		this.jackpotUdtraekDateTimeString = jackpotUdtraekDateTimeString;
	}

	public JackpotPuljeTransaktion getLastJackpotPuljeTransaktion() {
		return pujleTransaktions.peek();
	}
	
	public JackpotPuljeTransaktion addNewJackpotPuljeTransaktion() {
		return pujleTransaktions.push(new JackpotPuljeTransaktion());
	}

	public static class JackpotPuljeTransaktion {
		private String kasinoIdentifikation;
		private String spilleautomatNavn;
		private String spilleautomatNummer;
		private Long spilleautomatJackpotTilvaekstBeloeb;
		private String spilleautomatFabrikant;
		
		public String getSpilleautomatFabrikant() {
			return spilleautomatFabrikant;
		}
		public void setSpilleautomatFabrikant(String spilleautomatFabrikant) {
			this.spilleautomatFabrikant = spilleautomatFabrikant;
		}
		public String getKasinoIdentifikation() {
			return kasinoIdentifikation;
		}
		public void setKasinoIdentifikation(String kasinoIdentifikation) {
			this.kasinoIdentifikation = kasinoIdentifikation;
		}
		public String getSpilleautomatNavn() {
			return spilleautomatNavn;
		}
		public void setSpilleautomatNavn(String spilleautomatNavn) {
			this.spilleautomatNavn = spilleautomatNavn;
		}
		public String getSpilleautomatNummer() {
			return spilleautomatNummer;
		}
		public void setSpilleautomatNummer(String spilleautomatNummer) {
			this.spilleautomatNummer = spilleautomatNummer;
		}
		public Long getSpilleautomatJackpotTilvaekstBeloeb() {
			return spilleautomatJackpotTilvaekstBeloeb;
		}
		public void setSpilleautomatJackpotTilvaekstBeloeb(
				Long spilleautomatJackpotTilvaekstBeloeb) {
			this.spilleautomatJackpotTilvaekstBeloeb = spilleautomatJackpotTilvaekstBeloeb;
		}
		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("JackpotPuljeTransaktion [getKasinoIdentifikation()=");
			builder.append(getKasinoIdentifikation());
			builder.append(", getSpilleautomatNavn()=");
			builder.append(getSpilleautomatNavn());
			builder.append(", getSpilleautomatNummer()=");
			builder.append(getSpilleautomatNummer());
			builder.append(", getSpilleautomatJackpotTilvaekstBeloeb()=");
			builder.append(getSpilleautomatJackpotTilvaekstBeloeb());
			builder.append("]");
			return builder.toString();
		}
		
	}

	public Long getSpilleautomatJackpotPuljeTotal() {
		return spilleautomatJackpotPuljeTotal;
	}

	public void setSpilleautomatJackpotPuljeTotal(
			Long spilleautomatJackpotPuljeTotal) {
		this.spilleautomatJackpotPuljeTotal = spilleautomatJackpotPuljeTotal;
	}

	public String getGevinstKasinoIdentifikation() {
		return gevinstKasinoIdentifikation;
	}

	public void setGevinstKasinoIdentifikation(String gevinstKasinoIdentifikation) {
		this.gevinstKasinoIdentifikation = gevinstKasinoIdentifikation;
	}

	public String getGevinstSpilleautomatNavn() {
		return gevinstSpilleautomatNavn;
	}

	public void setGevinstSpilleautomatNavn(String gevinstSpilleautomatNavn) {
		this.gevinstSpilleautomatNavn = gevinstSpilleautomatNavn;
	}

	public String getGevinstSpilleautomatNummer() {
		return gevinstSpilleautomatNummer;
	}

	public void setGevinstSpilleautomatNummer(String gevinstSpilleautomatNummer) {
		this.gevinstSpilleautomatNummer = gevinstSpilleautomatNummer;
	}

	public Long getSpilleautomatJackpotUdbetalingGevinst() {
		return spilleautomatJackpotUdbetalingGevinst;
	}

	public void setSpilleautomatJackpotUdbetalingGevinst(
			Long spilleautomatJackpotUdbetalingGevinst) {
		this.spilleautomatJackpotUdbetalingGevinst = spilleautomatJackpotUdbetalingGevinst;
	}

	public Long getSpilleautomatJackpotOpstartBeloeb() {
		return spilleautomatJackpotOpstartBeloeb;
	}

	public void setSpilleautomatJackpotOpstartBeloeb(Long spilleautomatJackpotOpstartBeloeb) {
		this.spilleautomatJackpotOpstartBeloeb = spilleautomatJackpotOpstartBeloeb;
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.KasinoSpilleautomatJackpotStruktur;
	}

	public Stack<JackpotPuljeTransaktion> getPujleTransaktions() {
		return pujleTransaktions;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("KasinoSpilleautomatJackpotStandardRecord [pujleTransaktions=");
		builder.append(pujleTransaktions);
		builder.append(", spilleautomatJackpotIdentifikation=");
		builder.append(spilleautomatJackpotIdentifikation);
		builder.append(", spilleautomatJackpotUdtraekDatoTid=");
		builder.append(spilleautomatJackpotUdtraekDatoTid);
		builder.append(", spilleautomatJackpotPuljeTotal=");
		builder.append(spilleautomatJackpotPuljeTotal);
		builder.append(", gevinstKasinoIdentifikation=");
		builder.append(gevinstKasinoIdentifikation);
		builder.append(", gevinstSpilleautomatNavn=");
		builder.append(gevinstSpilleautomatNavn);
		builder.append(", gevinstSpilleautomatNummer=");
		builder.append(gevinstSpilleautomatNummer);
		builder.append(", spilleautomatJackpotUdbetalingGevinst=");
		builder.append(spilleautomatJackpotUdbetalingGevinst);
		builder.append(", spilleautomatJackpotOpstartBeloeb=");
		builder.append(spilleautomatJackpotOpstartBeloeb);
		builder.append(", getSpilFilIdentifikation()=");
		builder.append(getSpilFilIdentifikation());
		builder.append(", getSpilCertifikatIdentifikation()=");
		builder.append(getSpilCertifikatIdentifikation());
		builder.append("]");
		return builder.toString();
	}

}
