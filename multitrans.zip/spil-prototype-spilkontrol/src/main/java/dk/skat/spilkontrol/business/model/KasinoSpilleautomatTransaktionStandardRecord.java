package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class KasinoSpilleautomatTransaktionStandardRecord extends StandardRecord {

	private Stack<SpilleautomatAflaesning> aflaesnings = new Stack<SpilleautomatAflaesning>();
	
	public Stack<SpilleautomatAflaesning> getAflaesnings() {
		return this.aflaesnings;
	}
	
	public SpilleautomatAflaesning getLastAflaesning() {
		return aflaesnings.peek();
	}
	
	public SpilleautomatAflaesning addNewAflaesning() {
		return aflaesnings.push(new SpilleautomatAflaesning());
	}

	public class SpilleautomatAflaesning {
		private String spilleautomatFabrikant;
		private String spilleautomatNavn;
		private String spilleautomatNummer;
		
		private DateTime spilleautomatUdtraekDatoTid;
		private String spilleautomatUdtraekDateTimeString;
		private String spilleautomatProgramVersion;

		private DateTime spilleautomatSidstAendret;
		private String spilleautomatSidstAendretDateTimeString;
		
		private Double spilleautomatUdbetalingsProcent;
		private Long spilleautomatIndbetalingIndskud;
		private Long spilleautomatudbetalingGevinst;
		private Long spilleautomatSpilledeKreditter;
		private Long spilleautomatVundneKreditter;
		
		public String getSpilleautomatFabrikant() {
			return spilleautomatFabrikant;
		}
		public void setSpilleautomatFabrikant(String spilleautomatFabrikant) {
			this.spilleautomatFabrikant = spilleautomatFabrikant;
		}
		public String getSpilleautomatNavn() {
			return spilleautomatNavn;
		}
		public void setSpilleautomatNavn(String spilleautomatNavn) {
			this.spilleautomatNavn = spilleautomatNavn;
		}
		public DateTime getSpilleautomatUdtraekDatoTid() {
			return spilleautomatUdtraekDatoTid;
		}
		public void setSpilleautomatUdtraekDatoTid(DateTime spilleautomatUdtraekDatoTid) {
			this.spilleautomatUdtraekDatoTid = spilleautomatUdtraekDatoTid;
		}
		public String getSpilleautomatProgramVersion() {
			return spilleautomatProgramVersion;
		}
		public void setSpilleautomatProgramVersion(String spilleautomatProgramVersion) {
			this.spilleautomatProgramVersion = spilleautomatProgramVersion;
		}
		public DateTime getSpilleautomatSidstAendret() {
			return spilleautomatSidstAendret;
		}
		public void setSpilleautomatSidstAendret(DateTime spilleautomatSidstAendret) {
			this.spilleautomatSidstAendret = spilleautomatSidstAendret;
		}
		public Double getSpilleautomatUdbetalingsProcent() {
			return spilleautomatUdbetalingsProcent;
		}
		public void setSpilleautomatUdbetalingsProcent(Double spilleautomatUdbetalingsProcent) {
			this.spilleautomatUdbetalingsProcent = spilleautomatUdbetalingsProcent;
		}
		public String getSpilleautomatNummer() {
			return spilleautomatNummer;
		}
		public void setSpilleautomatNummer(String spilleautomatNummer) {
			this.spilleautomatNummer = spilleautomatNummer;
		}
		public Long getSpilleautomatIndbetalingIndskud() {
			return spilleautomatIndbetalingIndskud;
		}
		public void setSpilleautomatIndbetalingIndskud(
				Long spilleautomatIndbetalingIndskud) {
			this.spilleautomatIndbetalingIndskud = spilleautomatIndbetalingIndskud;
		}
		public Long getSpilleautomatudbetalingGevinst() {
			return spilleautomatudbetalingGevinst;
		}
		public void setSpilleautomatudbetalingGevinst(
				Long spilleautomatudbetalingGevinst) {
			this.spilleautomatudbetalingGevinst = spilleautomatudbetalingGevinst;
		}
		public Long getSpilleautomatSpilledeKreditter() {
			return spilleautomatSpilledeKreditter;
		}
		public void setSpilleautomatSpilledeKreditter(
				Long spilleautomatSpilledeKreditter) {
			this.spilleautomatSpilledeKreditter = spilleautomatSpilledeKreditter;
		}
		public Long getSpilleautomatVundneKreditter() {
			return spilleautomatVundneKreditter;
		}
		public void setSpilleautomatVundneKreditter(Long spilleautomatVundneKreditter) {
			this.spilleautomatVundneKreditter = spilleautomatVundneKreditter;
		}
		public final String getSpilleautomatUdtraekDateTimeString() {
			return spilleautomatUdtraekDateTimeString;
		}
		public final void setSpilleautomatUdtraekDateTimeString(
				String spilleautomatUdtraekDateTimeString) {
			this.spilleautomatUdtraekDateTimeString = spilleautomatUdtraekDateTimeString;
		}
		public final String getSpilleautomatSidstAendretDateTimeString() {
			return spilleautomatSidstAendretDateTimeString;
		}
		public final void setSpilleautomatSidstAendretDateTimeString(
				String spilleautomatSidstAendretDateTimeString) {
			this.spilleautomatSidstAendretDateTimeString = spilleautomatSidstAendretDateTimeString;
		}
		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("SpilleautomatAflaesning [spilleautomatFabrikant=");
			builder.append(spilleautomatFabrikant);
			builder.append(", spilleautomatNavn=");
			builder.append(spilleautomatNavn);
			builder.append(", spilleautomatNummer=");
			builder.append(spilleautomatNummer);
			builder.append(", spilleautomatUdtraekDatoTid=");
			builder.append(spilleautomatUdtraekDatoTid);
			builder.append(", spilleautomatProgramVersion=");
			builder.append(spilleautomatProgramVersion);
			builder.append(", spilleautomatSidstAendret=");
			builder.append(spilleautomatSidstAendret);
			builder.append(", spilleautomatUdbetalingsProcent=");
			builder.append(spilleautomatUdbetalingsProcent);
			builder.append(", spilleautomatIndbetalingIndskud=");
			builder.append(spilleautomatIndbetalingIndskud);
			builder.append(", spilleautomatudbetalingGevinst=");
			builder.append(spilleautomatudbetalingGevinst);
			builder.append(", spilleautomatSpilledeKreditter=");
			builder.append(spilleautomatSpilledeKreditter);
			builder.append(", spilleautomatVundneKreditter=");
			builder.append(spilleautomatVundneKreditter);
			builder.append("]");
			return builder.toString();
		}
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("KasinoSpilleautomatTransaktionStandardRecord [aflaesnings=");
		builder.append(aflaesnings);
		builder.append(", getSpilFilIdentifikation()=");
		builder.append(getSpilFilIdentifikation());
		builder.append(", getSpilCertifikatIdentifikation()=");
		builder.append(getSpilCertifikatIdentifikation());
		builder.append("]");
		return builder.toString();
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.KasinoSpilleautomatTransaktionStruktur;
	}	
}
