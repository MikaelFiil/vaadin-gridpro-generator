package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.PuljespilSlutStandardRecord.TilfaeldighedGenerator;
import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;

import java.util.Stack;

public class MonopolBingoNetskrabStartStandardRecord extends AbstractGameStandardRecord {

	private Double teoretiskTilbagebetalingProcent;
	private Boolean stamdataPuljespil;
	private Stack<GevinstStruktur> gevinstStruktur = new Stack<GevinstStruktur>();
	private final Stack<TilfaeldighedGenerator> tilfaeldighedGeneratorListe = new Stack<TilfaeldighedGenerator>();

	public Stack<GevinstStruktur> getSpilGevinstStrukturStack() {
		return this.gevinstStruktur;
	}
	
	public GevinstStruktur getLastGevinstStruktur() {
		return gevinstStruktur.peek();
	}
	
	public GevinstStruktur addGevinstStruktur(GevinstStruktur element) {
		return gevinstStruktur.push(element);
	}
	
	public final void addNewTilfaeldighedGenerator() {
		tilfaeldighedGeneratorListe.push(new TilfaeldighedGenerator());
	}

	public Stack<TilfaeldighedGenerator> getTilfaeldighedGeneratorListe() {
		return tilfaeldighedGeneratorListe;
	}

	public TilfaeldighedGenerator getLastTilfaeldighedGenerator() {
		return tilfaeldighedGeneratorListe.peek();
	}
	
	public final Double getTeoretiskTilbagebetalingProcent() {
		return teoretiskTilbagebetalingProcent;
	}

	public final void setTeoretiskTilbagebetalingProcent(
			Double teoretiskTilbagebetalingProcent) {
		this.teoretiskTilbagebetalingProcent = teoretiskTilbagebetalingProcent;
	}

	public final Boolean getStamdataPuljespil() {
		return stamdataPuljespil;
	}

	public final void setStamdataPuljespil(Boolean stamdataPuljespil) {
		this.stamdataPuljespil = stamdataPuljespil;
	}

	public class GevinstStruktur {

		private Long gevinstStamdataNummer;
		private String gevinstStamdataBeskrivelse;
		private Double gevinstStamdataBeloeb;
		private Double gevinstStamdataProcent;;
		private String valuta;

		public final Long getGevinstStamdataNummer() {
			return gevinstStamdataNummer;
		}

		public final void setGevinstStamdataNummer(Long gevinstStamdataNummer) {
			this.gevinstStamdataNummer = gevinstStamdataNummer;
		}

		public final String getGevinstStamdataBeskrivelse() {
			return gevinstStamdataBeskrivelse;
		}

		public final void setGevinstStamdataBeskrivelse(
				String gevinstStamdataBeskrivelse) {
			this.gevinstStamdataBeskrivelse = gevinstStamdataBeskrivelse;
		}

		public final Double getGevinstStamdataBeloeb() {
			return gevinstStamdataBeloeb;
		}

		public final void setGevinstStamdataBeloeb(Double gevinstStamdataBeloeb) {
			this.gevinstStamdataBeloeb = gevinstStamdataBeloeb;
		}

		public final Double getGevinstStamdataProcent() {
			return gevinstStamdataProcent;
		}

		public final void setGevinstStamdataProcent(Double gevinstStamdataProcent) {
			this.gevinstStamdataProcent = gevinstStamdataProcent;
		}

		public String getValuta() {
			return valuta;
		}

		public void setValuta(String valuta) {
			this.valuta = valuta;
		}
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolBingoNetskrabStartStruktur;
	}

}
