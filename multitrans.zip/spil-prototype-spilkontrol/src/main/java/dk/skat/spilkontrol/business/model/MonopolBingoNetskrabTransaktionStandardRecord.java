package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolBingoNetskrabTransaktionStandardRecord extends AbstractGameStandardRecord {
	
	private final Stack<SpillerOgKuponType> spillerOgKupon = new Stack<SpillerOgKuponType>();

	public final Stack<SpillerOgKuponType> getSpillerOgKuponListe() {
		return spillerOgKupon;
	}

	public final void addNewSpillerOgKupon() {
		spillerOgKupon.push(new SpillerOgKuponType());
	}

	public MonopolBingoNetskrabTransaktionStandardRecord() {
	}
	
	public static class SpillerOgKuponType {

		private String spillerInformationIdentifikation;
		private String spilTransaktionIdentifikation;
		private DateTime spilKoebDatoTid;
		private String spilKoebDatoTidString;
		private String spilSalgskanal;

		private Double spilIndskud;
		private Double spilGevinstSpil;
		private Double spilGevinstJackpot;
		private String valutaOplysningKode;
		
		private String spilTerminalidentification;
		private String spilHjemmeside;

		private Boolean spilAnnullering; // nullable
		private DateTime spilAnnulleringDatoTid; // nullable
		private String spilAnnulleringDatoTidString; // nullable
		
		public String getSpilHjemmeside() {
			return spilHjemmeside;
		}

		public void setSpilHjemmeside(String spilHjemmeside) {
			this.spilHjemmeside = spilHjemmeside;
		}

		public final String getSpillerInformationIdentifikation() {
			return spillerInformationIdentifikation;
		}

		public final void setSpillerInformationIdentifikation(
				String spillerInformationIdentifikation) {
			this.spillerInformationIdentifikation = spillerInformationIdentifikation;
		}

		public final String getSpilIdentifikation() {
			return spilTransaktionIdentifikation;
		}

		public final void setSpilTransaktionIdentifikation(String spilIdentifikation) {
			this.spilTransaktionIdentifikation = spilIdentifikation;
		}

		public final DateTime getSpilKoebDatoTid() {
			return spilKoebDatoTid;
		}

		public final void setSpilKoebDatoTid(DateTime spilKoebDatoTid) {
			this.spilKoebDatoTid = spilKoebDatoTid;
		}

		public final String getSpilSalgskanal() {
			return spilSalgskanal;
		}


		public final void setSpilSalgskanal(String spilSalgskanal) {
			this.spilSalgskanal = spilSalgskanal;
		}


		public final String getSpilTerminalidentification() {
			return spilTerminalidentification;
		}


		public final void setSpilTerminalidentification(
				String spilTerminalidentification) {
			this.spilTerminalidentification = spilTerminalidentification;
		}

		public final Boolean getSpilAnnullering() {
			return spilAnnullering;
		}

		public final void setSpilAnnullering(Boolean spilAnnullering) {
			this.spilAnnullering = spilAnnullering;
		}

		public final DateTime getSpilAnnulleringDatoTid() {
			return spilAnnulleringDatoTid;
		}

		public final void setSpilAnnulleringDatoTid(DateTime spilAnnulleringDatoTid) {
			this.spilAnnulleringDatoTid = spilAnnulleringDatoTid;
		}

		public final Double getSpilIndskud() {
			return spilIndskud;
		}

		public final void setSpilIndskud(Double spilIndskud) {
			this.spilIndskud = spilIndskud;
		}

		public final String getValutaOplysningKode() {
			return valutaOplysningKode;
		}

		public final void setValutaOplysningKode(String valutaOplysningKode) {
			this.valutaOplysningKode = valutaOplysningKode;
		}

		public final String getSpilTransaktionIdentifikation() {
			return spilTransaktionIdentifikation;
		}

		public final String getSpilKoebDatoTidString() {
			return spilKoebDatoTidString;
		}

		public final void setSpilKoebDatoTidString(String spilKoebDatoTidString) {
			this.spilKoebDatoTidString = spilKoebDatoTidString;
		}

		public final Double getSpilGevinstSpil() {
			return spilGevinstSpil;
		}

		public final void setSpilGevinstSpil(Double spilGevinstSpil) {
			this.spilGevinstSpil = spilGevinstSpil;
		}

		public final Double getSpilGevinstJackpot() {
			return spilGevinstJackpot;
		}

		public final void setSpilGevinstJackpot(Double spilGevinstJackpot) {
			this.spilGevinstJackpot = spilGevinstJackpot;
		}

		public final String getSpilAnnulleringDatoTidString() {
			return spilAnnulleringDatoTidString;
		}

		public final void setSpilAnnulleringDatoTidString(
				String spilAnnulleringDatoTidString) {
			this.spilAnnulleringDatoTidString = spilAnnulleringDatoTidString;
		}
		
	}
	
	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolBingoNetskrabTransaktionStruktur;
	}
	
}
