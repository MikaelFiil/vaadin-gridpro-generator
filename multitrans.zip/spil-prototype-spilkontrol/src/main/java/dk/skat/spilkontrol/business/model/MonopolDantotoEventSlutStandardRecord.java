package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

public class MonopolDantotoEventSlutStandardRecord extends AbstractMonopolDantotoStandardRecord{

	private DateTime eventSlutDatoTid;
	private String eventSlutDatoTidString;
	private double omsaetningFoerAnnulleringer;
	private double omsaetningEfterAnnulleringer;
	private double annulleringerBeloeb;
	
	
	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolDantotoEventSlutStruktur;
	}

	public DateTime getEventSlutDatoTid() {
		return eventSlutDatoTid;
	}


	public void setEventSlutDatoTid(DateTime eventSlutDatoTid) {
		this.eventSlutDatoTid = eventSlutDatoTid;
	}

	public String getEventSlutDatoTidString() {
		return eventSlutDatoTidString;
	}


	public void setEventSlutDatoTidString(String eventSlutDatoTidString) {
		this.eventSlutDatoTidString = eventSlutDatoTidString;
	}

	public double getOmsaetningFoerAnnulleringer() {
		return omsaetningFoerAnnulleringer;
	}


	public void setOmsaetningFoerAnnulleringer(double omsaetningFoerAnnulleringer) {
		this.omsaetningFoerAnnulleringer = omsaetningFoerAnnulleringer;
	}


	public double getOmsaetningEfterAnnulleringer() {
		return omsaetningEfterAnnulleringer;
	}


	public void setOmsaetningEfterAnnulleringer(double omsaetningEfterAnnulleringer) {
		this.omsaetningEfterAnnulleringer = omsaetningEfterAnnulleringer;
	}


	public double getAnnulleringerBeloeb() {
		return annulleringerBeloeb;
	}


	public void setAnnulleringerBeloeb(double annulleringerBeloeb) {
		this.annulleringerBeloeb = annulleringerBeloeb;
	}
}
