package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

public class MonopolDantotoEventStartStandardRecord extends AbstractMonopolDantotoStandardRecord{

	private DateTime eventDato;
	private String eventDatoString;
	private String host;
	private String baneNavn;
	private int baneNummer;
	
	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolDantotoEventStartStruktur;
	}

	public DateTime getEventDato() {
		return eventDato;
	}

	public void setEventDato(DateTime eventDato) {
		this.eventDato = eventDato;
	}
	
	public String getEventDatoString() {
		return eventDatoString;
	}

	public void setEventDatoString(String eventDatoString) {
		this.eventDatoString = eventDatoString;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getBaneNavn() {
		return baneNavn;
	}

	public void setBaneNavn(String baneNavn) {
		this.baneNavn = baneNavn;
	}

	public int getBaneNummer() {
		return baneNummer;
	}

	public void setBaneNummer(int baneNummer) {
		this.baneNummer = baneNummer;
	}
}
