package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolDantotoEventTotalStandardRecord extends AbstractMonopolDantotoStandardRecord {

	// Event Start
	private DateTime eventDato;
	private String eventDatoString;
	private String host;
	private String baneNavn;
	private int baneNummer;

	// Event Slut
	private DateTime eventSlutDatoTid;
	private String eventSlutDatoTidString;
	private double omsaetningFoerAnnulleringer;
	private double omsaetningEfterAnnulleringer;
	private double annulleringerBeloeb;

	// Spil start
	private double gevinstPuljeProcent;
	private DateTime spilForventetSlutDatoTid;
	private String spilForventetSlutDatoTidString;

	final private Stack<GenerelSpilNoegle> generelSpilNoegleListe = new Stack<GenerelSpilNoegle>();
	final private Stack<GevinstPulje> gevinstPuljeListe = new Stack<GevinstPulje>();

	public void addNewGenerelPuljeNoegle() {
		generelSpilNoegleListe.push(new GenerelSpilNoegle());
	}

	public void addNewGevinstPulje() {
		gevinstPuljeListe.push(new GevinstPulje());
	}

	// Spil slut
	private double indskudSpilTillIndh;
	private double antalRaekkerTillIndh;
	private double gevinstPuljeBeloeb;
	private DateTime lukketForSpilDatoTid;
	private String lukketForSpilDatoTidString;
	private DateTime spilProduktFaktiskSlutDatoTid;
	private String spilProduktFaktiskSlutDatoTidString;

	private final Stack<GevinstkategorierOgGevinster> resultatDantotoListe = new Stack<GevinstkategorierOgGevinster>();
	private final Stack<ResultatGrundlag> resultatGrundlagListe = new Stack<ResultatGrundlag>();
	private final Stack<Vinder> vinderListe = new Stack<Vinder>();
	private final Stack<UdgaaedeHeste> udgaaedeHesteListe = new Stack<UdgaaedeHeste>();

	public final void addNewGevinstkategorierOgGevinster() {
		resultatDantotoListe.push(new GevinstkategorierOgGevinster());
	}

	public final void addResultatGrundlag() {
		resultatGrundlagListe.push(new ResultatGrundlag());
	}

	public final void addNewVinder() {
		vinderListe.push(new Vinder());
	}

	public final void addNewUdgaaedeHeste() {
		udgaaedeHesteListe.push(new UdgaaedeHeste());
	}

	@Override
	// Event start
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolDantotoEventTotalStruktur;
	}

	public DateTime getEventDato() {
		return eventDato;
	}

	public void setEventDato(DateTime eventDato) {
		this.eventDato = eventDato;
	}

	public String getEventDatoString() {
		return eventDatoString;
	}

	public void setEventDatoString(String eventDatoString) {
		this.eventDatoString = eventDatoString;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getBaneNavn() {
		return baneNavn;
	}

	public void setBaneNavn(String baneNavn) {
		this.baneNavn = baneNavn;
	}

	public int getBaneNummer() {
		return baneNummer;
	}

	public void setBaneNummer(int baneNummer) {
		this.baneNummer = baneNummer;
	}

	// Event slut
	public DateTime getEventSlutDatoTid() {
		return eventSlutDatoTid;
	}


	public void setEventSlutDatoTid(DateTime eventSlutDatoTid) {
		this.eventSlutDatoTid = eventSlutDatoTid;
	}

	public String getEventSlutDatoTidString() {
		return eventSlutDatoTidString;
	}


	public void setEventSlutDatoTidString(String eventSlutDatoTidString) {
		this.eventSlutDatoTidString = eventSlutDatoTidString;
	}

	public double getOmsaetningFoerAnnulleringer() {
		return omsaetningFoerAnnulleringer;
	}


	public void setOmsaetningFoerAnnulleringer(double omsaetningFoerAnnulleringer) {
		this.omsaetningFoerAnnulleringer = omsaetningFoerAnnulleringer;
	}


	public double getOmsaetningEfterAnnulleringer() {
		return omsaetningEfterAnnulleringer;
	}


	public void setOmsaetningEfterAnnulleringer(double omsaetningEfterAnnulleringer) {
		this.omsaetningEfterAnnulleringer = omsaetningEfterAnnulleringer;
	}


	public double getAnnulleringerBeloeb() {
		return annulleringerBeloeb;
	}


	public void setAnnulleringerBeloeb(double annulleringerBeloeb) {
		this.annulleringerBeloeb = annulleringerBeloeb;
	}

	// Spil start

	public double getGevinstPuljeProcent() {
		return gevinstPuljeProcent;
	}

	public void setGevinstPuljeProcent(double gevinstPuljeProcent) {
		this.gevinstPuljeProcent = gevinstPuljeProcent;
	}

	public DateTime getSpilForventetSlutDatoTid() {
		return spilForventetSlutDatoTid;
	}

	public void setSpilForventetSlutDatoTid(DateTime spilForventetSlutDatoTid) {
		this.spilForventetSlutDatoTid = spilForventetSlutDatoTid;
	}

	public String getSpilForventetSlutDatoTidString() {
		return spilForventetSlutDatoTidString;
	}

	public void setSpilForventetSlutDatoTidString(
			String spilForventetSlutDatoTidString) {
		this.spilForventetSlutDatoTidString = spilForventetSlutDatoTidString;
	}

	public Stack<GenerelSpilNoegle> getGenerelSpilNoegleListe() {
		return generelSpilNoegleListe;
	}

	public Stack<GevinstPulje> getGevinstPuljeListe() {
		return gevinstPuljeListe;
	}



	// spil slut

	public double getIndskudSpilTillIndh() {
		return indskudSpilTillIndh;
	}

	public void setIndskudSpilTillIndh(double indskudSpilTillIndh) {
		this.indskudSpilTillIndh = indskudSpilTillIndh;
	}

	public double getAntalRaekkerTillIndh() {
		return antalRaekkerTillIndh;
	}

	public void setAntalRaekkerTillIndh(double antalRaekkerTillIndh) {
		this.antalRaekkerTillIndh = antalRaekkerTillIndh;
	}

	public double getGevinstPuljeBeloeb() {
		return gevinstPuljeBeloeb;
	}

	public void setGevinstPuljeBeloeb(double gevinstPuljeBeloeb) {
		this.gevinstPuljeBeloeb = gevinstPuljeBeloeb;
	}

	public DateTime getLukketForSpilDatoTid() {
		return lukketForSpilDatoTid;
	}

	public void setLukketForSpilDatoTid(DateTime lukketForSpilDatoTid) {
		this.lukketForSpilDatoTid = lukketForSpilDatoTid;
	}

	public String getLukketForSpilDatoTidString() {
		return lukketForSpilDatoTidString;
	}

	public void setLukketForSpilDatoTidString(String lukketForSpilDatoTidString) {
		this.lukketForSpilDatoTidString = lukketForSpilDatoTidString;
	}

	public DateTime getSpilProduktFaktiskSlutDatoTid() {
		return spilProduktFaktiskSlutDatoTid;
	}

	public void setSpilProduktFaktiskSlutDatoTid(
			DateTime spilProduktFaktiskSlutDatoTid) {
		this.spilProduktFaktiskSlutDatoTid = spilProduktFaktiskSlutDatoTid;
	}

	public String getSpilProduktFaktiskSlutDatoTidString() {
		return spilProduktFaktiskSlutDatoTidString;
	}

	public void setSpilProduktFaktiskSlutDatoTidString(
			String spilProduktFaktiskSlutDatoTidString) {
		this.spilProduktFaktiskSlutDatoTidString = spilProduktFaktiskSlutDatoTidString;
	}

	public Stack<GevinstkategorierOgGevinster> getResultatDantotoListe() {
		return resultatDantotoListe;
	}

	public Stack<ResultatGrundlag> getResultatGrundlagListe() {
		return resultatGrundlagListe;
	}

	public Stack<Vinder> getVinderListe() {
		return vinderListe;
	}

	public final Stack<UdgaaedeHeste> getUdgaaedeHesteListe() {
		return udgaaedeHesteListe;
	}

}