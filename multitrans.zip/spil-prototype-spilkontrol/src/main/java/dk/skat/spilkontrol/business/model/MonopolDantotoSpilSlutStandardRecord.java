package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolDantotoSpilSlutStandardRecord extends AbstractMonopolDantotoStandardRecord{

	private double indskudSpilTillIndh;
	private double antalRaekkerTillIndh;
	private double gevinstPuljeBeloeb;
	private DateTime lukketForSpilDatoTid;
	private String lukketForSpilDatoTidString;
	private DateTime spilProduktFaktiskSlutDatoTid;
	private String spilProduktFaktiskSlutDatoTidString;
	
	private final Stack<GevinstkategorierOgGevinster> resultatDantotoListe = new Stack<GevinstkategorierOgGevinster>();
	private final Stack<ResultatGrundlag> resultatGrundlagListe = new Stack<ResultatGrundlag>();
	private final Stack<Vinder> vinderListe = new Stack<Vinder>();
	private final Stack<UdgaaedeHeste> udgaaedeHesteListe = new Stack<UdgaaedeHeste>();
	
	public final void addNewGevinstkategorierOgGevinster() {
		resultatDantotoListe.push(new GevinstkategorierOgGevinster());
	}

	public final void addResultatGrundlag() {
		resultatGrundlagListe.push(new ResultatGrundlag());
	}

	public final void addNewVinder() {
		vinderListe.push(new Vinder());
	}
	
	public final void addNewUdgaaedeHeste() {
		udgaaedeHesteListe.push(new UdgaaedeHeste());
	}
	
	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolDantotoSlutStruktur;
	}
	
	public double getIndskudSpilTillIndh() {
		return indskudSpilTillIndh;
	}

	public void setIndskudSpilTillIndh(double indskudSpilTillIndh) {
		this.indskudSpilTillIndh = indskudSpilTillIndh;
	}

	public double getAntalRaekkerTillIndh() {
		return antalRaekkerTillIndh;
	}

	public void setAntalRaekkerTillIndh(double antalRaekkerTillIndh) {
		this.antalRaekkerTillIndh = antalRaekkerTillIndh;
	}

	public double getGevinstPuljeBeloeb() {
		return gevinstPuljeBeloeb;
	}

	public void setGevinstPuljeBeloeb(double gevinstPuljeBeloeb) {
		this.gevinstPuljeBeloeb = gevinstPuljeBeloeb;
	}

	public DateTime getLukketForSpilDatoTid() {
		return lukketForSpilDatoTid;
	}

	public void setLukketForSpilDatoTid(DateTime lukketForSpilDatoTid) {
		this.lukketForSpilDatoTid = lukketForSpilDatoTid;
	}

	public String getLukketForSpilDatoTidString() {
		return lukketForSpilDatoTidString;
	}

	public void setLukketForSpilDatoTidString(String lukketForSpilDatoTidString) {
		this.lukketForSpilDatoTidString = lukketForSpilDatoTidString;
	}

	public DateTime getSpilProduktFaktiskSlutDatoTid() {
		return spilProduktFaktiskSlutDatoTid;
	}

	public void setSpilProduktFaktiskSlutDatoTid(
			DateTime spilProduktFaktiskSlutDatoTid) {
		this.spilProduktFaktiskSlutDatoTid = spilProduktFaktiskSlutDatoTid;
	}

	public String getSpilProduktFaktiskSlutDatoTidString() {
		return spilProduktFaktiskSlutDatoTidString;
	}

	public void setSpilProduktFaktiskSlutDatoTidString(
			String spilProduktFaktiskSlutDatoTidString) {
		this.spilProduktFaktiskSlutDatoTidString = spilProduktFaktiskSlutDatoTidString;
	}

	public Stack<GevinstkategorierOgGevinster> getResultatDantotoListe() {
		return resultatDantotoListe;
	}

	public Stack<ResultatGrundlag> getResultatGrundlagListe() {
		return resultatGrundlagListe;
	}

	public Stack<Vinder> getVinderListe() {
		return vinderListe;
	}

	public final Stack<UdgaaedeHeste> getUdgaaedeHesteListe() {
		return udgaaedeHesteListe;
	}

	public static class GevinstkategorierOgGevinster {
		
		private String gevinstPuljeIdentifikation;
		private long gevinstPuljeAntalGevinsterTillIndh;
		private double gevinstPuljeBeloebTillIndh;
		private double gevinstPuljeBeloebPerRaekke;
		
		private double gevinstPuljeTilfoejetBeloeb;
		private Double gevinstPuljeOverfoerselPrimo;
		private Double gevinstPuljeOverfoerselUltimo;
		
		public String getGevinstPuljeIdentifikation() {
			return gevinstPuljeIdentifikation;
		}
		public void setGevinstPuljeIdentifikation(String gevinstPuljeIdentifikation) {
			this.gevinstPuljeIdentifikation = gevinstPuljeIdentifikation;
		}
		public long getGevinstPuljeAntalGevinsterTillIndh() {
			return gevinstPuljeAntalGevinsterTillIndh;
		}
		public void setGevinstPuljeAntalGevinsterTillIndh(
				long gevinstPuljeAntalGevinsterTillIndh) {
			this.gevinstPuljeAntalGevinsterTillIndh = gevinstPuljeAntalGevinsterTillIndh;
		}
		public double getGevinstPuljeBeloebTillIndh() {
			return gevinstPuljeBeloebTillIndh;
		}
		public void setGevinstPuljeBeloebTillIndh(double gevinstPuljeBeloebTillIndh) {
			this.gevinstPuljeBeloebTillIndh = gevinstPuljeBeloebTillIndh;
		}
		public double getGevinstPuljeBeloebPerRaekke() {
			return gevinstPuljeBeloebPerRaekke;
		}
		public void setGevinstPuljeBeloebPerRaekke(double gevinstPuljeBeloebPerRaekke) {
			this.gevinstPuljeBeloebPerRaekke = gevinstPuljeBeloebPerRaekke;
		}
		public double getGevinstPuljeTilfoejetBeloeb() {
			return gevinstPuljeTilfoejetBeloeb;
		}
		public void setGevinstPuljeTilfoejetBeloeb(double gevinstPuljeTilfoejetBeloeb) {
			this.gevinstPuljeTilfoejetBeloeb = gevinstPuljeTilfoejetBeloeb;
		}
		public Double getGevinstPuljeOverfoerselPrimo() {
			return gevinstPuljeOverfoerselPrimo;
		}
		public void setGevinstPuljeOverfoerselPrimo(Double gevinstPuljeOverfoerselPrimo) {
			this.gevinstPuljeOverfoerselPrimo = gevinstPuljeOverfoerselPrimo;
		}
		public Double getGevinstPuljeOverfoerselUltimo() {
			return gevinstPuljeOverfoerselUltimo;
		}
		public void setGevinstPuljeOverfoerselUltimo(
				Double gevinstPuljeOverfoerselUltimo) {
			this.gevinstPuljeOverfoerselUltimo = gevinstPuljeOverfoerselUltimo;
		}
	}	
	
	public static class ResultatGrundlag {

		private String puljespilVinderRaekke;
			
		public final String getPuljespilVinderRaekke() {
			return puljespilVinderRaekke;
		}

		public final void setPuljespilVinderRaekke(String puljespilVinderRaekke) {
			this.puljespilVinderRaekke = puljespilVinderRaekke;
		}
	}
	
	public static class UdgaaedeHeste {
		
		private Long puljespilNoegleNummer;
		
		private Long dantotoLoebNummer;
		
		/**
		 * tekst lang type, max 500 char
		 */
		private String udgaaedeHeste;

		public final Long getPuljespilNoegleNummer() {
			return puljespilNoegleNummer;
		}

		public final void setPuljespilNoegleNummer(Long puljespilNoegleNummer) {
			this.puljespilNoegleNummer = puljespilNoegleNummer;
		}

		public final Long getDantotoLoebNummer() {
			return dantotoLoebNummer;
		}

		public final void setDantotoLoebNummer(Long dantotoLoebNummer) {
			this.dantotoLoebNummer = dantotoLoebNummer;
		}

		public final String getUdgaaedeHeste() {
			return udgaaedeHeste;
		}

		public final void setUdgaaedeHeste(String udgaaedeHeste) {
			this.udgaaedeHeste = udgaaedeHeste;
		}

	}
	
	public static class Vinder {
		private String spillerInformationIdentifikation;
		private String spilTransaktionIdentifikation;
		private Long raekkeNummer;
		private double spilGevinstSpil;

		public final String getSpillerInformationIdentifikation() {
			return spillerInformationIdentifikation;
		}

		public final void setSpillerInformationIdentifikation(
				String spillerInformationIdentifikation) {
			this.spillerInformationIdentifikation = spillerInformationIdentifikation;
		}

		public final String getSpilTransaktionIdentifikation() {
			return spilTransaktionIdentifikation;
		}

		public final void setSpilTransaktionIdentifikation(String spillerIdentifikation) {
			this.spilTransaktionIdentifikation = spillerIdentifikation;
		}

		public final Long getRaekkeNummer() {
			return raekkeNummer;
		}

		public final void setRaekkeNummer(Long raekkeNummer) {
			this.raekkeNummer = raekkeNummer;
		}

		public final double getSpilGevinstSpil() {
			return spilGevinstSpil;
		}

		public final void setSpilGevinstSpil(double spilGevinstFraSpil) {
			this.spilGevinstSpil = spilGevinstFraSpil;
		}
	}
}
