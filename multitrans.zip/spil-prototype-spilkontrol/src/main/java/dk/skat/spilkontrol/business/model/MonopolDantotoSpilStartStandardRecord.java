package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolDantotoSpilStartStandardRecord extends
AbstractMonopolDantotoStandardRecord {

	private double gevinstPuljeProcent;
	private DateTime spilForventetSlutDatoTid;
	private String spilForventetSlutDatoTidString;

	final private Stack<GenerelSpilNoegle> generelSpilNoegleListe = new Stack<GenerelSpilNoegle>();
	final private Stack<GevinstPulje> gevinstPuljeListe = new Stack<GevinstPulje>();

	public void addNewGenerelPuljeNoegle() {
		generelSpilNoegleListe.push(new GenerelSpilNoegle());
	}

	public void addNewGevinstPulje() {
		gevinstPuljeListe.push(new GevinstPulje());
	}
	
	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolDantotoStartStruktur;
	}

	public double getGevinstPuljeProcent() {
		return gevinstPuljeProcent;
	}

	public void setGevinstPuljeProcent(double gevinstPuljeProcent) {
		this.gevinstPuljeProcent = gevinstPuljeProcent;
	}

	public DateTime getSpilForventetSlutDatoTid() {
		return spilForventetSlutDatoTid;
	}

	public void setSpilForventetSlutDatoTid(DateTime spilForventetSlutDatoTid) {
		this.spilForventetSlutDatoTid = spilForventetSlutDatoTid;
	}

	public String getSpilForventetSlutDatoTidString() {
		return spilForventetSlutDatoTidString;
	}

	public void setSpilForventetSlutDatoTidString(
			String spilForventetSlutDatoTidString) {
		this.spilForventetSlutDatoTidString = spilForventetSlutDatoTidString;
	}

	public Stack<GenerelSpilNoegle> getGenerelSpilNoegleListe() {
		return generelSpilNoegleListe;
	}

	public Stack<GevinstPulje> getGevinstPuljeListe() {
		return gevinstPuljeListe;
	}



}
