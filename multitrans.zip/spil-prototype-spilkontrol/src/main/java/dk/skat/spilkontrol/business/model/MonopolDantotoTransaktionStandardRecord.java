package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;

import java.util.Stack;

public class MonopolDantotoTransaktionStandardRecord extends AbstractMonopolDantotoStandardRecord{

	private final Stack<SpillerOgKuponType> spillerOgKupon = new Stack<SpillerOgKuponType>();

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolDantotoTransaktionStruktur;
	}

	public final Stack<SpillerOgKuponType> getSpillerOgKuponListe() {
		return spillerOgKupon;
	}

	public final void addNewSpillerOgKupon() {
		spillerOgKupon.push(new SpillerOgKuponType());
	}


}
