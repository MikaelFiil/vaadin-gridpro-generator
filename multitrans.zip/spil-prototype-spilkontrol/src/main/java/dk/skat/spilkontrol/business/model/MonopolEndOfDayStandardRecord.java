package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolEndOfDayStandardRecord extends StandardRecord {

	private DateTime endOfDateRapportDato;
	private String endOfDateRapportDatoString;
	private String valuta;
	private Stack<SpilOpgoerelseType> spilOpgoerelses = new Stack<SpilOpgoerelseType>();
	private Double totalOmsaetning;
	
	public Stack<SpilOpgoerelseType> getSpilOpgoerelses(){
		return this.spilOpgoerelses;
	}
	
	public SpilOpgoerelseType getLastSpilOpgoerelse() {
		return spilOpgoerelses.peek();
	}
	
	public SpilOpgoerelseType addSpilOpgoerelse(SpilOpgoerelseType spilOpgoerelse) {
		return spilOpgoerelses.push(spilOpgoerelse);
	}
	
	public DateTime getEndOfDateRapportDato() {
		return endOfDateRapportDato;
	}

	public void setEndOfDateRapportDato(DateTime endOfDateRapportDato) {
		this.endOfDateRapportDato = endOfDateRapportDato;
	}

	public final String getEndOfDateRapportDatoString() {
		return endOfDateRapportDatoString;
	}

	public final void setEndOfDateRapportDatoString(
			String endOfDateRapportDatoString) {
		this.endOfDateRapportDatoString = endOfDateRapportDatoString;
	}

	public String getValuta() {
		return valuta;
	}

	public void setValuta(String valuta) {
		this.valuta = valuta;
	}

	public Double getTotalOmsaetning() {
		return totalOmsaetning;
	}

	public void setTotalOmsaetning(Double totalOmsaetning) {
		this.totalOmsaetning = totalOmsaetning;
	}


	public class SpilOpgoerelseType {
		private String spilKategoryNavn;
		private String spilProduktNavn;
		private String spilProduktIdentifikation;
		private String dantotoKategoriNavn;
		
		private Long endOfDayRapportAntalSpil;
		private Double endOfDayRapportIndskud;
		private Double endOfDayRapportGevinster;
		private Double endOfDayRapportGevinsterFoerAfgift;
		
		public String getSpilKategoryNavn() {
			return spilKategoryNavn;
		}
		public void setSpilKategoryNavn(String spilKategoryNavn) {
			this.spilKategoryNavn = spilKategoryNavn;
		}
		public Long getEndOfDayRapportAntalSpil() {
			return endOfDayRapportAntalSpil;
		}
		public void setEndOfDayRapportAntalSpil(Long endOfDayRapportAntalSpil) {
			this.endOfDayRapportAntalSpil = endOfDayRapportAntalSpil;
		}
		public final String getSpilProduktNavn() {
			return spilProduktNavn;
		}
		public final void setSpilProduktNavn(String spilProduktNavn) {
			this.spilProduktNavn = spilProduktNavn;
		}
		public final String getSpilProduktIdentifikation() {
			return spilProduktIdentifikation;
		}
		public final void setSpilProduktIdentifikation(String spilProduktIdentifikation) {
			this.spilProduktIdentifikation = spilProduktIdentifikation;
		}
		public final Double getEndOfDayRapportIndskud() {
			return endOfDayRapportIndskud;
		}
		public final void setEndOfDayRapportIndskud(Double endOfDayRapportIndskud) {
			this.endOfDayRapportIndskud = endOfDayRapportIndskud;
		}
		public final void setEndOfDayRapportGevinster(Double endOfDayRapportGevinster) {
			this.endOfDayRapportGevinster = endOfDayRapportGevinster;
		}
		public final Double getEndOfDayRapportGevinster() {
			return this.endOfDayRapportGevinster;
		}
		public final void setEndOfDayRapportGevinsterFoerAfgift(Double endOfDayRapportGevinsterFoerAfgift) {
			this.endOfDayRapportGevinsterFoerAfgift = endOfDayRapportGevinsterFoerAfgift;
		}
		public final Double getEndOfDayRapportGevinsterFoerAfgift() {
			return this.endOfDayRapportGevinsterFoerAfgift;
		}
		public final String getDantotoKategoriNavn() {
			return dantotoKategoriNavn;
		}
		public final void setDantotoKategoriNavn(String dantotoKategoriNavn) {
			this.dantotoKategoriNavn = dantotoKategoriNavn;
		}
		@Override
		public String toString() {
			return "SpilOpgoerelse [spilKategoryNavn=" + spilKategoryNavn
					+ ", spilProduktNavn=" + spilProduktNavn
					+ ", spilProduktIdentifikation="
					+ spilProduktIdentifikation + ", dantotoKategoriNavn="
					+ dantotoKategoriNavn + ", endOfDayRapportAntalSpil="
					+ endOfDayRapportAntalSpil + ", endOfDayRapportIndskud="
					+ endOfDayRapportIndskud + ", endOfDayRapportGevinster="
					+ endOfDayRapportGevinster
					+ ", endOfDayRapportGevinsterFoerAfgift="
					+ endOfDayRapportGevinsterFoerAfgift + "]";
		}
		
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolEndOfDayRapportStruktur;
	}

}
