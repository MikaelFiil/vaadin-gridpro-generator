package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.datafile.Dimensions;
import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolFastOddsTransaktionStrukturRecord extends AbstractGameStandardRecord {

	private Stack<TransaktionType> transactions = new Stack<TransaktionType>();
	
	public Stack<TransaktionType> getTransaktions() {
		return this.transactions;
	}
	
	public TransaktionType getLastTransaction() {
		return transactions.peek();
	}
	
	public TransaktionType addTransaction(TransaktionType transaction) {
		return transactions.push(transaction);
	}

	public class TransaktionType {
		private Double odds;
		private String spillerInformationIdentifikation;
		private String spilIdentifikation; //spilTransaktionIdentifikation
		private DateTime spilKoebDatoTid;
		private DateTime spilForventetSlutDatoTid;
		private String spilKoebDatoTidString;
		private String spilForventetSlutDatoTidString;
		private String spilSalgskanal;
		private String spilTerminalIdentifikation;
		private String spilProduktNavn;
		private String spilProduktIdentifikation;
		
		//Danish word for homepage
		private String spilHjemmeside;
		
		private Double spilIndskud;
		private String valutaOplysningKode;
		private Boolean spilAnnullering; 
		private DateTime spilAnnulleringDatoTid;
		private String spilAnnulleringDatoTidString;

		public Double getOdds() {
			return odds;
		}
		public void setOdds(Double odds) {
			this.odds = odds;
		}

		public String getSpillerInformationIdentifikation() {
			return spillerInformationIdentifikation;
		}
		public void setSpillerInformationIdentifikation(
				String spillerInformationIdentifikation) {
			this.spillerInformationIdentifikation = spillerInformationIdentifikation;
		}
		public String getSpilTransaktionIdentifikation() {
			return spilIdentifikation;
		}
		public void setSpilTransaktionIdentifikation(String spilIdentifikation) {
			this.spilIdentifikation = spilIdentifikation;
		}
		public DateTime getSpilKoebDatoTid() {
			return spilKoebDatoTid;
		}
		public void setSpilKoebDatoTid(DateTime spilKoebDatoTid) {
			this.spilKoebDatoTid = spilKoebDatoTid;
		}
		public DateTime getSpilForventetSlutDatoTid() {
			return spilForventetSlutDatoTid;
		}
		public void setSpilForventetSlutDatoTid(DateTime spilForventetSlutDatoTid) {
			this.spilForventetSlutDatoTid = spilForventetSlutDatoTid;
		}
		public String getSpilSalgskanal() {
			return spilSalgskanal;
		}
		public void setSpilSalgskanal(String spilSalgskanal) {
			this.spilSalgskanal = spilSalgskanal;
		}
		public String getSpilTerminalIdentifikation() {
			return spilTerminalIdentifikation;
		}
		public void setSpilTerminalIdentifikation(String spilTerminalIdentifikation) {
			this.spilTerminalIdentifikation = spilTerminalIdentifikation;
		}
		public Double getSpilIndskud() {
			return spilIndskud;
		}
		public void setSpilIndskud(Double spilIndskud) {
			this.spilIndskud = spilIndskud;
		}
		public String getValutaOplysningKode() {
			return valutaOplysningKode;
		}
		public void setValutaOplysningKode(String valutaOplysningKode) {
			this.valutaOplysningKode = valutaOplysningKode;
		}
		public Boolean getSpilAnnullering() {
			return spilAnnullering;
		}
		public void setSpilAnnullering(Boolean spilAnnullering) {
			this.spilAnnullering = spilAnnullering;
		}
		public DateTime getSpilAnnulleringDatoTid() {
			return spilAnnulleringDatoTid;
		}
		public void setSpilAnnulleringDatoTid(DateTime spilAnnulleringDatoTid) {
			this.spilAnnulleringDatoTid = spilAnnulleringDatoTid;
		}
		public String getSpilHjemmeside() {
			return spilHjemmeside;
		}
		public void setSpilHjemmeside(String hjemmeside) {
			this.spilHjemmeside = hjemmeside;
		}
		public final String getSpilKoebDatoTidString() {
			return spilKoebDatoTidString;
		}
		public final void setSpilKoebDatoTidString(String spilKoebDatoTidString) {
			this.spilKoebDatoTidString = spilKoebDatoTidString;
		}
		public final String getSpilForventetSlutDatoTidString() {
			return spilForventetSlutDatoTidString;
		}
		public final void setSpilForventetSlutDatoTidString(
				String spilForventetSlutDatoTidString) {
			this.spilForventetSlutDatoTidString = spilForventetSlutDatoTidString;
		}
		public final String getSpilAnnulleringDatoTidString() {
			return spilAnnulleringDatoTidString;
		}
		public final void setSpilAnnulleringDatoTidString(
				String spilAnnulleringDatoTidString) {
			this.spilAnnulleringDatoTidString = spilAnnulleringDatoTidString;
		}

		public String getSpilProduktNavn() { return spilProduktNavn; }
		public void setSpilProduktNavn(String spilProduktNavn) {
			this.spilProduktNavn = spilProduktNavn;
		}

		public String getSpilProduktIdentifikation() { return spilProduktIdentifikation; }
		public void setSpilProduktIdentifikation(String spilProduktIdentifikation) {
			this.spilProduktIdentifikation = spilProduktIdentifikation;
		}

	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolVirtuelFastOddsTransaktionStruktur;
	}
	
	@Override
	public void collectDimensions(Dimensions cache) {
		super.collectDimensions(cache);
		
		for (TransaktionType t : transactions) {
			cache.addSession(t.getSpilTransaktionIdentifikation());
			cache.addTransaction(t.getSpilTransaktionIdentifikation(), t.spilAnnullering);
			cache.addDate(t.spilAnnulleringDatoTid);
			cache.addDate(t.spilForventetSlutDatoTid);
			cache.addDate(t.spilKoebDatoTid);
			cache.addValuta(t.valutaOplysningKode);
			cache.addSpiller(t.spillerInformationIdentifikation);
		}
	}
}
