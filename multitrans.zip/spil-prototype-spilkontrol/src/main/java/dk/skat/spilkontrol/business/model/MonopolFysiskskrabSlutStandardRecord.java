package dk.skat.spilkontrol.business.model;


import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

public class MonopolFysiskskrabSlutStandardRecord extends AbstractGameStandardRecord {

	private DateTime faktiskSlutDatoTid;
	private String faktiskSlutDatoTidString;
	private Double indskud;
	private Double gevinst;
	private Long antalLodder;
	private Long antalGevinster;
	private Double tilbagebetalingProcent;
	private String valutaOplysningKode;
	
	private Long returneretStjaaletAntalBlokke;
	private Long returneretStjaaletAntalLodder;
	private Double returneretStjaaletIndskud;

	public DateTime getFaktiskSlutDatoTid() {
		return faktiskSlutDatoTid;
	}

	public void setFaktiskSlutDatoTid(DateTime faktiskSlutDatoTid) {
		this.faktiskSlutDatoTid = faktiskSlutDatoTid;
	}

	public String getFaktiskSlutDatoTidString() {
		return faktiskSlutDatoTidString;
	}

	public void setFaktiskSlutDatoTidString(String faktiskSlutDatoTidString) {
		this.faktiskSlutDatoTidString = faktiskSlutDatoTidString;
	}

	public Double getIndskud() {
		return indskud;
	}

	public void setIndskud(Double indskud) {
		this.indskud = indskud;
	}

	public Double getGevinst() {
		return gevinst;
	}

	public void setGevinst(Double gevinst) {
		this.gevinst = gevinst;
	}

	public Long getAntalLodder() {
		return antalLodder;
	}

	public void setAntalLodder(Long antalLodder) {
		this.antalLodder = antalLodder;
	}

	public Long getAntalGevinster() {
		return antalGevinster;
	}

	public void setAntalGevinster(Long antalGevinster) {
		this.antalGevinster = antalGevinster;
	}

	public Double getTilbagebetalingProcent() {
		return tilbagebetalingProcent;
	}

	public void setTilbagebetalingProcent(Double tilbagebetalingProcent) {
		this.tilbagebetalingProcent = tilbagebetalingProcent;
	}

	public String getValutaOplysningKode() {
		return valutaOplysningKode;
	}

	public void setValutaOplysningKode(String valuta) {
		this.valutaOplysningKode = valuta;
	}

	public Long getReturneretStjaaletAntalBlokke() {
		return returneretStjaaletAntalBlokke;
	}

	public void setReturneretStjaaletAntalBlokke(Long returneretStjaaletAntalBlokke) {
		this.returneretStjaaletAntalBlokke = returneretStjaaletAntalBlokke;
	}

	public Long getReturneretStjaaletAntalLodder() {
		return returneretStjaaletAntalLodder;
	}

	public void setReturneretStjaaletAntalLodder(Long returneretStjaaletAntalLodder) {
		this.returneretStjaaletAntalLodder = returneretStjaaletAntalLodder;
	}

	public Double getReturneretStjaaletIndskud() {
		return returneretStjaaletIndskud;
	}

	public void setReturneretStjaaletIndskud(Double returneretStjaaletIndskud) {
		this.returneretStjaaletIndskud = returneretStjaaletIndskud;
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolFysiskSkrabSlutStruktur;
	}

}
