package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolFysiskskrabStartStandardRecord extends AbstractGameStandardRecord {

	private Long produktNummer;
	private Double teoretiskTilbagebetalingProcent;
	private Long antalLodder;
	private Double lodPris;
	private DateTime foersteSalgsdato;
	private String foersteSalgsdatoString;
	private DateTime sidsteSalgsdato;
	private String sidsteSalgsdatoString;
	private DateTime foraeldelsedato;
	private String foraeldelsedatoString;
	private Long modulAntalTotal;
	private Long antalBlokke;
	
	private Stack<GevinstStruktur> gevinstStruktur = new Stack<GevinstStruktur>();

	public Stack<GevinstStruktur> getSpilGevinstStrukturStack() {
		return this.gevinstStruktur;
	}
	
	public GevinstStruktur getLastGevinstStruktur() {
		return gevinstStruktur.peek();
	}
	
	public GevinstStruktur addGevinstStruktur(GevinstStruktur element) {
		return gevinstStruktur.push(element);
	}
	
	public final Double getTeoretiskTilbagebetalingProcent() {
		return teoretiskTilbagebetalingProcent;
	}

	public final void setTeoretiskTilbagebetalingProcent(
			Double teoretiskTilbagebetalingProcent) {
		this.teoretiskTilbagebetalingProcent = teoretiskTilbagebetalingProcent;
	}
	
	public String getFoersteSalgsdatoString() {
		return foersteSalgsdatoString;
	}

	public void setFoersteSalgsdatoString(String foersteSalgsdatoString) {
		this.foersteSalgsdatoString = foersteSalgsdatoString;
	}

	public String getSidsteSalgsdatoString() {
		return sidsteSalgsdatoString;
	}

	public void setSidsteSalgsdatoString(String sidsteSalgsdatoString) {
		this.sidsteSalgsdatoString = sidsteSalgsdatoString;
	}

	public String getForaeldelsedatoString() {
		return foraeldelsedatoString;
	}

	public void setForaeldelsedatoString(String foraeldelsedatoString) {
		this.foraeldelsedatoString = foraeldelsedatoString;
	}
	
	public Long getProduktNummer() {
		return produktNummer;
	}

	public void setProduktNummer(Long produktNummer) {
		this.produktNummer = produktNummer;
	}

	public Long getAntalLodder() {
		return antalLodder;
	}

	public void setAntalLodder(Long antalLodder) {
		this.antalLodder = antalLodder;
	}

	public Double getLodPris() {
		return lodPris;
	}

	public void setLodPris(Double lodPris) {
		this.lodPris = lodPris;
	}

	public DateTime getFoersteSalgsdato() {
		return foersteSalgsdato;
	}
	
	public void setFoersteSalgsdato(DateTime foersteSalgsDato) {
		this.foersteSalgsdato = foersteSalgsDato;
	}
	
	public DateTime getSidsteSalgsdato() {
		return sidsteSalgsdato;
	}

	public void setSidsteSalgsdato(DateTime sidsteSalgsdato) {
		this.sidsteSalgsdato = sidsteSalgsdato;
	}

	public DateTime getForaeldelsedato() {
		return foraeldelsedato;
	}
	
	public void setForaeldelsedato(DateTime foraeldelsedato) {
		this.foraeldelsedato = foraeldelsedato;
	}

	public Long getModulAntalTotal() {
		return modulAntalTotal;
	}

	public void setModulAntalTotal(Long modulAntalTotal) {
		this.modulAntalTotal = modulAntalTotal;
	}

	public Long getAntalBlokke() {
		return antalBlokke;
	}

	public void setAntalBlokke(Long antalBlokke) {
		this.antalBlokke = antalBlokke;
	}

	public Stack<GevinstStruktur> getGevinstStruktur() {
		return gevinstStruktur;
	}

	public void setGevinstStruktur(Stack<GevinstStruktur> gevinstStruktur) {
		this.gevinstStruktur = gevinstStruktur;
	}

	public class GevinstStruktur {

		private Long gevinstStamdataNummer;
		private String gevinstStamdataBeskrivelse;
		private Double gevinstStamdataBeloeb;
		private Long gevinstStamdataAntal;
		private String valuta;

		public final Long getGevinstStamdataNummer() {
			return gevinstStamdataNummer;
		}

		public final void setGevinstStamdataNummer(Long gevinstStamdataNummer) {
			this.gevinstStamdataNummer = gevinstStamdataNummer;
		}

		public final String getGevinstStamdataBeskrivelse() {
			return gevinstStamdataBeskrivelse;
		}

		public final void setGevinstStamdataBeskrivelse(
				String gevinstStamdataBeskrivelse) {
			this.gevinstStamdataBeskrivelse = gevinstStamdataBeskrivelse;
		}

		public final Double getGevinstStamdataBeloeb() {
			return gevinstStamdataBeloeb;
		}

		public final void setGevinstStamdataBeloeb(Double gevinstStamdataBeloeb) {
			this.gevinstStamdataBeloeb = gevinstStamdataBeloeb;
		}

		public final Long getGevinstStamdataAntal() {
			return gevinstStamdataAntal;
		}

		public final void setGevinstStamdataAntal(Long gevinstStamdataAntal) {
			this.gevinstStamdataAntal = gevinstStamdataAntal;
		}

		public String getValuta() {
			return valuta;
		}

		public void setValuta(String valuta) {
			this.valuta = valuta;
		}

	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolFysiskSkrabStartStruktur;
	}

}
