package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolFysiskskrabTransaktionStandardRecord extends AbstractGameStandardRecord {
	
	private final Stack<BlokAktiveringType> blokAktivering = new Stack<BlokAktiveringType>();

	public final Stack<BlokAktiveringType> getBlokAktivering() {
		return blokAktivering;
	}

	public final void addNewBlokAktivering() {
		blokAktivering.push(new BlokAktiveringType());
	}

	private final Stack<FysiskSkrabGevinstsoegningType> fysiskSkrabGevinstsoegning = new Stack<FysiskSkrabGevinstsoegningType>();

	public final Stack<FysiskSkrabGevinstsoegningType> getFysiskSkrabGevinstsoegning() {
		return fysiskSkrabGevinstsoegning;
	}

	public final void addNewFysiskSkrabGevinstsoegning() {
		fysiskSkrabGevinstsoegning.push(new FysiskSkrabGevinstsoegningType());
	}

	public MonopolFysiskskrabTransaktionStandardRecord() {
	}
	
	public static class BlokAktiveringType {

		private DateTime blokAktiveringDato;
		private String blokAktiveringDatoString;
		private Double blokIndskud;
		private Long antalLodder;
		private String valutaOplysningKode;

		public DateTime getBlokAktiveringDato() {
			return blokAktiveringDato;
		}

		public void setBlokAktiveringDato(DateTime blokAktiveringDato) {
			this.blokAktiveringDato = blokAktiveringDato;
		}

		public String getBlokAktiveringDatoString() {
			return blokAktiveringDatoString;
		}

		public void setBlokAktiveringDatoString(String blokAktiveringDatoString) {
			this.blokAktiveringDatoString = blokAktiveringDatoString;
		}

		public Double getBlokIndskud() {
			return blokIndskud;
		}

		public void setBlokIndskud(Double blokIndskud) {
			this.blokIndskud = blokIndskud;
		}

		public Long getAntalLodder() {
			return antalLodder;
		}

		public void setAntalLodder(Long antalLodder) {
			this.antalLodder = antalLodder;
		}

		public String getValutaOplysningKode() {
			return valutaOplysningKode;
		}

		public void setValutaOplysningKode(String valutaOplysningsKode) {
			this.valutaOplysningKode = valutaOplysningsKode;
		}
		
	}
	
	public static class FysiskSkrabGevinstsoegningType {
		
		private String spilTransaktionIdentifikation;
		private DateTime spilIndloesningDatoTid;
		private String spilIndloesningDatoTidString;
		private Double spilGevinst;
		private Long monopolGevinstStamDataNummer;
		private String valutaOplysningKode;
		
		private String spilTerminalIdentifikation;
		private String spilHjemmeside;

		public String getSpilTransaktionIdentifikation() {
			return spilTransaktionIdentifikation;
		}

		public void setSpilTransaktionIdentifikation(
				String spilTransaktionIdentifikation) {
			this.spilTransaktionIdentifikation = spilTransaktionIdentifikation;
		}

		public DateTime getSpilIndloesningDatoTid() {
			return spilIndloesningDatoTid;
		}

		public void setSpilIndloesningDatoTid(DateTime spilIndloesningDatoTid) {
			this.spilIndloesningDatoTid = spilIndloesningDatoTid;
		}

		public String getSpilIndloesningDatoTidString() {
			return spilIndloesningDatoTidString;
		}

		public void setSpilIndloesningDatoTidString(String spilIndloesningDatoTidString) {
			this.spilIndloesningDatoTidString = spilIndloesningDatoTidString;
		}

		public Double getSpilGevinst() {
			return spilGevinst;
		}

		public void setSpilGevinst(Double spilGevinst) {
			this.spilGevinst = spilGevinst;
		}

		public Long getGevinstStamdataNummer() {
			return monopolGevinstStamDataNummer;
		}

		public void setGevinstStamdataNummer(Long monopolGevinstStamDataNummer) {
			this.monopolGevinstStamDataNummer = monopolGevinstStamDataNummer;
		}

		public String getValutaOplysningKode() {
			return valutaOplysningKode;
		}

		public void setValutaOplysningKode(String valutaOplysningKode) {
			this.valutaOplysningKode = valutaOplysningKode;
		}

		public String getSpilTerminalIdentifikation() {
			return spilTerminalIdentifikation;
		}

		public void setSpilTerminalIdentifikation(String spilTerminalIdentifikation) {
			this.spilTerminalIdentifikation = spilTerminalIdentifikation;
		}

		public String getSpilHjemmeside() {
			return spilHjemmeside;
		}

		public void setSpilHjemmeside(String spilHjemmeside) {
			this.spilHjemmeside = spilHjemmeside;
		}

	}
	
	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolFysiskSkrabTransaktionStruktur;
	}
	
}
