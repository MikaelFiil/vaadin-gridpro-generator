package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;

import java.util.Stack;

public class MonopolLandeDataStandardRecord extends AbstractGameStandardRecord {
	
	final private Stack<LandedataPuljeListe> landedataPuljeListe = new Stack<LandedataPuljeListe>();
	
	// LandedataOnsdagslotto
    private Long onsdagslottoRaekkerTotal;
    private Long onsdagslottoRaekkerSuperpulje;
	private Long onsdagslottoFoerstePraemieOevrige;
    private String onsdagslottoLandeDataLande;
	
    // LandedataEurojackpot
	private Double eurojackpotOmsaetningTotal;
	private Double eurojackpotDataBoosterGaranti;
	private Double eurojackpotBoosterSpecial;
    private String eurojackpotValutaOplysningKode;
    
    private boolean seenLandedataOnsdagslotto;
    private boolean seenLandedataEurojackpot;
    private boolean seenLandedataPuljeListe;
    
	public final Long getOnsdagslottoRaekkerTotal() {
		return onsdagslottoRaekkerTotal;
	}

	public final void setOnsdagslottoRaekkerTotal(Long onsdagslottoRaekkerTotal) {
		this.onsdagslottoRaekkerTotal = onsdagslottoRaekkerTotal;
	}

	public final Long getOnsdagslottoRaekkerSuperpulje() {
		return onsdagslottoRaekkerSuperpulje;
	}

	public final void setOnsdagslottoRaekkerSuperpulje(
			Long onsdagslottoRaekkerSuperpulje) {
		this.onsdagslottoRaekkerSuperpulje = onsdagslottoRaekkerSuperpulje;
	}

	public final Long getOnsdagslottoFoerstePraemieOevrige() {
		return onsdagslottoFoerstePraemieOevrige;
	}

	public final void setOnsdagslottoFoerstePraemieOevrige(
			Long onsdagslottoFoerstePraemieOevrige) {
		this.onsdagslottoFoerstePraemieOevrige = onsdagslottoFoerstePraemieOevrige;
	}

	public final String getOnsdagslottoLandeDataLande() {
		return onsdagslottoLandeDataLande;
	}

	public final void setOnsdagslottoLandeDataLande(
			String onsdagslottoLandeDataLande) {
		this.onsdagslottoLandeDataLande = onsdagslottoLandeDataLande;
	}

	public final Double getEurojackpotOmsaetningTotal() {
		return eurojackpotOmsaetningTotal;
	}

	public final void setEurojackpotOmsaetningTotal(Double eurojackpotOmsaetningTotal) {
		this.eurojackpotOmsaetningTotal = eurojackpotOmsaetningTotal;
	}

	public final Double getEurojackpotDataBoosterGaranti() {
		return eurojackpotDataBoosterGaranti;
	}

	public final void setEurojackpotDataBoosterGaranti(
			Double eurojackpotDataBoosterGaranti) {
		this.eurojackpotDataBoosterGaranti = eurojackpotDataBoosterGaranti;
	}

	public final Double getEurojackpotBoosterSpecial() {
		return eurojackpotBoosterSpecial;
	}

	public final void setEurojackpotBoosterSpecial(Double eurojackpotBoosterSpecial) {
		this.eurojackpotBoosterSpecial = eurojackpotBoosterSpecial;
	}

	public final String getEurojackpotValutaOplysningKode() {
		return eurojackpotValutaOplysningKode;
	}

	public final void setEurojackpotValutaOplysningKode(
			String eurojackpotValutaOplysningKode) {
		this.eurojackpotValutaOplysningKode = eurojackpotValutaOplysningKode;
	}

	public final boolean isSeenLandedataOnsdagslotto() {
		return seenLandedataOnsdagslotto;
	}

	public final void setSeenLandedataOnsdagslotto(boolean seenLandedataOnsdagslotto) {
		this.seenLandedataOnsdagslotto = seenLandedataOnsdagslotto;
	}

	public final boolean isSeenLandedataEurojackpot() {
		return seenLandedataEurojackpot;
	}

	public final void setSeenLandedataEurojackpot(boolean seenLandedataEurojackpot) {
		this.seenLandedataEurojackpot = seenLandedataEurojackpot;
	}

	public final boolean isSeenLandedataPuljeListe() {
		return seenLandedataPuljeListe;
	}

	public final void setSeenLandedataPuljeListe(boolean seenLandedataPuljeListe) {
		this.seenLandedataPuljeListe = seenLandedataPuljeListe;
	}

	public final Stack<LandedataPuljeListe> getLandeDataPuljeListe() {
		return landedataPuljeListe;
	}

	public final void addNewLandedataPuljeListe() {
		landedataPuljeListe.add(new LandedataPuljeListe());
	}
	
	public static class LandedataPuljeListe {
		
		private String gevinstPuljeIdentifikation;
		private String gevinstPuljeBeskrivelse;
		private Long gevinstPuljeAntalGevinsterTotal;
		private Double gevinstPuljeTilfoejetBeloeb;
		private Double gevinstPuljeOverfoerselPrimo;
		private Double gevinstPuljeOverfoerselUltimo;
		private String valutaOplysningKode;

		public final String getGevinstPuljeIdentifikation() {
			return gevinstPuljeIdentifikation;
		}

		public final void setGevinstPuljeIdentifikation(
				String gevinstPuljeIdentifikation) {
			this.gevinstPuljeIdentifikation = gevinstPuljeIdentifikation;
		}

		public final String getGevinstPuljeBeskrivelse() {
			return gevinstPuljeBeskrivelse;
		}

		public final void setGevinstPuljeBeskrivelse(String gevinstPuljeBeskrivelse) {
			this.gevinstPuljeBeskrivelse = gevinstPuljeBeskrivelse;
		}
		
		/**
		 * missing value is allowed. It will then return null.
		 * 
		 * @return
		 */
		public final Long getGevinstPuljeAntalGevinsterTotal() {
			return gevinstPuljeAntalGevinsterTotal;
		}

		public final void setGevinstPuljeAntalGevinsterTotal(Long gevinstPuljeAntalGevinsterTotal) {
			this.gevinstPuljeAntalGevinsterTotal = gevinstPuljeAntalGevinsterTotal;
		}

		public final Double getGevinstPuljeTilfoejetBeloeb() {
			return gevinstPuljeTilfoejetBeloeb;
		}

		public final void setGevinstPuljeTilfoejetBeloeb(Double gevinstPuljeTilfoejetBeloeb) {
			this.gevinstPuljeTilfoejetBeloeb = gevinstPuljeTilfoejetBeloeb;
		}

		public final Double getGevinstPuljeOverfoerselPrimo() {
			return gevinstPuljeOverfoerselPrimo;
		}

		public final void setGevinstPuljeOverfoerselPrimo(Double gevinstPuljeOverfoerselPrimo) {
			this.gevinstPuljeOverfoerselPrimo = gevinstPuljeOverfoerselPrimo;
		}

		public final Double getGevinstPuljeOverfoerselUltimo() {
			return gevinstPuljeOverfoerselUltimo;
		}

		public final void setGevinstPuljeOverfoerselUltimo(Double gevinstPuljeOverfoerselUltimo) {
			this.gevinstPuljeOverfoerselUltimo = gevinstPuljeOverfoerselUltimo;
		}

		public final String getValutaOplysningKode() {
			return valutaOplysningKode;
		}

		public final void setValutaOplysningKode(String valutaOplysningKode) {
			this.valutaOplysningKode = valutaOplysningKode;
		}


		@Override
		public String toString() {
			return "LandedataPuljeListe [gevinstPuljeIdentifikation="
					+ gevinstPuljeIdentifikation + ", gevinstPuljeBeskrivelse="
					+ gevinstPuljeBeskrivelse
					+ ", gevinstPuljeAntalGevinsterTotal="
					+ gevinstPuljeAntalGevinsterTotal
					+ ", gevinstPuljeTilfoejetBeloeb="
					+ gevinstPuljeTilfoejetBeloeb
					+ ", gevinstPuljeOverfoerselPrimo="
					+ gevinstPuljeOverfoerselPrimo
					+ ", gevinstPuljeOverfoerselUltimo="
					+ gevinstPuljeOverfoerselUltimo + ", valutaOplysningKode="
					+ valutaOplysningKode + "]";
		}
	
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolLandeDataStruktur;
	}
	
}
