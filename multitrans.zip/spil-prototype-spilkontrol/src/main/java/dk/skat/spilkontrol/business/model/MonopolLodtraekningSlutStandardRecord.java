package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolLodtraekningSlutStandardRecord extends AbstractGameStandardRecord {

	/**
	 * used to save state - has Vinder been seen?
	 */
	private boolean insideVinder; 
	
	private final Stack<TilfaeldighedGenerator> tilfaeldighedGeneratorListe = new Stack<TilfaeldighedGenerator>();

	private final Stack<Vinder> vinderListe = new Stack<Vinder>();
	
	private final Stack<ResultatGrundlag> resultatGrundlagListe = new Stack<ResultatGrundlag>();
	
	private DateTime spilProduktFaktiskSlutDatoTid;

	private String spilProduktFaktiskSlutDatoTidString;

	public MonopolLodtraekningSlutStandardRecord() {
	}
	
	public final void addResultatGrundlag() {
		resultatGrundlagListe.push(new ResultatGrundlag());
	}

	public final void addNewVinder() {
		vinderListe.push(new Vinder());
	}

	public final void addNewTilfaeldighedGenerator() {
		tilfaeldighedGeneratorListe.push(new TilfaeldighedGenerator());
	}

	public Stack<ResultatGrundlag> getResultatGrundlagListe() {
		return resultatGrundlagListe;
	}

	public Stack<TilfaeldighedGenerator> getTilfaeldighedGeneratorListe() {
		return tilfaeldighedGeneratorListe;
	}

	public final Stack<Vinder> getVinderListe() {
		return vinderListe;
	}

	public final DateTime getSpilProduktFaktiskSlutDatoTid() {
		return spilProduktFaktiskSlutDatoTid;
	}

	public final void setSpilProduktFaktiskSlutDatoTid(DateTime spilTypeFaktiskSlutDatoTid) {
		this.spilProduktFaktiskSlutDatoTid = spilTypeFaktiskSlutDatoTid;
	}
	
	public final String getSpilProduktFaktiskSlutDatoTidString() {
		return spilProduktFaktiskSlutDatoTidString;
	}

	public final void setSpilProduktFaktiskSlutDatoTidString(
			String spilProduktFaktiskSlutDatoTidString) {
		this.spilProduktFaktiskSlutDatoTidString = spilProduktFaktiskSlutDatoTidString;
	}


	public static class ResultatGrundlag {
		private Long lodtraekningVinderTal;

		public final Long getLodtraekningVinderTal() {
			return lodtraekningVinderTal;
		}

		public final void setLodtraekningVinderTal(Long lodtraekningVinderTal) {
			this.lodtraekningVinderTal = lodtraekningVinderTal;
		}

	}
	
	public static class TilfaeldighedGenerator {
		private String tilfaeldighedGeneratorIdentifikation;
		
		private String tilfaeldighedGeneratorSoftwareId;
		
		private String ansvarlig;
		
		public String getTilfaeldighedGeneratorIdentifikation() {
			return tilfaeldighedGeneratorIdentifikation;
		}

		public void setTilfaeldighedGeneratorIdentifikation(String tilfaeldighedGeneratorIdentifikation) {
			this.tilfaeldighedGeneratorIdentifikation = tilfaeldighedGeneratorIdentifikation;
		}

		public String getTilfaeldighedGeneratorSoftwareId() {
			return tilfaeldighedGeneratorSoftwareId;
		}

		public void setTilfaeldighedGeneratorSoftwareId(String tilfaeldighedGeneratorSoftwareId) {
			this.tilfaeldighedGeneratorSoftwareId = tilfaeldighedGeneratorSoftwareId;
		}
		

		public final String getAnsvarlig() {
			return ansvarlig;
		}

		public final void setAnsvarlig(String ansvarlig) {
			this.ansvarlig = ansvarlig;
		}

	}

	public static class Vinder {

		private String spilTransaktionIdentifikation;
		private Long vinderTal;
		public final String getSpilTransaktionIdentifikation() {
			return spilTransaktionIdentifikation;
		}
		public final void setSpilTransaktionIdentifikation(
				String spilTransaktionIdentifikation) {
			this.spilTransaktionIdentifikation = spilTransaktionIdentifikation;
		}
		public final Long getVinderTal() {
			return vinderTal;
		}
		public final void setVinderTal(Long vinderTal) {
			this.vinderTal = vinderTal;
		}
		
	}
	
	public final boolean isInsideVinder() {
		return insideVinder;
	}

	public final void setInsideVinder(boolean insideVinder) {
		this.insideVinder = insideVinder;
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolLodtraekningSlutStruktur;
	}
	
}
