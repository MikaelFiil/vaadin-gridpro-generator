package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolLodtraekningStartStandardRecord extends AbstractGameStandardRecord {
	
	/**
	 * used to save state - has OverordnetSpilInformation been seen?
	 */
	private boolean overordnet; 
	
	private DateTime spilForventetSlutDatoTid;
	private String spilForventetSlutDatoTidString;
	private String overordnetSpilKategoriNavn;
	private String overordnetSpilProduktNavn;
	private String overordnetSpilProduktIdentifikation;
	
	final private Stack<Kandidat> kandidatListe = new Stack<Kandidat>();

	public void addNewKandidat() {
		kandidatListe.push(new Kandidat());
	}
	
	public final DateTime getSpilForventetSlutDatoTid() {
		return spilForventetSlutDatoTid;
	}

	public final void setSpilForventetSlutDatoTid(DateTime spilForventetSlutDatoTid) {
		this.spilForventetSlutDatoTid = spilForventetSlutDatoTid;
	}
	
	public final String getSpilForventetSlutDatoTidString() {
		return spilForventetSlutDatoTidString;
	}

	public final void setSpilForventetSlutDatoTidString(
			String spilForventetSlutDatoTidString) {
		this.spilForventetSlutDatoTidString = spilForventetSlutDatoTidString;
	}

	public final Stack<Kandidat> getKandidatListe() {
		return kandidatListe;
	}
	
	public final String getOverordnetSpilKategoriNavn() {
		return overordnetSpilKategoriNavn;
	}

	public final void setOverordnetSpilKategoriNavn(
			String overordnetSpilKategoriNavn) {
		this.overordnetSpilKategoriNavn = overordnetSpilKategoriNavn;
	}

	public final String getOverordnetSpilProduktNavn() {
		return overordnetSpilProduktNavn;
	}

	public final void setOverordnetSpilProduktNavn(String overordnetSpilProduktNavn) {
		this.overordnetSpilProduktNavn = overordnetSpilProduktNavn;
	}

	public final String getOverordnetSpilProduktIdentifikation() {
		return overordnetSpilProduktIdentifikation;
	}

	public final void setOverordnetSpilProduktIdentifikation(
			String overordnetSpilProduktIdentifikation) {
		this.overordnetSpilProduktIdentifikation = overordnetSpilProduktIdentifikation;
	}


	public static class Kandidat {
		
		private String spilTransaktionIdentifikation;
		
		private Long lodtraekningSekvensTal;
		
		private Long raekkeNummer;

		private DateTime spilKoebDatoTid;

		private String spilKoebDatoTidString;

		public final String getSpilTransaktionIdentifikation() {
			return spilTransaktionIdentifikation;
		}

		public final void setSpilTransaktionIdentifikation(
				String spilTransaktionIdentifikation) {
			this.spilTransaktionIdentifikation = spilTransaktionIdentifikation;
		}

		public final Long getLodtraekningSekvensTal() {
			return lodtraekningSekvensTal;
		}

		public final void setLodtraekningSekvensTal(Long lodtraekningSekvensTal) {
			this.lodtraekningSekvensTal = lodtraekningSekvensTal;
		}

		public final Long getRaekkeNummer() {
			return raekkeNummer;
		}

		public final void setRaekkeNummer(Long raekkeNummer) {
			this.raekkeNummer = raekkeNummer;
		}

		public final DateTime getSpilKoebDatoTid() {
			return spilKoebDatoTid;
		}

		public final void setSpilKoebDatoTid(DateTime spilKoebDatoTid) {
			this.spilKoebDatoTid = spilKoebDatoTid;
		}
		
		public final String getSpilKoebDatoTidString() {
			return spilKoebDatoTidString;
		}

		public final void setSpilKoebDatoTidString(String spilKoebDatoTidString) {
			this.spilKoebDatoTidString = spilKoebDatoTidString;
		}

		@Override
		public String toString() {
			return "Kandidat [spilTransaktionIdentifikation="
					+ spilTransaktionIdentifikation
					+ ", lodtraekningSekvensTal=" + lodtraekningSekvensTal
					+ ", raekkeNummer=" + raekkeNummer + ", spilKoebDatoTid="
					+ spilKoebDatoTid + "]";
		}

	}

	public final boolean isOverordnet() {
		return overordnet;
	}

	public final void setOverordnet(boolean overordnet) {
		this.overordnet = overordnet;
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolLodtraekningStartStruktur;
	}

	@Override
	public String toString() {
		return "MonopolLodtraekningStartStandardRecord [spilForventetSlutDatoTid="
				+ spilForventetSlutDatoTid
				+ ", overordnetSpilKategoriNavn="
				+ overordnetSpilKategoriNavn
				+ ", overordnetSpilProduktNavn="
				+ overordnetSpilProduktNavn
				+ ", overordnetSpilProduktIdentifikation="
				+ overordnetSpilProduktIdentifikation
				+ ", kandidatListe="
				+ kandidatListe
				+ ", getSpilKategoriNavn()="
				+ getSpilKategoriNavn()
				+ ", getSpilProduktIdentifikation()="
				+ getSpilProduktIdentifikation()
				+ ", getSpilProduktNavn()="
				+ getSpilProduktNavn()
				+ ", getSpilFilIdentifikation()="
				+ getSpilFilIdentifikation()
				+ ", getSpilFilErstatningIdentifikation()="
				+ getSpilFilErstatningIdentifikation()
				+ ", getSpilCertifikatIdentifikation()="
				+ getSpilCertifikatIdentifikation() + "]";
	}

	
}
