package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolLodtraekningTotalStrukturStandardRecord extends AbstractGameStandardRecord
{
    private TilladelsesindehaverOgSpil tilladelsesindehaverOgSpil;
    private Stack<TilfaeldighedGenerator> tilfaeldighedGeneratorListe;
    private Stack<ResultatGrundlag> resultatGrundlagListe;

   public MonopolLodtraekningTotalStrukturStandardRecord(){
        tilladelsesindehaverOgSpil = new TilladelsesindehaverOgSpil();
        tilfaeldighedGeneratorListe = new Stack<>();
        resultatGrundlagListe = new Stack<>();

    }
    @Override
    public StandardRecordTypes getStructureType() {
        return StandardRecordTypes.MonopolLodtraekningTotalStruktur;
    }

    public Stack<TilfaeldighedGenerator> getTilfaeldighedGeneratorList() {
        return tilfaeldighedGeneratorListe;
    }

    public TilfaeldighedGenerator getLatestTilfaeldighedGenerator() {
        return tilfaeldighedGeneratorListe.peek();
    }
    public ResultatGrundlag getLatestResultatGrundlag() {
        return resultatGrundlagListe.peek();
    }

    public Stack<ResultatGrundlag> getResultatGrundlagList() {
        return resultatGrundlagListe;
    }

    public void addNewTilfaeldighedGenerator(){
        tilfaeldighedGeneratorListe.push(new TilfaeldighedGenerator());
    }

    public void addNewResultatGrundlag(){
        resultatGrundlagListe.push(new ResultatGrundlag());
    }

    public TilladelsesindehaverOgSpil getTilladelsesindehaverOgSpil() {
        return tilladelsesindehaverOgSpil;
    }

    public void setTilladelsesindehaverOgSpil(TilladelsesindehaverOgSpil tilladelsesindehaverOgSpil) {
        this.tilladelsesindehaverOgSpil = tilladelsesindehaverOgSpil;
    }

    public class TilfaeldighedGenerator {
        private String tilfaeldighedGeneratorIdentifikation;
        private String tilfaeldighedGeneratorSoftwareId;
        private String lodtraekningAnsvarlig;

        public String getTilfaeldighedGeneratorIdentifikation() {
            return tilfaeldighedGeneratorIdentifikation;
        }

        public void setTilfaeldighedGeneratorIdentifikation(String tilfaeldighedGeneratorIdentifikation) {
            this.tilfaeldighedGeneratorIdentifikation = tilfaeldighedGeneratorIdentifikation;
        }

        public String getTilfaeldighedGeneratorSoftwareId() {
            return tilfaeldighedGeneratorSoftwareId;
        }

        public void setTilfaeldighedGeneratorSoftwareId(String tilfaeldighedGeneratorSoftwareId) {
            this.tilfaeldighedGeneratorSoftwareId = tilfaeldighedGeneratorSoftwareId;
        }

        public String getLodtraekningAnsvarlig() {
            return lodtraekningAnsvarlig;
        }

        public void setLodtraekningAnsvarlig(String lodtraekningAnsvarlig) {
            this.lodtraekningAnsvarlig = lodtraekningAnsvarlig;
        }
    }

    public class TilladelsesindehaverOgSpil {
        private String monopolSpilKategoriNavn;
        private String monopolSpilProduktNavn;
        private String monopolSpilProduktIdentifikation;
        private DateTime monopolSpilProduktFaktiskSlutDatoTid;
        private String monopolSpilProduktFaktiskSlutDatoTidString;

        public String getMonopolSpilProduktFaktiskSlutDatoTidString() {
            return monopolSpilProduktFaktiskSlutDatoTidString;
        }

        public void setMonopolSpilProduktFaktiskSlutDatoTidString(String monopolSpilProduktFaktiskSlutDatoTidString) {
            this.monopolSpilProduktFaktiskSlutDatoTidString = monopolSpilProduktFaktiskSlutDatoTidString;
        }

        public String getMonopolSpilKategoriNavn() {
            return monopolSpilKategoriNavn;
        }

        public void setMonopolSpilKategoriNavn(String monopolSpilKategoriNavn) {
            this.monopolSpilKategoriNavn = monopolSpilKategoriNavn;
        }

        public String getMonopolSpilProduktNavn() {
            return monopolSpilProduktNavn;
        }

        public void setMonopolSpilProduktNavn(String monopolSpilProduktNavn) {
            this.monopolSpilProduktNavn = monopolSpilProduktNavn;
        }

        public String getMonopolSpilProduktIdentifikation() {
            return monopolSpilProduktIdentifikation;
        }

        public void setMonopolSpilProduktIdentifikation(String monopolSpilProduktIdentifikation) {
            this.monopolSpilProduktIdentifikation = monopolSpilProduktIdentifikation;
        }

        public DateTime getMonopolSpilProduktFaktiskSlutDatoTid() {
            return monopolSpilProduktFaktiskSlutDatoTid;
        }

        public void setMonopolSpilProduktFaktiskSlutDatoTid(DateTime monopolSpilProduktFaktiskSlutDatoTid) {
            this.monopolSpilProduktFaktiskSlutDatoTid = monopolSpilProduktFaktiskSlutDatoTid;
        }
    }

    public class ResultatGrundlag {
        private String GevinstPuljeIdentifikation;
        private Stack<VinderTal> VinderTalList;

        public ResultatGrundlag(){
            VinderTalList = new Stack<>();
        }

        public String getGevinstPuljeIdentifikation() {
            return GevinstPuljeIdentifikation;
        }

        public void setGevinstPuljeIdentifikation(String gevinstPuljeIdentifikation) {
            GevinstPuljeIdentifikation = gevinstPuljeIdentifikation;
        }

        public Stack<VinderTal> getVinderTalList() {
            return VinderTalList;
        }

        public VinderTal getLatestVinderTal(){
            return getVinderTalList().peek();
        }

        public void addNewVinderTal(Integer value){
            VinderTal vinderTal = new VinderTal();
            vinderTal.setLodtraekningVinderTal(value);
            VinderTalList.push(vinderTal);
        }

        public class VinderTal{
            public Integer getLodtraekningVinderTal() {
                return LodtraekningVinderTal;
            }

            public void setLodtraekningVinderTal(Integer lodtraekningVinderTal) {
                LodtraekningVinderTal = lodtraekningVinderTal;
            }

            public Integer LodtraekningVinderTal;


        }



    }

}
