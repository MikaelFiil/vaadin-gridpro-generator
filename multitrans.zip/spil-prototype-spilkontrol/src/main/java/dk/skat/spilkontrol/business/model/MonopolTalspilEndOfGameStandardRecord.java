package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolTalspilEndOfGameStandardRecord extends AbstractGameStandardRecord {

	// inside Talspil tag
	private DateTime endOfGameDatoTid;
	private String endOfGameDatoTidString;

	private Double indskudSpilTillIndh;
	private Double indskudSpilTotal;
	private Double indskudJackpotTillIndh;
	private Double indskudJackpotTotal;

	private Long antalRaekkerTillIndh;
	private Long samletAntalRaekker;

	private Double gevinstPuljeBeloeb;
	private String valutaOplysningKode;

	public static class ResultatTalSpil {
	
		private String puljeIdentifikation;
		
		private Double puljeOverfoerselPrimo;

		public final String getPuljeIdentifikation() {
			return puljeIdentifikation;
		}

		public final void setPuljeIdentifikation(String puljeIdentifikation) {
			this.puljeIdentifikation = puljeIdentifikation;
		}


		public final Double getPuljeOverfoerselPrimo() {
			return puljeOverfoerselPrimo;
		}

		public final void setPuljeOverfoerselPrimo(Double puljeOverfoerselPrimo) {
			this.puljeOverfoerselPrimo = puljeOverfoerselPrimo;
		}

		@Override
		public String toString() {
			return "ResultatTalSpil [puljeIdentifikation="
					+ puljeIdentifikation + ", puljeOverfoerselPrimo=" + puljeOverfoerselPrimo + "]";
		}
	}
	
	private final Stack<ResultatTalSpil> resultatTalSpilListe = new Stack<ResultatTalSpil>();
	
	public final void addNewResultatTalSpil() {
		resultatTalSpilListe.push(new ResultatTalSpil());
	}
	
	public final DateTime getEndOfGameDatoTid() {
		return endOfGameDatoTid;
	}
	public final void setEndOfGameDatoTid(DateTime endOfGameDatoTid) {
		this.endOfGameDatoTid = endOfGameDatoTid;
	}

	public final String getEndOfGameDatoTidString() {
		return endOfGameDatoTidString;
	}

	public final void setEndOfGameDatoTidString(String endOfGameDatoTidString) {
		this.endOfGameDatoTidString = endOfGameDatoTidString;
	}

	public final Double getIndskudSpilTillIndh() {
		return indskudSpilTillIndh;
	}
	public final void setIndskudSpilTillIndh(Double indskudSpilTillIndh) {
		this.indskudSpilTillIndh = indskudSpilTillIndh;
	}
	public final Double getIndskudSpilTotal() {
		return indskudSpilTotal;
	}
	public final void setIndskudSpilTotal(Double indskudSpilTotal) {
		this.indskudSpilTotal = indskudSpilTotal;
	}
	public final Double getIndskudJackpotTillIndh() {
		return indskudJackpotTillIndh;
	}
	public final void setIndskudJackpotTillIndh(Double indskudJackpotTillIndh) {
		this.indskudJackpotTillIndh = indskudJackpotTillIndh;
	}
	public final Double getIndskudJackpotTotal() {
		return indskudJackpotTotal;
	}
	public final void setIndskudJackpotTotal(Double indskudJackpotTotal) {
		this.indskudJackpotTotal = indskudJackpotTotal;
	}
	public final Long getAntalRaekkerTillIndh() {
		return antalRaekkerTillIndh;
	}
	public final void setAntalRaekkerTillIndh(Long antalRaekkerTillIndh) {
		this.antalRaekkerTillIndh = antalRaekkerTillIndh;
	}
	public final Long getSamletAntalRaekker() {
		return samletAntalRaekker;
	}
	public final void setSamletAntalRaekker(Long samletAntalRaekker) {
		this.samletAntalRaekker = samletAntalRaekker;
	}
	public final Double getGevinstPuljeBeloeb() {
		return gevinstPuljeBeloeb;
	}
	public final void setGevinstPuljeBeloeb(Double gevinstPuljeBeloeb) {
		this.gevinstPuljeBeloeb = gevinstPuljeBeloeb;
	}
	public final String getValutaOplysningKode() {
		return valutaOplysningKode;
	}
	public final void setValutaOplysningKode(String valutaOplysningKode) {
		this.valutaOplysningKode = valutaOplysningKode;
	}
	
	public final Stack<ResultatTalSpil> getResultatTalSpilListe() {
		return resultatTalSpilListe;
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolTalspilEndOfGameStruktur;
	}
	
}
