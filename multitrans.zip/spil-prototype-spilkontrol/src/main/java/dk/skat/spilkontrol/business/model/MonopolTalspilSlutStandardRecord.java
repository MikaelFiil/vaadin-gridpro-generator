package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolTalspilSlutStandardRecord extends AbstractGameStandardRecord {

	private final Stack<TilfaeldighedGenerator> tilfaeldighedGeneratorListe = new Stack<TilfaeldighedGenerator>();

	private final Stack<SamletOmsaetning> samletOmsaetningListe = new Stack<SamletOmsaetning>();

	private final Stack<GevinstkategorierOgGevinster> gevinstkategorierListe = new Stack<GevinstkategorierOgGevinster>();
	
	private final Stack<ResultatGrundlag> resultatGrundlagListe = new Stack<ResultatGrundlag>();

	private final Stack<Vinder> vinderListe = new Stack<Vinder>();
	
	private DateTime spilProduktFaktiskSlutDatoTid;
	
	private String spilProduktFaktiskSlutDatoTidString;

	private String valutaOplysningKode;

	public MonopolTalspilSlutStandardRecord() {
	}
	
	public final void addNewGevinstkategorierOgGevinster() {
		gevinstkategorierListe.push(new GevinstkategorierOgGevinster());
	}

	public final void addResultatGrundlag() {
		resultatGrundlagListe.push(new ResultatGrundlag());
	}

	public final void addNewVinder() {
		vinderListe.push(new Vinder());
	}

	public final void addNewTilfaeldighedGenerator() {
		tilfaeldighedGeneratorListe.push(new TilfaeldighedGenerator());
	}

	public final void addNewSamletOmsaetning() {
		samletOmsaetningListe.push(new SamletOmsaetning());
	}
	
	public Stack<ResultatGrundlag> getResultatGrundlagListe() {
		return resultatGrundlagListe;
	}

	public Stack<TilfaeldighedGenerator> getTilfaeldighedGeneratorListe() {
		return tilfaeldighedGeneratorListe;
	}

	public final Stack<SamletOmsaetning> getSamletOmsaetningListe() {
		return samletOmsaetningListe;
	}

	public final Stack<GevinstkategorierOgGevinster> getGevinstkategorierListe() {
		return gevinstkategorierListe;
	}

	public final Stack<Vinder> getVinderListe() {
		return vinderListe;
	}

	public final DateTime getSpilProduktFaktiskSlutDatoTid() {
		return spilProduktFaktiskSlutDatoTid;
	}

	public final void setSpilProduktFaktiskSlutDatoTid(DateTime spilTypeFaktiskSlutDatoTid) {
		this.spilProduktFaktiskSlutDatoTid = spilTypeFaktiskSlutDatoTid;
	}

	public final String getValutaOplysningKode() {
		return valutaOplysningKode;
	}

	public final void setValutaOplysningKode(String valutaOplysningKode) {
		this.valutaOplysningKode = valutaOplysningKode;
	}
	
	public final String getSpilProduktFaktiskSlutDatoTidString() {
		return spilProduktFaktiskSlutDatoTidString;
	}

	public final void setSpilProduktFaktiskSlutDatoTidString(
			String spilProduktFaktiskSlutDatoTidString) {
		this.spilProduktFaktiskSlutDatoTidString = spilProduktFaktiskSlutDatoTidString;
	}


	public static class ResultatGrundlag {
		/**
		 * inside ResultatGrundlag is puljespilVinderRaekke
		 */
		private String puljespilVinderRaekke;
			
		public final String getPuljespilVinderRaekke() {
			return puljespilVinderRaekke;
		}

		public final void setPuljespilVinderRaekke(String puljespilVinderRaekke) {
			this.puljespilVinderRaekke = puljespilVinderRaekke;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("ResultatGrundlag [puljespilVinderRaekke=");
			builder.append(puljespilVinderRaekke);
			builder.append("]");
			return builder.toString();
		}
		
	}
	
	public static class TilfaeldighedGenerator {
		private String tilfaeldighedGeneratorIdentifikation;
		
		private String tilfaeldighedGeneratorSoftwareId;
		
		public String getTilfaeldighedGeneratorIdentifikation() {
			return tilfaeldighedGeneratorIdentifikation;
		}

		public void setTilfaeldighedGeneratorIdentifikation(String tilfaeldighedGeneratorIdentifikation) {
			this.tilfaeldighedGeneratorIdentifikation = tilfaeldighedGeneratorIdentifikation;
		}

		public String getTilfaeldighedGeneratorSoftwareId() {
			return tilfaeldighedGeneratorSoftwareId;
		}

		public void setTilfaeldighedGeneratorSoftwareId(String tilfaeldighedGeneratorSoftwareId) {
			this.tilfaeldighedGeneratorSoftwareId = tilfaeldighedGeneratorSoftwareId;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("TilfaeldighedGenerator [TilfaeldighedGeneratorIdentifikation=");
			builder.append(tilfaeldighedGeneratorIdentifikation);
			builder.append(", TilfaeldighedGeneratorSoftwareId=");
			builder.append(tilfaeldighedGeneratorSoftwareId);
			builder.append("]");
			return builder.toString();
		}
		
	}

	public static class GevinstkategorierOgGevinster {
		private String gevinstPuljeIdentifikation;
		private Long gevinstPuljeAntalGevinsterTillIndh;

		private Double gevinstPuljeBeloebTillIndh;
		private Double gevinstPuljeBeloebTotal;
		private Double gevinstPuljeBeloebPerRaekke;
		private Double gevinstPuljeTilfoejetBeloeb;
		private Double gevinstPuljeOverfoerselUltimo;

		private Long spilSamletAntalRaekker;

		public final String getGevinstPuljeIdentifikation() {
			return gevinstPuljeIdentifikation;
		}

		public final Long getGevinstPuljeAntalGevinsterTillIndh() {
			return gevinstPuljeAntalGevinsterTillIndh;
		}
		public final void setGevinstPuljeAntalGevinsterTillIndh(
				Long gevinstPuljeAntalGevinsterTillIndh) {
			this.gevinstPuljeAntalGevinsterTillIndh = gevinstPuljeAntalGevinsterTillIndh;
		}
		public final Double getGevinstPuljeBeloebTillIndh() {
			return gevinstPuljeBeloebTillIndh;
		}
		public final void setGevinstPuljeBeloebTillIndh(
				Double gevinstPuljeBeloebTillIndh) {
			this.gevinstPuljeBeloebTillIndh = gevinstPuljeBeloebTillIndh;
		}
		public final Double getGevinstPuljeBeloebTotal() {
			return gevinstPuljeBeloebTotal;
		}
		public final void setGevinstPuljeBeloebTotal(Double gevinstPuljeBeloebTotal) {
			this.gevinstPuljeBeloebTotal = gevinstPuljeBeloebTotal;
		}
		public final Double getGevinstPuljeBeloebPerRaekke() {
			return gevinstPuljeBeloebPerRaekke;
		}
		public final void setGevinstPuljeBeloebPerRaekke(
				Double gevinstPuljeBeloebPerRaekke) {
			this.gevinstPuljeBeloebPerRaekke = gevinstPuljeBeloebPerRaekke;
		}
		public final Long getSpilSamletAntalRaekker() {
			return spilSamletAntalRaekker;
		}
		public final void setSpilSamletAntalRaekker(Long spilSamletAntalRaekker) {
			this.spilSamletAntalRaekker = spilSamletAntalRaekker;
		}

		public final void setGevinstPuljeIdentifikation(
				String gevinstPuljeIdentifikation) {
			this.gevinstPuljeIdentifikation = gevinstPuljeIdentifikation;
		}

		public final Double getGevinstPuljeTilfoejetBeloeb() {
			return gevinstPuljeTilfoejetBeloeb;
		}

		public final void setGevinstPuljeTilfoejetBeloeb(
				Double gevinstPuljeTilfoejetBeloeb) {
			this.gevinstPuljeTilfoejetBeloeb = gevinstPuljeTilfoejetBeloeb;
		}

		public final Double getGevinstPuljeOverfoerselUltimo() {
			return gevinstPuljeOverfoerselUltimo;
		}

		public final void setGevinstPuljeOverfoerselUltimo(
				Double gevinstPuljeOverfoerselUltimo) {
			this.gevinstPuljeOverfoerselUltimo = gevinstPuljeOverfoerselUltimo;
		}
		
	}
	
	
	public static class SamletOmsaetning {
		private Double samletOmsaetning;
		
		private String valutaOplysningKode;
		
		private Double valutaOplysningKurs;

		public final Double getSamletOmsaetning() {
			return samletOmsaetning;
		}

		public final void setSamletOmsaetning(Double samletOmsaetning) {
			this.samletOmsaetning = samletOmsaetning;
		}

		public final String getValutaOplysningKode() {
			return valutaOplysningKode;
		}

		public final void setValutaOplysningKode(String valutaOplysningKode) {
			this.valutaOplysningKode = valutaOplysningKode;
		}

		public final Double getValutaOplysningKurs() {
			return valutaOplysningKurs;
		}

		public final void setValutaOplysningKurs(Double valutaOplysningKurs) {
			this.valutaOplysningKurs = valutaOplysningKurs;
		}

	}
	
	public static class Vinder {
		private String spillerInformationIdentifikation;
		
		private String spilTransaktionIdentifikation;
		
		private Long raekkeNummer;
		
		private Double spilGevinstSpil;
		
		private Double spilGevinstJackpot;

		public final String getSpillerInformationIdentifikation() {
			return spillerInformationIdentifikation;
		}

		public final void setSpillerInformationIdentifikation(
				String spillerInformationIdentifikation) {
			this.spillerInformationIdentifikation = spillerInformationIdentifikation;
		}

		public final String getSpilTransaktionIdentifikation() {
			return spilTransaktionIdentifikation;
		}

		public final void setSpilTransaktionIdentifikation(String spillerIdentifikation) {
			this.spilTransaktionIdentifikation = spillerIdentifikation;
		}

		public final Long getRaekkeNummer() {
			return raekkeNummer;
		}

		public final void setRaekkeNummer(Long raekkeNummer) {
			this.raekkeNummer = raekkeNummer;
		}

		public final Double getSpilGevinstSpil() {
			return spilGevinstSpil;
		}

		public final void setSpilGevinstSpil(Double spilGevinstFraSpil) {
			this.spilGevinstSpil = spilGevinstFraSpil;
		}

		public final Double getSpilGevinstJackpot() {
			return spilGevinstJackpot;
		}

		public final void setSpilGevinstJackpot(Double spilGevinstFraJackpot) {
			this.spilGevinstJackpot = spilGevinstFraJackpot;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("Vinder [spillerInformationIdentifikation=");
			builder.append(spillerInformationIdentifikation);
			builder.append(", spilTransaktionIdentifikation=");
			builder.append(spilTransaktionIdentifikation);
			builder.append(", raekkeNummer=");
			builder.append(raekkeNummer);
			builder.append(", spilGevinstSpil=");
			builder.append(spilGevinstSpil);
			builder.append(", spilGevinstJackpot=");
			builder.append(spilGevinstJackpot);
			builder.append("]");
			return builder.toString();
		}

	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolTalspilSlutStruktur;
	}
	
}
