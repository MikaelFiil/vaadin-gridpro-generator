package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolTalspilStartStandardRecord extends AbstractGameStandardRecord {
	
	final private Stack<GenerelSpilNoegle> generelSpilNoegleListe = new Stack<GenerelSpilNoegle>();
	
	// TalSpil
	private boolean spilProduktAabentNetvaerk;
	private Double gevinstPuljeProcent;
    private Long antalResultatPuljer;
	private Long antalTal;
	private Double spilRaekkePris;
	private DateTime spilForventetSlutDatoTid;
	private String spilForventetSlutDatoTidString;
    private String valutaOplysningKode;
    private Long monopolSpilProduktNummer;
    private Long monopolTalspilDrawNummer;
	private Long monopolTalspilUgeNummer;
    
	public boolean isSpilTypeAabentNetvaerk() {
		return spilProduktAabentNetvaerk;
	}
	
	public void setSpilProduktAabentNetvaerk(boolean spilTypeAabentNetvaerk) {
		this.spilProduktAabentNetvaerk = spilTypeAabentNetvaerk;
	}
	
	private final Stack<ResultatTalSpil> resultatTalSpilListe =
			new Stack<ResultatTalSpil>();
	
	public void addNewGenerelPuljeNoegle() {
		generelSpilNoegleListe.push(new GenerelSpilNoegle());
	}

	public void addNewResultatTalSpil() {
		resultatTalSpilListe.push(new ResultatTalSpil());
	}

	public final DateTime getSpilForventetSlutDatoTid() {
		return spilForventetSlutDatoTid;
	}

	public final void setSpilForventetSlutDatoTid(DateTime spilForventetSlutDatoTid) {
		this.spilForventetSlutDatoTid = spilForventetSlutDatoTid;
	}
	
	public final String getSpilForventetSlutDatoTidString() {
		return spilForventetSlutDatoTidString;
	}

	public final void setSpilForventetSlutDatoTidString(
			String spilForventetSlutDatoTidString) {
		this.spilForventetSlutDatoTidString = spilForventetSlutDatoTidString;
	}

	public final String getValutaOplysningKode() {
		return valutaOplysningKode;
	}

	public final void setValutaOplysningKode(String valutaOplysningKode) {
		this.valutaOplysningKode = valutaOplysningKode;
	}

	public final Long getMonopolSpilProduktNummer() {
		return monopolSpilProduktNummer;
	}

	public final void setMonopolSpilProduktNummer(Long monopolSpilProduktNummer) {
		this.monopolSpilProduktNummer = monopolSpilProduktNummer;
	}

	public final Long getMonopolTalspilDrawNummer() {
		return monopolTalspilDrawNummer;
	}

	public final void setMonopolTalspilDrawNummer(Long monopolTalspilDrawNummer) {
		this.monopolTalspilDrawNummer = monopolTalspilDrawNummer;
	}

	public final Long getMonopolTalspilUgeNummer() {
		return monopolTalspilUgeNummer;
	}

	public final void setMonopolTalspilUgeNummer(Long monopolTalspilUgeNummer) {
		this.monopolTalspilUgeNummer = monopolTalspilUgeNummer;
	}

	public final Stack<GenerelSpilNoegle> getGenerelSpilNoegleListe() {
		return generelSpilNoegleListe;
	}

	public final Stack<ResultatTalSpil> getResultatTalSpilListe() {
		return resultatTalSpilListe;
	}

	public final Double getGevinstPuljeProcent() {
		return gevinstPuljeProcent;
	}

	public final void setGevinstPuljeProcent(Double gevinstPuljeProcent) {
		this.gevinstPuljeProcent = gevinstPuljeProcent;
	}

	public final Long getAntalResultatPuljer() {
		return antalResultatPuljer;
	}

	public final void setAntalResultatPuljer(Long antalResultatPuljer) {
		this.antalResultatPuljer = antalResultatPuljer;
	}

	public final Long getAntalTal() {
		return antalTal;
	}

	public final void setAntalTal(Long antalTal) {
		this.antalTal = antalTal;
	}

	public final Double getSpilRaekkePris() {
		return spilRaekkePris;
	}

	public final void setSpilRaekkePris(Double spilRaekkePris) {
		this.spilRaekkePris = spilRaekkePris;
	}

	public final boolean isSpilProduktAabentNetvaerk() {
		return spilProduktAabentNetvaerk;
	}

	public static class GenerelSpilNoegle {
		
		private Long noegleNummer;
		
		private String noegleBeskrivelse;
		
		private String noegleValideTal;

		public final Long getNoegleNummer() {
			return noegleNummer;
		}

		public final void setNoegleNummer(Long noegleNummer) {
			this.noegleNummer = noegleNummer;
		}

		public final String getNoegleBeskrivelse() {
			return noegleBeskrivelse;
		}

		public final void setNoegleBeskrivelse(String noegleBeskrivelse) {
			this.noegleBeskrivelse = noegleBeskrivelse;
		}

		public final String getNoegleValideTal() {
			return noegleValideTal;
		}

		public final void setNoegleValideTal(String noegleValideTal) {
			this.noegleValideTal = noegleValideTal;
		}

		@Override
		public String toString() {
			return "GenerelSpilNoegle [noegleKampNummer=" + noegleNummer
					+ ", noegleBeskrivelse=" + noegleBeskrivelse
					+ ", noegleValideTal=" + noegleValideTal + "]";
		}

	}

	public static class ResultatTalSpil {
		
		private String gevinstPuljeIdentifikation;
		
		private Double gevinstPuljeGevinstProcent;
		
		private String gevinstPuljeBeskrivelse;

		private Double gevinstPuljeGaranti;
		
		public final String getGevinstPuljeBeskrivelse() {
			return gevinstPuljeBeskrivelse;
		}
		public final void setGevinstPuljeBeskrivelse(String gevinstPuljeBeskrivelse) {
			this.gevinstPuljeBeskrivelse = gevinstPuljeBeskrivelse;
		}
		public final String getGevinstPuljeIdentifikation() {
			return gevinstPuljeIdentifikation;
		}
		public final void setGevinstPuljeIdentifikation(
				String gevinstPuljeIdentifikation) {
			this.gevinstPuljeIdentifikation = gevinstPuljeIdentifikation;
		}
		public final Double getGevinstPuljeGevinstProcent() {
			return gevinstPuljeGevinstProcent;
		}
		public final void setGevinstPuljeGevinstProcent(
				Double gevinstPuljeGevinstProcent) {
			this.gevinstPuljeGevinstProcent = gevinstPuljeGevinstProcent;
		}
		
		/**
		 * missing value is allowed. It will then return null.
		 * 
		 * @return
		 */
		public final Double getGevinstPuljeGaranti() {
			return gevinstPuljeGaranti;
		}
		
		public final void setGevinstPuljeGaranti(Double gevinstPuljeGaranti) {
			this.gevinstPuljeGaranti = gevinstPuljeGaranti;
		}
		
	}

	@Override
	public String toString() {
		return "MonopolTalspilStartStandardRecord [generelSpilNoegleListe="
				+ generelSpilNoegleListe + ", spilProduktAabentNetvaerk="
				+ spilProduktAabentNetvaerk + ", gevinstPuljeProcent="
				+ gevinstPuljeProcent + ", antalResultatPuljer="
				+ antalResultatPuljer + ", antalTal=" + antalTal
				+ ", spilRaekkePris=" + spilRaekkePris
				+ ", spilForventetSlutDatoTid=" + spilForventetSlutDatoTid
				+ ", valutaOplysningKode=" + valutaOplysningKode
				+ ", resultatTalSpilListe=" + resultatTalSpilListe + "]";
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolTalspilStartStruktur;
	}
	
}
