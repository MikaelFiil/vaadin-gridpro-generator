package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class MonopolTalspilTransaktionStandardRecord extends AbstractGameStandardRecord {
	
	private final Stack<SpillerOgKuponType> spillerOgKupon = new Stack<>();

	public final Stack<SpillerOgKuponType> getSpillerOgKuponListe() {
		return spillerOgKupon;
	}

	public final void addNewSpillerOgKupon() {
		spillerOgKupon.push(new SpillerOgKuponType());
	}

	public MonopolTalspilTransaktionStandardRecord() {
	}
	
	public static class SpillerOgKuponType {

		// These fields are common with Kasino
		private String spillerInformationIdentifikation;
		private String spilTransaktionIdentifikation;
		private String monopolOverordnetSpilTransaktionIdentifikation;
		private DateTime spilKoebDatoTid;
		private String spilKoebDatoTidString;
		private String spilSalgskanal;

		// These fields are special for PuljespilTransaktion
		private Long spilAntalRaekker;
		private Double spilIndskud;
		private Double spilIndskudSpil;

		private Double kenoRaekkePris;
		private String talSpilType;
		
		private String valutaOplysningKode;
		
		private String spilTerminalidentification;
		private String spilHjemmeside;

		private Boolean spilAnnullering; // nullable
		private DateTime spilAnnulleringDatoTid; // nullable
		private String spilAnnulleringDatoTidString; // nullable

		private final Stack<Spilkombinationer> spilkombinationerListe = new Stack<>();

		private final Stack<Jackpot> jackpotListe = new Stack<>();

		private Double andel;

		public String getSpilHjemmeside() {
			return spilHjemmeside;
		}

		public void setSpilHjemmeside(String spilHjemmeside) {
			this.spilHjemmeside = spilHjemmeside;
		}

		public Stack<Jackpot> getJackpotListe() {
			return jackpotListe;
		}

		public final String getSpillerInformationIdentifikation() {
			return spillerInformationIdentifikation;
		}

		public final void setSpillerInformationIdentifikation(
				String spillerInformationIdentifikation) {
			this.spillerInformationIdentifikation = spillerInformationIdentifikation;
		}

		public final String getSpilIdentifikation() {
			return spilTransaktionIdentifikation;
		}

		public final void setSpilTransaktionIdentifikation(String spilIdentifikation) {
			this.spilTransaktionIdentifikation = spilIdentifikation;
		}

		public final DateTime getSpilKoebDatoTid() {
			return spilKoebDatoTid;
		}

		public final void setSpilKoebDatoTid(DateTime spilKoebDatoTid) {
			this.spilKoebDatoTid = spilKoebDatoTid;
		}
		
		public final String getSpilKoebDatoTidString() {
			return spilKoebDatoTidString;
		}

		public final void setSpilKoebDatoTidString(String spilKoebDatoTidString) {
			this.spilKoebDatoTidString = spilKoebDatoTidString;
		}

		public final String getSpilAnnulleringDatoTidString() {
			return spilAnnulleringDatoTidString;
		}

		public final void setSpilAnnulleringDatoTidString(
				String spilAnnulleringDatoTidString) {
			this.spilAnnulleringDatoTidString = spilAnnulleringDatoTidString;
		}

		public final String getSpilSalgskanal() {
			return spilSalgskanal;
		}


		public final void setSpilSalgskanal(String spilSalgskanal) {
			this.spilSalgskanal = spilSalgskanal;
		}


		public final String getSpilTerminalidentification() {
			return spilTerminalidentification;
		}


		public final void setSpilTerminalidentification(
				String spilTerminalidentification) {
			this.spilTerminalidentification = spilTerminalidentification;
		}

		public final Boolean getSpilAnnullering() {
			return spilAnnullering;
		}


		public final void setSpilAnnullering(Boolean spilAnnullering) {
			this.spilAnnullering = spilAnnullering;
		}

		public final DateTime getSpilAnnulleringDatoTid() {
			return spilAnnulleringDatoTid;
		}


		public final void setSpilAnnulleringDatoTid(DateTime spilAnnulleringDatoTid) {
			this.spilAnnulleringDatoTid = spilAnnulleringDatoTid;
		}


		public final Double getSpilIndskudTilSpil() {
			return spilIndskudSpil;
		}

		public final void setSpilIndskudSpil(Double spilIndskudTilSpil) {
			this.spilIndskudSpil = spilIndskudTilSpil;
		}


		public final Long getSpilAntalRaekker() {
			return spilAntalRaekker;
		}


		public final void setSpilAntalRaekker(Long spilAntalRaekker) {
			this.spilAntalRaekker = spilAntalRaekker;
		}


		public final Double getSpilIndskud() {
			return spilIndskud;
		}

		public final void setSpilIndskud(Double spilIndskud) {
			this.spilIndskud = spilIndskud;
		}

		public final String getMonopolOverordnetSpilTransaktionIdentifikation() {
			return monopolOverordnetSpilTransaktionIdentifikation;
		}

		public final void setMonopolOverordnetSpilTransaktionIdentifikation(
				String monopolOverordnetSpilTransaktionIdentifikation) {
			this.monopolOverordnetSpilTransaktionIdentifikation = monopolOverordnetSpilTransaktionIdentifikation;
		}

		public final String getTalSpilType() {
			return talSpilType;
		}

		public final void setTalSpilType(String talSpilType) {
			this.talSpilType = talSpilType;
		}

		public final String getValutaOplysningKode() {
			return valutaOplysningKode;
		}

		public final void setValutaOplysningKode(String valutaOplysningKode) {
			this.valutaOplysningKode = valutaOplysningKode;
		}

		public final String getSpilTransaktionIdentifikation() {
			return spilTransaktionIdentifikation;
		}

		public final Double getSpilIndskudSpil() {
			return spilIndskudSpil;
		}

		public final Double getKenoRaekkePris() {
			return kenoRaekkePris;
		}

		public final void setKenoRaekkePris(Double kenoRaekkePris) {
			this.kenoRaekkePris = kenoRaekkePris;
		}

		/**
		 * Special information for Pool games.
		 */
		public final Stack<Spilkombinationer> getSpilkombinationerListe() {
			return spilkombinationerListe;
		}
		
		public final void addNewSpilkombinationer() {
			spilkombinationerListe.push(new Spilkombinationer());
		}
		
		public final void addNewJackpot() {
			jackpotListe.push(new Jackpot());
		}

		public static class Jackpot {
			private String jackpotIdentifikation; // nullable
			private Double spilIndskudJackpot; // nullable
			public String getJackpotIdentifikation() {
				return jackpotIdentifikation;
			}
			public void setJackpotIdentifikation(String jackpotIdentifikation) {
				this.jackpotIdentifikation = jackpotIdentifikation;
			}
			public Double getSpilIndskudJackpot() {
				return spilIndskudJackpot;
			}
			public void setSpilIndskudJackpot(Double spilIndskudJackpot) {
				this.spilIndskudJackpot = spilIndskudJackpot;
			}
			@Override
			public String toString() {
                return "Jackpot [jackpotIdentifikation=" +
                    jackpotIdentifikation +
                    ", spilIndskudJackpot=" +
                    spilIndskudJackpot +
                    "]";
			}

		}

		public static class Spilkombinationer {
			private Long raekkeNummer;

			private String raekkeSpilkombinationer;

			public final Long getRaekkeNummer() {
				return raekkeNummer;
			}

			public final void setRaekkeNummer(Long raekkeNummer) {
				this.raekkeNummer = raekkeNummer;
			}

			public final String getRaekkeSpilkombinationer() {
				return raekkeSpilkombinationer;
			}

			public final void setRaekkeSpilkombinationer(String raekkeSpilkombinationer) {
				this.raekkeSpilkombinationer = raekkeSpilkombinationer;
			}

			@Override
			public String toString() {
                return "Spilkombinationer [raekkeNummer=" +
                    raekkeNummer +
                    ", raekkeSpilkombinationer=" +
                    raekkeSpilkombinationer +
                    "]";
			}
		}

		@Override
		public String toString() {
			return "SpillerOgKuponType [spillerInformationIdentifikation="
					+ spillerInformationIdentifikation
					+ ", spilTransaktionIdentifikation="
					+ spilTransaktionIdentifikation
					+ ", monopolOverordnetSpilTransaktionIdentifikation="
					+ monopolOverordnetSpilTransaktionIdentifikation
					+ ", spilKoebDatoTid=" + spilKoebDatoTid
					+ ", spilSalgskanal=" + spilSalgskanal
					+ ", spilAntalRaekker=" + spilAntalRaekker
					+ ", spilIndskud=" + spilIndskud + ", spilIndskudSpil="
					+ spilIndskudSpil + ", talSpilType=" + talSpilType
					+ ", valutaOplysningKode=" + valutaOplysningKode
					+ ", spilTerminalidentification="
					+ spilTerminalidentification + ", spilHjemmeside="
					+ spilHjemmeside + ", spilAnnullering=" + spilAnnullering
					+ ", spilAnnulleringDatoTid=" + spilAnnulleringDatoTid
					+ ", spilkombinationerListe=" + spilkombinationerListe
					+ ", jackpotListe=" + jackpotListe + "]";
		}

		public Double getAndel() { return andel; }

		public void setAndel(Double andel) { this.andel = andel; }
		
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.MonopolTalspilTransaktionStruktur;
	}
	
	@Override
	public String toString() {
        return "PuljespilTransaktionStandardRecord [" +
            "spilFilIdentifikation=" +
            getSpilFilIdentifikation() +
            ", spilFilErstatningIdentifikation=" +
            getSpilFilErstatningIdentifikation() +
            ", *** spilCertifikatIdentifikation=" +
            getSpilCertifikatIdentifikation() +
            ", spilKategoriNavn=" +
            getSpilKategoriNavn() +
            ", spilProduktNavn=" +
            getSpilProduktNavn() +
            ", spilProduktIdentifikation=" +
            getSpilProduktIdentifikation() +
            ", spillerOgKupon=" +
            spillerOgKupon +
            "]";
	}
}
