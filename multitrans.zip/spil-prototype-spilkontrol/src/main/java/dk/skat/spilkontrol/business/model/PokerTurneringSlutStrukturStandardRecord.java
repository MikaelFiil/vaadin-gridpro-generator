package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.PuljespilSlutStandardRecord.TilfaeldighedGenerator;
import dk.skat.spilkontrol.business.model.datafile.Dimensions;
import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class PokerTurneringSlutStrukturStandardRecord extends AbstractGameStandardRecord {

	private final Stack<TilfaeldighedGenerator> tilfaeldighedGeneratorListe = new Stack<TilfaeldighedGenerator>();

	private DateTime spilProduktFaktiskSlutDatoTid;
	private String spilProduktFaktiskSlutDatoTidString;
	private Long pokerAntalSpillereTillIndh;
	private Long pokerAntalSpillereTotal;
	private Long pokerAntalSpillereKval;
	private Double pokerBuyInTillIndh;
	private Double pokerBuyInTotal;
	private Double pokerFeeTillIndh;
	private Double pokerFeeTotal;
	private Double pokerRebuyTillIndh;
	private Double pokerRebuyTotal;
	private Double pokerAddonTillIndh;
	private Double pokerAddonTotal;
	private Long pokerBuyinAntalTillIndh;
	private Long pokerBuyinAntalTotal;
	private Long pokerRebuyAntalTillIndh;
	private Long pokerRebuyAntalTotal;
	private Long pokerAddonAntalTillIndh;
	private Long pokerAddonAntalTotal;
	private Double pokerTilfoejetPrizepool;
	private Double pokerGevinstTillIndh;
	private Double pokerGevinstTotal;
	private String valutaOplysningKode;

	public final void addNewTilfaeldighedGenerator() {
		tilfaeldighedGeneratorListe.push(new TilfaeldighedGenerator());
	}
	
	public Stack<TilfaeldighedGenerator> getTilfaeldighedGeneratorListe() {
		return tilfaeldighedGeneratorListe;
	}
	private final Stack<PuljespilSlutStandardRecord.Vinder> vinderListe = new Stack<PuljespilSlutStandardRecord.Vinder>();

	public final void addNewVinder() {
		vinderListe.push(new PuljespilSlutStandardRecord.Vinder());
	}

	public final Stack<PuljespilSlutStandardRecord.Vinder> getVinderListe() {
		return vinderListe;
	}

	public DateTime getSpilProduktFaktiskSlutDatoTid() {
		return spilProduktFaktiskSlutDatoTid;
	}
	public void setSpilProduktFaktiskSlutDatoTid(DateTime spilTypeFaktiskSlutDatoTid) {
		this.spilProduktFaktiskSlutDatoTid = spilTypeFaktiskSlutDatoTid;
	}
	
	public final String getSpilProduktFaktiskSlutDatoTidString() {
		return spilProduktFaktiskSlutDatoTidString;
	}

	public final void setSpilProduktFaktiskSlutDatoTidString(
			String spilProduktFaktiskSlutDatoTidString) {
		this.spilProduktFaktiskSlutDatoTidString = spilProduktFaktiskSlutDatoTidString;
	}

	public Long getPokerAntalSpillereTillIndh() {
		return pokerAntalSpillereTillIndh;
	}
	public void setPokerAntalSpillereTillIndh(Long pokerAntalSpillereTillIndh) {
		this.pokerAntalSpillereTillIndh = pokerAntalSpillereTillIndh;
	}
	public Long getPokerAntalSpillereTotal() {
		return pokerAntalSpillereTotal;
	}
	public void setPokerAntalSpillereTotal(Long pokerAntalSpillereTotal) {
		this.pokerAntalSpillereTotal = pokerAntalSpillereTotal;
	}
	public Long getPokerAntalSpillereKval() {
		return pokerAntalSpillereKval;
	}
	public void setPokerAntalSpillereKval(Long pokerAntalSpillereKval) {
		this.pokerAntalSpillereKval = pokerAntalSpillereKval;
	}
	public Double getPokerBuyInTillIndh() {
		return pokerBuyInTillIndh;
	}
	public void setPokerBuyInTillIndh(Double pokerBuyInTillIndh) {
		this.pokerBuyInTillIndh = pokerBuyInTillIndh;
	}
	public Double getPokerBuyInTotal() {
		return pokerBuyInTotal;
	}
	public void setPokerBuyInTotal(Double pokerBuyInTotal) {
		this.pokerBuyInTotal = pokerBuyInTotal;
	}
	public Double getPokerFeeTillIndh() {
		return pokerFeeTillIndh;
	}
	public void setPokerFeeTillIndh(Double pokerFeeTillIndh) {
		this.pokerFeeTillIndh = pokerFeeTillIndh;
	}
	public Double getPokerFeeTotal() {
		return pokerFeeTotal;
	}
	public void setPokerFeeTotal(Double pokerFeeTotal) {
		this.pokerFeeTotal = pokerFeeTotal;
	}
	public Double getPokerRebuyTillIndh() {
		return pokerRebuyTillIndh;
	}
	public void setPokerRebuyTillIndh(Double pokerRebuyTillIndh) {
		this.pokerRebuyTillIndh = pokerRebuyTillIndh;
	}
	public Double getPokerRebuyTotal() {
		return pokerRebuyTotal;
	}
	public void setPokerRebuyTotal(Double pokerRebuyTotal) {
		this.pokerRebuyTotal = pokerRebuyTotal;
	}
	public Double getPokerAddonTillIndh() {
		return pokerAddonTillIndh;
	}
	public void setPokerAddonTillIndh(Double pokerAddonTillIndh) {
		this.pokerAddonTillIndh = pokerAddonTillIndh;
	}
	public Double getPokerAddonTotal() {
		return pokerAddonTotal;
	}
	public void setPokerAddonTotal(Double pokerAddonTotal) {
		this.pokerAddonTotal = pokerAddonTotal;
	}
	public Long getPokerBuyinAntalTillIndh() {
		return pokerBuyinAntalTillIndh;
	}
	public void setPokerBuyinAntalTillIndh(Long pokerBuyinAntalTillIndh) {
		this.pokerBuyinAntalTillIndh = pokerBuyinAntalTillIndh;
	}
	public Long getPokerBuyinAntalTotal() {
		return pokerBuyinAntalTotal;
	}
	public void setPokerBuyinAntalTotal(Long pokerBuyinAntalTotal) {
		this.pokerBuyinAntalTotal = pokerBuyinAntalTotal;
	}
	public Long getPokerRebuyAntalTillIndh() {
		return pokerRebuyAntalTillIndh;
	}
	public void setPokerRebuyAntalTillIndh(Long pokerRebuyAntalTillIndh) {
		this.pokerRebuyAntalTillIndh = pokerRebuyAntalTillIndh;
	}
	public Long getPokerRebuyAntalTotal() {
		return pokerRebuyAntalTotal;
	}
	public void setPokerRebuyAntalTotal(Long pokerRebuyAntalTotal) {
		this.pokerRebuyAntalTotal = pokerRebuyAntalTotal;
	}
	public Long getPokerAddonAntalTillIndh() {
		return pokerAddonAntalTillIndh;
	}
	public void setPokerAddonAntalTillIndh(Long pokerAddonAntalTillIndh) {
		this.pokerAddonAntalTillIndh = pokerAddonAntalTillIndh;
	}
	public Long getPokerAddonAntalTotal() {
		return pokerAddonAntalTotal;
	}
	public void setPokerAddonAntalTotal(Long pokerAddonAntalTotal) {
		this.pokerAddonAntalTotal = pokerAddonAntalTotal;
	}
	public Double getPokerTilfoejetPrizepool() {
		return pokerTilfoejetPrizepool;
	}
	public void setPokerTilfoejetPrizepool(Double pokerTilfoejetPrizepool) {
		this.pokerTilfoejetPrizepool = pokerTilfoejetPrizepool;
	}
	
	public Double getPokerGevinstTillIndh() {
		return pokerGevinstTillIndh;
	}

	public void setPokerGevinstTillIndh(Double pokerGevinstTillIndh) {
		this.pokerGevinstTillIndh = pokerGevinstTillIndh;
	}

	public Double getPokerGevinstTotal() {
		return pokerGevinstTotal;
	}
	public void setPokerGevinstTotal(Double pokerGevinstTotal) {
		this.pokerGevinstTotal = pokerGevinstTotal;
	}
	public String getValutaOplysningKode() {
		return valutaOplysningKode;
	}
	public void setValutaOplysningKode(String valutaOplysningKode) {
		this.valutaOplysningKode = valutaOplysningKode;
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.PokerTurneringSlutStruktur;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PokerTurneringSlutStrukturStandardRecord [spilProduktFaktiskSlutDatoTid=");
		builder.append(spilProduktFaktiskSlutDatoTid);
		builder.append(", pokerAntalSpillereTillIndh=");
		builder.append(pokerAntalSpillereTillIndh);
		builder.append(", pokerAntalSpillereTotal=");
		builder.append(pokerAntalSpillereTotal);
		builder.append(", pokerAntalSpillereKval=");
		builder.append(pokerAntalSpillereKval);
		builder.append(", pokerBuyInTillIndh=");
		builder.append(pokerBuyInTillIndh);
		builder.append(", pokerBuyInTotal=");
		builder.append(pokerBuyInTotal);
		builder.append(", pokerFeeTillIndh=");
		builder.append(pokerFeeTillIndh);
		builder.append(", pokerFeeTotal=");
		builder.append(pokerFeeTotal);
		builder.append(", pokerRebuyTillIndh=");
		builder.append(pokerRebuyTillIndh);
		builder.append(", pokerRebuyTotal=");
		builder.append(pokerRebuyTotal);
		builder.append(", pokerAddonTillIndh=");
		builder.append(pokerAddonTillIndh);
		builder.append(", pokerAddonTotal=");
		builder.append(pokerAddonTotal);
		builder.append(", pokerBuyinAntalTillIndh=");
		builder.append(pokerBuyinAntalTillIndh);
		builder.append(", pokerBuyinAntalTotal=");
		builder.append(pokerBuyinAntalTotal);
		builder.append(", pokerRebuyAntalTillIndh=");
		builder.append(pokerRebuyAntalTillIndh);
		builder.append(", pokerRebuyAntalTotal=");
		builder.append(pokerRebuyAntalTotal);
		builder.append(", pokerAddonAntalTillIndh=");
		builder.append(pokerAddonAntalTillIndh);
		builder.append(", pokerAddonAntalTotal=");
		builder.append(pokerAddonAntalTotal);
		builder.append(", pokerTilfoejetPrizepool=");
		builder.append(pokerTilfoejetPrizepool);
		builder.append(", PokerGevinstTillIndh=");
		builder.append(pokerGevinstTillIndh);
		builder.append(", pokerGevinstTotal=");
		builder.append(pokerGevinstTotal);
		builder.append(", valutaOplysningKode=");
		builder.append(valutaOplysningKode);
		builder.append(", tilfaeldighedGeneratorListe=");
		builder.append(tilfaeldighedGeneratorListe);
		builder.append(", getSpilKategoriNavn()=");
		builder.append(getSpilKategoriNavn());
		builder.append(", getSpilProduktIdentifikation()=");
		builder.append(getSpilProduktIdentifikation());
		builder.append(", getSpilProduktNavn()=");
		builder.append(getSpilProduktNavn());
		builder.append(", getSpilFilIdentifikation()=");
		builder.append(getSpilFilIdentifikation());
		builder.append(", getSpilFilErstatningIdentifikation()=");
		builder.append(getSpilFilErstatningIdentifikation());
		builder.append(", getSpilCertifikatIdentifikation()=");
		builder.append(getSpilCertifikatIdentifikation());
		builder.append("]");
		return builder.toString();
	}
	
	@Override
	public void collectDimensions(Dimensions cache) {
		super.collectDimensions(cache);
		
		cache.addDate(spilProduktFaktiskSlutDatoTid);
		cache.addValuta(valutaOplysningKode);
		cache.addSession(getSpilProduktIdentifikation());
	}

}
