package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.datafile.Dimensions;
import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;

import java.util.Stack;

public class PokerTurneringStartStrukturStandardRecord extends AbstractGameStandardRecord {

	private boolean spilProduktAabentNetvaerk;
	private final Stack<Jackpot> jackpotListe = new Stack<Jackpot>();


	public boolean isSpilProduktAabentNetvaerk() {
		return spilProduktAabentNetvaerk;
	}

	public void setSpilProduktAabentNetvaerk(boolean spilProduktAabentNetvaerk) {
		this.spilProduktAabentNetvaerk = spilProduktAabentNetvaerk;
	}

	public Stack<Jackpot> getJackpotListe() {
		return jackpotListe;
	}

	public final void addNewJackpot() {
		jackpotListe.push(new Jackpot());
	}
	static public class Jackpot {
		public String jackpotIdentification;
		
		public String getJackpotIdentification() {
			return jackpotIdentification;
		}
		public void setJackpotIdentification(String jackpotIdentification) {
			this.jackpotIdentification = jackpotIdentification;
		}
		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("Jackpot [jackpotIdentification=");
			builder.append(jackpotIdentification);
			builder.append("]");
			return builder.toString();
		}
		
	}
	
	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.PokerTurneringStartStruktur;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PokerTurneringStartStrukturStandardRecord [spilProduktAabentNetvaerk=");
		builder.append(spilProduktAabentNetvaerk);
		builder.append(", jackpotListe=");
		builder.append(jackpotListe);
		builder.append("]");
		return builder.toString();
	}
	
	@Override
	public void collectDimensions(Dimensions cache) {
		super.collectDimensions(cache);
		
		cache.addSession(getSpilProduktIdentifikation());

		for (Jackpot jackpot : jackpotListe) {
			cache.addJackpot(jackpot.getJackpotIdentification());
		}
	}
	
}
