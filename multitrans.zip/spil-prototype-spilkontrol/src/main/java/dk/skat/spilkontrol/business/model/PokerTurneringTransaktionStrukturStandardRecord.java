package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.PuljespilTransaktionStandardRecord.SpillerOgKuponType.Jackpot;
import dk.skat.spilkontrol.business.model.datafile.Dimensions;
import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class PokerTurneringTransaktionStrukturStandardRecord extends AbstractGameStandardRecord {
	
	private Stack<TurneringTransaktionInfoType> turneringTransaktionInfoListe = new Stack<TurneringTransaktionInfoType>();
	
	public TurneringTransaktionInfoType getLastAddElement() {
		return turneringTransaktionInfoListe.peek();
	}
	
	public TurneringTransaktionInfoType addTurneringTransaktionInfoTypeElement(TurneringTransaktionInfoType el) {
		return turneringTransaktionInfoListe.push(el);
	}
	
	public Stack<TurneringTransaktionInfoType> getTurneringTransaktionInfoListe() {
		return turneringTransaktionInfoListe;
	}

	public final class TurneringTransaktionInfoType {
		private String spillerInformationidentifikation;
		private String spilTransaktionIdentifikation;
		private DateTime spilKoebDatoTid;
		private String spilKoebDatoTidString;
		private String spilSalgskanal;
		private String pokerKoebType;
		private Double pokerKoebBeloeb;
		private Double pokerKoebFee;
		private String valutaOplysningkode;
		private String spilTerminalIdentifikation;
		private String spilHjemmeside;
		private Boolean spilAnnullering;
		private DateTime spilAnnulleringDatoTid;
		private String spilAnnulleringDatoTidString;
		private final Stack<Jackpot> jackpotListe = new Stack<Jackpot>();

		public final void addNewJackpot() {
			jackpotListe.push(new Jackpot());
		}

		public String getSpillerInformationidentifikation() {
			return spillerInformationidentifikation;
		}
		public void setSpillerInformationidentifikation(
				String spillerInformationidentifikation) {
			this.spillerInformationidentifikation = spillerInformationidentifikation;
		}

		public void setSpilIdentifikation(String spilIdentifikation) {
			this.spilTransaktionIdentifikation = spilIdentifikation;
		}
		public DateTime getSpilKoebDatoTid() {
			return spilKoebDatoTid;
		}
		public void setSpilKoebDatoTid(DateTime spilKoebDatoTid) {
			this.spilKoebDatoTid = spilKoebDatoTid;
		}
		public String getSpilSalgskanal() {
			return spilSalgskanal;
		}
		public void setSpilSalgskanal(String spilSalgskanal) {
			this.spilSalgskanal = spilSalgskanal;
		}
		public String getSpilTerminalIdentifikation() {
			return spilTerminalIdentifikation;
		}
		public void setSpilTerminalIdentifikation(String spilTerminalIdentifikation) {
			this.spilTerminalIdentifikation = spilTerminalIdentifikation;
		}
		public String getPokerKoebType() {
			return pokerKoebType;
		}
		public void setPokerKoebType(String pokerKoebType) {
			this.pokerKoebType = pokerKoebType;
		}
		public Double getPokerKoebBeloeb() {
			return pokerKoebBeloeb;
		}
		public void setPokerKoebBeloeb(Double pokerKoebBeloeb) {
			this.pokerKoebBeloeb = pokerKoebBeloeb;
		}
		public Double getPokerKoebFee() {
			return pokerKoebFee;
		}
		public void setPokerKoebFee(Double pokerKoebFee) {
			this.pokerKoebFee = pokerKoebFee;
		}
		public Boolean getSpilAnnullering() {
			return spilAnnullering;
		}
		public void setSpilAnnullering(Boolean spilAnnullering) {
			this.spilAnnullering = spilAnnullering;
		}
		public DateTime getSpilAnnulleringDatoTid() {
			return spilAnnulleringDatoTid;
		}
		public void setSpilAnnulleringDatoTid(DateTime spilAnnulleringDatoTid) {
			this.spilAnnulleringDatoTid = spilAnnulleringDatoTid;
		}

		public String getValutaOplysningkode() {
			return valutaOplysningkode;
		}
		public void setValutaOplysningkode(String valutaOplysningkode) {
			this.valutaOplysningkode = valutaOplysningkode;
		}
		
		public String getSpilHjemmeside() {
			return spilHjemmeside;
		}

		public void setSpilHjemmeside(String spilHjemmeside) {
			this.spilHjemmeside = spilHjemmeside;
		}

		public Stack<Jackpot> getJackpotListe() {
			return jackpotListe;
		}
		public String getSpilTransaktionIdentifikation() {
			return spilTransaktionIdentifikation;
		}
		public void setSpilTransaktionIdentifikation(
				String spilTransaktionIdentifikation) {
			this.spilTransaktionIdentifikation = spilTransaktionIdentifikation;
		}
		
		public final String getSpilKoebDatoTidString() {
			return spilKoebDatoTidString;
		}

		public final void setSpilKoebDatoTidString(String spilKoebDatoTidString) {
			this.spilKoebDatoTidString = spilKoebDatoTidString;
		}

		public final String getSpilAnnulleringDatoTidString() {
			return spilAnnulleringDatoTidString;
		}

		public final void setSpilAnnulleringDatoTidString(
				String spilAnnulleringDatoTidString) {
			this.spilAnnulleringDatoTidString = spilAnnulleringDatoTidString;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("TurneringTransaktionInfoType [spillerInformationidentifikation=");
			builder.append(spillerInformationidentifikation);
			builder.append(", spilTransaktionIdentifikation=");
			builder.append(spilTransaktionIdentifikation);
			builder.append(", spilKoebDatoTid=");
			builder.append(spilKoebDatoTid);
			builder.append(", spilSalgskanal=");
			builder.append(spilSalgskanal);
			builder.append(", pokerKoebType=");
			builder.append(pokerKoebType);
			builder.append(", pokerKoebBeloeb=");
			builder.append(pokerKoebBeloeb);
			builder.append(", pokerKoebFee=");
			builder.append(pokerKoebFee);
			builder.append(", valutaOplysningkode=");
			builder.append(valutaOplysningkode);
			builder.append(", spilTerminalIdentifikation=");
			builder.append(spilTerminalIdentifikation);
			builder.append(", spilHjemmeside=");
			builder.append(spilHjemmeside);
			builder.append(", spilAnnullering=");
			builder.append(spilAnnullering);
			builder.append(", spilAnnulleringDatoTid=");
			builder.append(spilAnnulleringDatoTid);
			builder.append(", jackpotListe=");
			builder.append(jackpotListe);
			builder.append("]");
			return builder.toString();
		}


	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.PokerTurneringTransaktionStruktur;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PokerTurneringTransaktionStrukturStandardRecord [turneringTransaktionInfoListe=");
		builder.append(turneringTransaktionInfoListe);
		builder.append(", getSpilKategoriNavn()=");
		builder.append(getSpilKategoriNavn());
		builder.append(", getSpilProduktIdentifikation()=");
		builder.append(getSpilProduktIdentifikation());
		builder.append(", getSpilProduktNavn()=");
		builder.append(getSpilProduktNavn());
		builder.append(", getSpilFilIdentifikation()=");
		builder.append(getSpilFilIdentifikation());
		builder.append(", getSpilFilErstatningIdentifikation()=");
		builder.append(getSpilFilErstatningIdentifikation());
		builder.append(", getSpilCertifikatIdentifikation()=");
		builder.append(getSpilCertifikatIdentifikation());
		builder.append("]");
		return builder.toString();
	}
	
	@Override
	public void collectDimensions(Dimensions cache) {
		super.collectDimensions(cache);
		
		cache.addSession(this.getSpilProduktIdentifikation());
		for (TurneringTransaktionInfoType tunering : turneringTransaktionInfoListe) {
			cache.addDate(tunering.spilAnnulleringDatoTid);
			cache.addDate(tunering.spilKoebDatoTid);
			cache.addSpiller(tunering.getSpillerInformationidentifikation());
			cache.addTransaction(tunering.getSpilTransaktionIdentifikation(), tunering.getSpilAnnullering());
			cache.addValuta(tunering.getValutaOplysningkode());

			for (Jackpot jackpot : tunering.getJackpotListe()) {
				cache.addJackpot(jackpot.getJackpotIdentifikation());
			}
		}
		
	}

}
