package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

public class PuljespilEndOfGameStandardRecord extends AbstractGameStandardRecord {

	// inside Pulje tag
	private DateTime puljespilEndOfGameDatoTid;
	private String puljespilEndOfGameDatoTidString;
	
	private Double puljespilIndskudSpilTillIndh;
	private Double puljespilIndskudSpilTotal;
	private Double puljespilIndskudJackpotTillIndh;
	private Double puljespilIndskudJackpotTotal;

	private Long puljespilAntalRaekkerTillIndh;
	private Long puljespilAntalRaekkerTotal;

	private Double puljespilGevinstPuljeBeloeb;
	private String valutaOplysningKode;

	public final DateTime getPuljespilEndOfGameDatoTid() {
		return puljespilEndOfGameDatoTid;
	}
	public final void setPuljespilEndOfGameDatoTid(DateTime puljespilEndOfGameDatoTid) {
		this.puljespilEndOfGameDatoTid = puljespilEndOfGameDatoTid;
	}
	
	public final String getPuljespilEndOfGameDatoTidString() {
		return puljespilEndOfGameDatoTidString;
	}
	public final void setPuljespilEndOfGameDatoTidString(
			String puljespilEndOfGameDatoTidString) {
		this.puljespilEndOfGameDatoTidString = puljespilEndOfGameDatoTidString;
	}
	public final Double getPuljespilIndskudSpilTillIndh() {
		return puljespilIndskudSpilTillIndh;
	}
	public final void setPuljespilIndskudSpilTillIndh(
			Double puljespilIndskudSpilTillIndh) {
		this.puljespilIndskudSpilTillIndh = puljespilIndskudSpilTillIndh;
	}
	public final Double getPuljespilIndskudSpilTotal() {
		return puljespilIndskudSpilTotal;
	}
	public final void setPuljespilIndskudSpilTotal(Double puljespilIndskudSpilTotal) {
		this.puljespilIndskudSpilTotal = puljespilIndskudSpilTotal;
	}
	public final Double getPuljespilIndskudJackpotTillIndh() {
		return puljespilIndskudJackpotTillIndh;
	}
	public final void setPuljespilIndskudJackpotTillIndh(
			Double puljespilIndskudJackpotTillIndh) {
		this.puljespilIndskudJackpotTillIndh = puljespilIndskudJackpotTillIndh;
	}
	public final Double getPuljespilIndskudJackpotTotal() {
		return puljespilIndskudJackpotTotal;
	}
	public final void setPuljespilIndskudJackpotTotal(
			Double puljespilIndskudJackpotTotal) {
		this.puljespilIndskudJackpotTotal = puljespilIndskudJackpotTotal;
	}
	public final Long getPuljespilAntalRaekkerTillIndh() {
		return puljespilAntalRaekkerTillIndh;
	}
	public final void setPuljespilAntalRaekkerTillIndh(
			Long puljespilAntalRaekkerTillIndh) {
		this.puljespilAntalRaekkerTillIndh = puljespilAntalRaekkerTillIndh;
	}
	public final Long getPuljespilAntalRaekkerTotal() {
		return puljespilAntalRaekkerTotal;
	}
	public final void setPuljespilAntalRaekkerTotal(Long puljespilAntalRaekkerTotal) {
		this.puljespilAntalRaekkerTotal = puljespilAntalRaekkerTotal;
	}
	public final Double getPuljespilGevinstPuljeBeloeb() {
		return puljespilGevinstPuljeBeloeb;
	}
	public final void setPuljespilGevinstPuljeBeloeb(
			Double puljespilGevinstPuljeBeloeb) {
		this.puljespilGevinstPuljeBeloeb = puljespilGevinstPuljeBeloeb;
	}
	public final String getValutaOplysningKode() {
		return valutaOplysningKode;
	}
	public final void setValutaOplysningKode(String valutaOplysningKode) {
		this.valutaOplysningKode = valutaOplysningKode;
	}
	
	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.PuljespilEndOfGameStruktur;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PuljespilEndOfGameStandardRecord [puljespilEndOfGameDatoTid=");
		builder.append(puljespilEndOfGameDatoTid);
		builder.append(", puljespilIndskudSpilTillIndh=");
		builder.append(puljespilIndskudSpilTillIndh);
		builder.append(", puljespilIndskudSpilTotal=");
		builder.append(puljespilIndskudSpilTotal);
		builder.append(", puljespilIndskudJackpotTillIndh=");
		builder.append(puljespilIndskudJackpotTillIndh);
		builder.append(", puljespilIndskudJackpotTotal=");
		builder.append(puljespilIndskudJackpotTotal);
		builder.append(", puljespilAntalRaekkerTillIndh=");
		builder.append(puljespilAntalRaekkerTillIndh);
		builder.append(", puljespilAntalRaekkerTotal=");
		builder.append(puljespilAntalRaekkerTotal);
		builder.append(", puljespilGevinstPuljeBeloeb=");
		builder.append(puljespilGevinstPuljeBeloeb);
		builder.append(", valutaOplysningKode=");
		builder.append(valutaOplysningKode);
		builder.append(", spilFilErstatningIdentifikation=");
		builder.append(getSpilFilErstatningIdentifikation());
		builder.append(", *** spilCertifikatIdentifikation=");
		builder.append(getSpilCertifikatIdentifikation());
		builder.append(", spilKategoriNavn=");
		builder.append(getSpilKategoriNavn());
		builder.append(", spilProduktNavn=");
		builder.append(getSpilProduktNavn());
		builder.append(", spilProduktIdentifikation=");
		builder.append(getSpilProduktIdentifikation());
		builder.append(", spilFilIdentifikation=");
		builder.append(getSpilFilIdentifikation());
		builder.append("]");
		return builder.toString();
	}
}
