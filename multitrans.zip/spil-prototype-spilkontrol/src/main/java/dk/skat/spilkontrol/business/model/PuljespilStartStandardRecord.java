package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class PuljespilStartStandardRecord extends AbstractGameStandardRecord {
	
	final private Stack<GenerelPuljeNoegle> generelPuljeNoegleListe = new Stack<GenerelPuljeNoegle>();
	
	// Pulje
	private boolean spilProduktAabentNetvaerk;
	private Double puljespilGevinstPuljeProcent;
    private Long puljespilAntalResultatPuljer;
	private Long puljespilAntalKampe;
	private Double puljespilRaekkePris;

	private DateTime spilForventetSlutDatoTid;
	private String spilForventetSlutDatoTidString;
    private String valutaOplysningKode;
	
	public boolean isSpilTypeAabentNetvaerk() {
		return spilProduktAabentNetvaerk;
	}
	
	public void setSpilProduktAabentNetvaerk(boolean spilTypeAabentNetvaerk) {
		this.spilProduktAabentNetvaerk = spilTypeAabentNetvaerk;
	}
	
	private final Stack<ResultatPulje> resultatPuljeListe =
			new Stack<ResultatPulje>();
	
	public void addNewGenerelPuljeNoegle() {
		generelPuljeNoegleListe.push(new GenerelPuljeNoegle());
	}

	public void addNewResultatPulje() {
		resultatPuljeListe.push(new ResultatPulje());
	}
	
	public final Double getPuljespilGevinstPuljeProcent() {
		return puljespilGevinstPuljeProcent;
	}

	public final void setPuljespilGevinstPuljeProcent(
			Double puljespilGevinstPuljeProcent) {
		this.puljespilGevinstPuljeProcent = puljespilGevinstPuljeProcent;
	}

	public final Long getPuljespilAntalResultatPuljer() {
		return puljespilAntalResultatPuljer;
	}

	public final void setPuljespilAntalResultatPuljer(
			Long puljespilAntalResultatPuljer) {
		this.puljespilAntalResultatPuljer = puljespilAntalResultatPuljer;
	}

	public final Long getPuljespilAntalKampe() {
		return puljespilAntalKampe;
	}

	public final void setPuljespilAntalKampe(Long puljespilAntalKampe) {
		this.puljespilAntalKampe = puljespilAntalKampe;
	}
	
    public final Double getPuljespilRaekkePris() {
		return puljespilRaekkePris;
	}

	public final void setPuljespilRaekkePris(Double puljespilRaekkePris) {
		this.puljespilRaekkePris = puljespilRaekkePris;
	}

	public final DateTime getSpilForventetSlutDatoTid() {
		return spilForventetSlutDatoTid;
	}

	public final void setSpilForventetSlutDatoTid(DateTime spilForventetSlutDatoTid) {
		this.spilForventetSlutDatoTid = spilForventetSlutDatoTid;
	}

	public final String getSpilForventetSlutDatoTidString() {
		return spilForventetSlutDatoTidString;
	}

	public final void setSpilForventetSlutDatoTidString(
			String spilForventetSlutDatoTidString) {
		this.spilForventetSlutDatoTidString = spilForventetSlutDatoTidString;
	}

	public final String getValutaOplysningKode() {
		return valutaOplysningKode;
	}

	public final void setValutaOplysningKode(String valutaOplysningKode) {
		this.valutaOplysningKode = valutaOplysningKode;
	}

	public final Stack<GenerelPuljeNoegle> getGenerelPuljeNoegleListe() {
		return generelPuljeNoegleListe;
	}

	public final Stack<ResultatPulje> getResultatPuljeListe() {
		return resultatPuljeListe;
	}

	public static class GenerelPuljeNoegle {
		
		private Long puljespilNoegleKampNummer;
		
		private String puljespilNoegleBeskrivelse;
		
		private Long puljespilNoegleGenerel;
		
		public final Long getPuljespilNoegleKampNummer() {
			return puljespilNoegleKampNummer;
		}
		public final void setPuljespilNoegleKampNummer(Long puljespilNoegleKampNummer) {
			this.puljespilNoegleKampNummer = puljespilNoegleKampNummer;
		}
		public final String getPuljespilNoegleBeskrivelse() {
			return puljespilNoegleBeskrivelse;
		}
		public final void setPuljespilNoegleBeskrivelse(
				String puljespilNoegleBeskrivelse) {
			this.puljespilNoegleBeskrivelse = puljespilNoegleBeskrivelse;
		}
		public final Long getPuljespilNoegleGenerel() {
			return puljespilNoegleGenerel;
		}
		public final void setPuljespilNoegleGenerel(Long puljespilNoegleGenerel) {
			this.puljespilNoegleGenerel = puljespilNoegleGenerel;
		}
		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("GenerelPuljeNoegle [puljespilNoegleKampNummer=");
			builder.append(puljespilNoegleKampNummer);
			builder.append(", puljespilNoegleBeskrivelse=");
			builder.append(puljespilNoegleBeskrivelse);
			builder.append(", puljespilNoegleGenerel=");
			builder.append(puljespilNoegleGenerel);
			builder.append("]");
			return builder.toString();
		}
		
	}

	public static class ResultatPulje {
		
		private String gevinstPuljeIdentifikation;
		
		private Double gevinstPuljeGevinstProcent;
		
		private Double gevinstPuljeOverfoerselPrimo;
		
		public Double getGevinstPuljeOverfoerselPrimo() {
			return gevinstPuljeOverfoerselPrimo;
		}
		public void setGevinstPuljeOverfoerselPrimo(Double gevinstPuljeOverfoerselPrimo) {
			this.gevinstPuljeOverfoerselPrimo = gevinstPuljeOverfoerselPrimo;
		}
		public final String getGevinstPuljeIdentifikation() {
			return gevinstPuljeIdentifikation;
		}
		public final void setGevinstPuljeIdentifikation(
				String gevinstPuljeIdentifikation) {
			this.gevinstPuljeIdentifikation = gevinstPuljeIdentifikation;
		}
		public final Double getGevinstPuljeGevinstProcent() {
			return gevinstPuljeGevinstProcent;
		}
		public final void setGevinstPuljeGevinstProcent(
				Double gevinstPuljeGevinstProcent) {
			this.gevinstPuljeGevinstProcent = gevinstPuljeGevinstProcent;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("ResultatPulje [gevinstPuljeIdentifikation=");
			builder.append(gevinstPuljeIdentifikation);
			builder.append(", gevinstPuljeGevinstProcent=");
			builder.append(gevinstPuljeGevinstProcent);
			builder.append(", GevinstPuljeOverfoerselPrimo=");
			builder.append(gevinstPuljeOverfoerselPrimo);
			builder.append("]");
			return builder.toString();
		}
		
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.PuljespilStartStruktur;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PuljespilStartStandardRecord [generelPuljeNoegleListe=");
		builder.append(generelPuljeNoegleListe);
		builder.append(", spilProduktAabentNetvaerk=");
		builder.append(spilProduktAabentNetvaerk);
		builder.append(", puljespilGevinstPuljeProcent=");
		builder.append(puljespilGevinstPuljeProcent);
		builder.append(", puljespilAntalResultatPuljer=");
		builder.append(puljespilAntalResultatPuljer);
		builder.append(", puljespilAntalKampe=");
		builder.append(puljespilAntalKampe);
		builder.append(", puljespilRaekkePris=");
		builder.append(puljespilRaekkePris);
		builder.append(", spilForventetSlutDatoTid=");
		builder.append(spilForventetSlutDatoTid);
		builder.append(", valutaOplysningKode=");
		builder.append(valutaOplysningKode);
		builder.append(", resultatPuljeListe=");
		builder.append(resultatPuljeListe);
		builder.append(", spilFilErstatningIdentifikation=");
		builder.append(getSpilFilErstatningIdentifikation());
		builder.append(", *** spilCertifikatIdentifikation=");
		builder.append(getSpilCertifikatIdentifikation());
		builder.append(", spilKategoriNavn=");
		builder.append(getSpilKategoriNavn());
		builder.append(", spilProduktNavn=");
		builder.append(getSpilProduktNavn());
		builder.append(", spilProduktIdentifikation=");
		builder.append(getSpilProduktIdentifikation());
		builder.append(", spilFilIdentifikation=");
		builder.append(getSpilFilIdentifikation());
		builder.append("]");
		return builder.toString();
	}
}
