package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.PuljespilTransaktionStandardRecord.SpillerOgKuponType.Jackpot;
import dk.skat.spilkontrol.business.model.PuljespilTransaktionStandardRecord.SpillerOgKuponType.Spilkombinationer;
import dk.skat.spilkontrol.business.model.datafile.Dimensions;
import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.joda.time.DateTime;

import java.util.Stack;

public class PuljespilTransaktionStandardRecord extends AbstractGameStandardRecord {
	
	private final Stack<SpillerOgKuponType> spillerOgKupon = new Stack<SpillerOgKuponType>();

	public final Stack<SpillerOgKuponType> getSpillerOgKuponListe() {
		return spillerOgKupon;
	}

	public final void addNewSpillerOgKupon() {
		spillerOgKupon.push(new SpillerOgKuponType());
	}

	public PuljespilTransaktionStandardRecord() {
	}
	
	public static class SpillerOgKuponType {

		// These fields are common with Kasino
		private String spillerInformationIdentifikation;
		private String spilTransaktionIdentifikation;

		private DateTime spilKoebDatoTid;
		private String spilKoebDatoTidString;
		
		private String spilSalgskanal;

		// These fields are special for PuljespilTransaktion
		private Long spilAntalRaekker;
		private Double spilIndskud;
		private Double spilIndskudSpil;
		private String valuta;
		
		private String spilTerminalidentification;
		private String spilHjemmeside;

		private Boolean spilAnnullering; // nullable
		private DateTime spilAnnulleringDatoTid; // nullable
		private String spilAnnulleringDatoTidString;
		private final Stack<Spilkombinationer> spilkombinationerListe = new Stack<Spilkombinationer>();

		private final Stack<Jackpot> jackpotListe = new Stack<Jackpot>();

		public final String getSpilKoebDatoTidString() {
			return spilKoebDatoTidString;
		}

		public final void setSpilKoebDatoTidString(String spilKoebDatoTidString) {
			this.spilKoebDatoTidString = spilKoebDatoTidString;
		}

		public final String getSpilAnnulleringDatoTidString() {
			return spilAnnulleringDatoTidString;
		}

		public final void setSpilAnnulleringDatoTidString(
				String spilAnnulleringDatoTidString) {
			this.spilAnnulleringDatoTidString = spilAnnulleringDatoTidString;
		}

		public String getSpilHjemmeside() {
			return spilHjemmeside;
		}

		public void setSpilHjemmeside(String spilHjemmeside) {
			this.spilHjemmeside = spilHjemmeside;
		}

		public Stack<Jackpot> getJackpotListe() {
			return jackpotListe;
		}

		public final String getSpillerInformationIdentifikation() {
			return spillerInformationIdentifikation;
		}

		public final void setSpillerInformationIdentifikation(
				String spillerInformationIdentifikation) {
			this.spillerInformationIdentifikation = spillerInformationIdentifikation;
		}

		public final String getSpilIdentifikation() {
			return spilTransaktionIdentifikation;
		}

		public final void setSpilTransaktionIdentifikation(String spilIdentifikation) {
			this.spilTransaktionIdentifikation = spilIdentifikation;
		}

		public final DateTime getSpilKoebDatoTid() {
			return spilKoebDatoTid;
		}

		public final void setSpilKoebDatoTid(DateTime spilKoebDatoTid) {
			this.spilKoebDatoTid = spilKoebDatoTid;
		}

		public final String getSpilSalgskanal() {
			return spilSalgskanal;
		}


		public final void setSpilSalgskanal(String spilSalgskanal) {
			this.spilSalgskanal = spilSalgskanal;
		}


		public final String getSpilTerminalidentification() {
			return spilTerminalidentification;
		}


		public final void setSpilTerminalidentification(
				String spilTerminalidentification) {
			this.spilTerminalidentification = spilTerminalidentification;
		}

		public final Boolean getSpilAnnullering() {
			return spilAnnullering;
		}


		public final void setSpilAnnullering(Boolean spilAnnullering) {
			this.spilAnnullering = spilAnnullering;
		}

		public final DateTime getSpilAnnulleringDatoTid() {
			return spilAnnulleringDatoTid;
		}

		public final void setSpilAnnulleringDatoTid(DateTime spilAnnulleringDatoTid) {
			this.spilAnnulleringDatoTid = spilAnnulleringDatoTid;
		}

		public final String getValuta() {
			return valuta;
		}

		public final void setValuta(String valuta) {
			this.valuta = valuta;
		}


		public final Double getSpilIndskudTilSpil() {
			return spilIndskudSpil;
		}

		public final void setSpilIndskudSpil(Double spilIndskudTilSpil) {
			this.spilIndskudSpil = spilIndskudTilSpil;
		}


		public final Long getSpilAntalRaekker() {
			return spilAntalRaekker;
		}


		public final void setSpilAntalRaekker(Long spilAntalRaekker) {
			this.spilAntalRaekker = spilAntalRaekker;
		}


		public final Double getSpilIndskud() {
			return spilIndskud;
		}

		public final void setSpilIndskud(Double spilIndskud) {
			this.spilIndskud = spilIndskud;
		}

		/**
		 * Special information for Pool games.
		 */
		public final Stack<Spilkombinationer> getSpilkombinationerListe() {
			return spilkombinationerListe;
		}
		
		public final void addNewSpilkombinationer() {
			spilkombinationerListe.push(new Spilkombinationer());
		}
		
		public final void addNewJackpot() {
			jackpotListe.push(new Jackpot());
		}

		public static class Jackpot {
			private String jackpotIdentifikation; // nullable
			private Double spilIndskudJackpot; // nullable
			public String getJackpotIdentifikation() {
				return jackpotIdentifikation;
			}
			public void setJackpotIdentifikation(String jackpotIdentifikation) {
				this.jackpotIdentifikation = jackpotIdentifikation;
			}
			public Double getSpilIndskudJackpot() {
				return spilIndskudJackpot;
			}
			public void setSpilIndskudJackpot(Double spilIndskudJackpot) {
				this.spilIndskudJackpot = spilIndskudJackpot;
			}
			@Override
			public String toString() {
				StringBuilder builder = new StringBuilder();
				builder.append("Jackpot [jackpotIdentifikation=");
				builder.append(jackpotIdentifikation);
				builder.append(", spilIndskudJackpot=");
				builder.append(spilIndskudJackpot);
				builder.append("]");
				return builder.toString();
			}

		}

		public static class Spilkombinationer {
			private Long raekkeNummer;

			private String raekkeSpilkombinationer;

			public final Long getRaekkeNummer() {
				return raekkeNummer;
			}

			public final void setRaekkeNummer(Long raekkeNummer) {
				this.raekkeNummer = raekkeNummer;
			}

			public final String getRaekkeSpilkombinationer() {
				return raekkeSpilkombinationer;
			}

			public final void setRaekkeSpilkombinationer(String raekkeSpilkombinationer) {
				this.raekkeSpilkombinationer = raekkeSpilkombinationer;
			}

			@Override
			public String toString() {
				StringBuilder builder = new StringBuilder();
				builder.append("Spilkombinationer [raekkeNummer=");
				builder.append(raekkeNummer);
				builder.append(", raekkeSpilkombinationer=");
				builder.append(raekkeSpilkombinationer);
				builder.append("]");
				return builder.toString();
			}
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("SpillerOgKuponType [spillerInformationIdentifikation=");
			builder.append(spillerInformationIdentifikation);
			builder.append(", spilIdentifikation=");
			builder.append(spilTransaktionIdentifikation);
			builder.append(", spilKoebDatoTid=");
			builder.append(spilKoebDatoTid);
			builder.append(", spilSalgskanal=");
			builder.append(spilSalgskanal);
			builder.append(", spilTerminalidentification=");
			builder.append(spilTerminalidentification);
			builder.append(", spilHjemmeside=");
			builder.append(spilHjemmeside);
			builder.append(", jackpotliste=");
			builder.append(getJackpotListe());
			builder.append(", spilAnnullering=");
			builder.append(spilAnnullering);
			builder.append(", spilAnnulleringDatoTid=");
			builder.append(spilAnnulleringDatoTid);
			builder.append(", valuta=");
			builder.append(valuta);
			builder.append(", spilIndskudSpil=");
			builder.append(spilIndskudSpil);
			builder.append(", spilAntalRaekker=");
			builder.append(spilAntalRaekker);
			builder.append(", spilIndskud=");
			builder.append(spilIndskud);
			builder.append(", spilkombinationerListe=");
			builder.append(spilkombinationerListe);
			builder.append("]");
			return builder.toString();
		}
		
	}

	@Override
	public StandardRecordTypes getStructureType() {
		return StandardRecordTypes.PuljespilTransaktionStruktur;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PuljespilTransaktionStandardRecord [");
		builder.append("spilFilIdentifikation=");
		builder.append(getSpilFilIdentifikation());
		builder.append(", spilFilErstatningIdentifikation=");
		builder.append(getSpilFilErstatningIdentifikation());
		builder.append(", *** spilCertifikatIdentifikation=");
		builder.append(getSpilCertifikatIdentifikation());
		builder.append(", spilKategoriNavn=");
		builder.append(getSpilKategoriNavn());
		builder.append(", spilProduktNavn=");
		builder.append(getSpilProduktNavn());
		builder.append(", spilProduktIdentifikation=");
		builder.append(getSpilProduktIdentifikation());
		builder.append(", spillerOgKupon=");
		builder.append(spillerOgKupon);
		builder.append("]");
		return builder.toString();
	}

	@Override
	public void collectDimensions(Dimensions cache) {
		super.collectDimensions(cache);
		
		cache.addSession(getSpilProduktIdentifikation());
		
		for (SpillerOgKuponType sk : spillerOgKupon) {
			cache.addDate(sk.spilAnnulleringDatoTid);
			cache.addDate(sk.spilKoebDatoTid);
			cache.addTransaction(sk.spilTransaktionIdentifikation, sk.spilAnnullering);
			cache.addSpiller(sk.spillerInformationIdentifikation);
			cache.addValuta(sk.valuta);
			
			for (Spilkombinationer komb : sk.spilkombinationerListe) {
				cache.addRaekke(sk.spilTransaktionIdentifikation, getSpilProduktIdentifikation(), komb.raekkeNummer);
			}
			
			for(Jackpot jackpot: sk.jackpotListe){
				cache.addJackpot(jackpot.jackpotIdentifikation);
			}
		}
		
	}
}
