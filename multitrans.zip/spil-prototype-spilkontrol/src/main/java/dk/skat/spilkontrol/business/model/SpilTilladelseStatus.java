package dk.skat.spilkontrol.business.model;

public enum SpilTilladelseStatus {

	CONFIRMED,
	NOT_CONFIRMED;
	
}
