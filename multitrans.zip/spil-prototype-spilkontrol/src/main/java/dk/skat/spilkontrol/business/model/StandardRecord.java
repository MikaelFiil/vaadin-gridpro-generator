package dk.skat.spilkontrol.business.model;

import dk.skat.spilkontrol.business.model.datafile.Dimensions;
import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import lombok.Data;

@Data
public abstract class StandardRecord {

	private String spilFilIdentifikation;
    private String spilFilErstatningIdentifikation;
    private String safeIdentifikation;
	private String spilCertifikatIdentifikation;
	private String xmlFileHash;

    protected StandardRecord() { }

    public abstract StandardRecordTypes getStructureType();

	public void collectDimensions(Dimensions cache) {
	}
	
}
