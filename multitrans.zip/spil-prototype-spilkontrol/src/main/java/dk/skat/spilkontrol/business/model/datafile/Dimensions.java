package dk.skat.spilkontrol.business.model.datafile;

import org.joda.time.DateTime;

import java.util.Date;

public interface Dimensions {

	void addJackpot(String identifikation);
	void addSpiller(String identifikation);
	void addSession(String identifikation);
	void addTransaction(String identifikation, Boolean annulleret);
	void addDate(DateTime date);
	void addDate(Date date);
	void addValuta(String valuta);
	void addRaekke(String spilTransaktionIdentifikation, String spilproduktidentifikation, Long raekkeNummer);
	
	Long lookupJackpot(String identifikation);
	Long lookupSpiller(String identifikation);
	Long lookupSession(String identifikation);
	String lookupTransaction(String identifikation);
	DrillDateProxy lookupDrillDate(Date date);
	DrillDateProxy lookupDrillDate(DateTime date);
	String lookupValuta(String valuta);
	Long lookupRaekke(String spilTransaktionIdentifikation, String spilproduktidentifikation, Long raekkeNummer);
	
	String getTilladelsesindehaverNavn();
	
}