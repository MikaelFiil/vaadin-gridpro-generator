package dk.skat.spilkontrol.business.model.datafile;



import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import java.util.Date;

public class DrillDateProxy {

	public final DateTime originalDateUTC;
	public final Date realDate;
	public final Long drillDateId; 
	
	public DrillDateProxy(DateTime dt, Date realDate, Long drillDateId) {
		if(dt == null){
			throw new IllegalArgumentException("Datetime må ikke være null!");
		}
		
		this.drillDateId = drillDateId;
		this.realDate = realDate;
		originalDateUTC = dt.withZone(DateTimeZone.UTC);
	}

	@Override
	public String toString() {
		return realDate.toString();
	}

	public static Date truncate(DateTime readDate) {
		return readDate.withZone(DateTimeZone.UTC).toDateMidnight().toDateTime().toDate();
	}
}
