package dk.skat.spilkontrol.business.model.standardrecords;

import dk.skat.spilkontrol.commons.string.StringUtil;

public enum StandardRecordTypes {

	KasinospilPrSessionStruktur(1),
	KasinoSpilPrTraekStruktur(2),
	PuljespilTransaktionStruktur(3),
	PuljespilEndOfGameStruktur(4),
	PuljespilSlutStruktur(5),
	PuljespilStartStruktur(6),
	JackpotUdloesningStruktur(7),
	EndOfDayRapportStruktur(8),
	FastOddsTransaktionStruktur(9),
	FastOddsSlutStruktur(10),
	PokerCashGamePrHaandStruktur(11),
	PokerCashGamePrSessionStruktur(12),
	PokerTurneringTransaktionStruktur(13),
	ManagerspilTransaktionStruktur(14),
	ManagerspilStartStruktur(15),
	ManagerspilSlutStruktur(16),
	PokerTurneringStartStruktur(17),
	PokerTurneringSlutStruktur(18),
	KasinoSpilleautomatTransaktionStruktur(19),
	KasinoSpilleautomatJackpotStruktur(20),
	MonopolTalspilStartStruktur(21),
	MonopolTalspilTransaktionStruktur(22),
	MonopolTalspilEndOfGameStruktur(23),
	MonopolTalspilSlutStruktur(24),
	MonopolLodtraekningStartStruktur(25),
	MonopolLodtraekningSlutStruktur(26),
	MonopolEndOfDayRapportStruktur(27),
	MonopolBingoNetskrabStartStruktur(28),
	MonopolBingoNetskrabTransaktionStruktur(29),
	MonopolFysiskSkrabStartStruktur(30),
	MonopolFysiskSkrabTransaktionStruktur(31),
	MonopolFysiskSkrabSlutStruktur(32),
	MonopolDantotoEventStartStruktur(33),
	MonopolDantotoTransaktionStruktur(34),
	MonopolDantotoStartStruktur(35),
	MonopolDantotoSlutStruktur(36),
	MonopolDantotoEventSlutStruktur(37),
	MonopolLandeDataStruktur(38),
	MonopolDantotoEventTotalStruktur(39),

	HesteagtigEventStartStruktur(40),
	HesteagtigTransaktionStruktur(41),
	HesteagtigStartStruktur(42),
	HesteagtigSlutStruktur(43),
	HesteagtigEventSlutStruktur(44),
	HesteagtigEventTotalStruktur(45),

	HestDKEventStartStruktur(46),
	HestDKTransaktionStruktur(47),
	HestDKStartStruktur(48),
	HestDKSlutStruktur(49),
	HestDKEventSlutStruktur(50),
	HestDKEventTotalStruktur(51),

	SpilleautomatTransaktionStruktur(52),
	SpilleautomatJackpotUdloesningStruktur(53),
    SpilleautomatEndOfDayStruktur(54),
	MonopolVirtuelFastOddsTransaktionStruktur(55),
	MonopolVirtuelFastOddsSlutStruktur(56),

	MonopolLodtraekningTotalStruktur(57)
	;

	private final int id;

	private StandardRecordTypes(int id) {
		this.id = id;
	}

	public static StandardRecordTypes getTypeByRootTagName(String rootTagName) {
		return valueOf( StringUtil.replaceDanishChars(rootTagName) );
	}

	public static StandardRecordTypes valueFromInteger(int id) {
		for(StandardRecordTypes c : StandardRecordTypes.values()) {
			if(c.getId()==id) {
				return c;
			}
		}
		return null;
	}

	public int getId() {
		return id;
	}
}
