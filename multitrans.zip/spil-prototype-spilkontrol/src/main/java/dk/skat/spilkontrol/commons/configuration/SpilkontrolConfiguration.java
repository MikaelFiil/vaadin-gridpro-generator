package dk.skat.spilkontrol.commons.configuration;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * This class reads the spilkontrol property file which must be located in the domain of the web logic server.
 * It contains endpoints and other configurations that must be customized for the target environment
 */
public final class SpilkontrolConfiguration {
	private static final String SPILKONTROL_SERVICECONFIGURATION_PROPERTIES = "/META-INF/spilkontrol.properties";
	public static final String SEPARATOR = ".";

	private static final long CACHE_LIFETIME = 300000;
	private static long cacheTimestamp;
	private static Properties cachedProperties;

	private SpilkontrolConfiguration() {
		
	}
	
	public static String getValue(String configKey) throws SpilkontrolConfigurationException {
		return getProperties().getProperty(configKey);
	}
	
	/**
	 * gets properties, maybe from the cache
	 * @throws SpilkontrolConfigurationException 
	 */
	private static Properties getProperties() throws SpilkontrolConfigurationException {

		long currentTime = System.currentTimeMillis();

		if ((currentTime > cacheTimestamp + CACHE_LIFETIME)
				|| (cachedProperties == null)) {
			cacheTimestamp = currentTime;
			cachedProperties = getPropertiesFromFile();
		}

		return cachedProperties;
	}
	
	private static Properties getPropertiesFromFile() throws SpilkontrolConfigurationException {
		Properties serviceConf = new Properties();
		InputStream fileInputStream = null;

		try {
			fileInputStream = SpilkontrolConfiguration.class.getResourceAsStream(SPILKONTROL_SERVICECONFIGURATION_PROPERTIES);
			serviceConf.load(fileInputStream);
		} catch (FileNotFoundException e) {
			throw new SpilkontrolConfigurationException("Error FileNotFoundException: "
					+ SPILKONTROL_SERVICECONFIGURATION_PROPERTIES, e);

		} catch (IOException e) {
			throw new SpilkontrolConfigurationException("Error reading "
					+ SPILKONTROL_SERVICECONFIGURATION_PROPERTIES, e);

		} finally {
			if (null != fileInputStream) {
				try {
					fileInputStream.close();
				} catch (IOException e) {
					// do nothing
				}
			}
		}

		return serviceConf;
	}
}
