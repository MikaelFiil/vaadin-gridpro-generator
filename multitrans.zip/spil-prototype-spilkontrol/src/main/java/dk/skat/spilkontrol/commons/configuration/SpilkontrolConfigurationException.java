package dk.skat.spilkontrol.commons.configuration;

import dk.skat.spilkontrol.commons.error.SpilkontrolErrorCode;
import dk.skat.spilkontrol.commons.error.SpilkontrolException;


public class SpilkontrolConfigurationException extends SpilkontrolException {

	private static final long serialVersionUID = -1472517855786243671L;

	public SpilkontrolConfigurationException(String message) {
		super(SpilkontrolErrorCode.SpilkontrolConfigurationError, message);
	}

	public SpilkontrolConfigurationException(String message, Exception e) {
		super(SpilkontrolErrorCode.SpilkontrolConfigurationError, message, e);
	}

}
