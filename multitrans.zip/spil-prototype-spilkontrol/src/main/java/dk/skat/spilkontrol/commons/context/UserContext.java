package dk.skat.spilkontrol.commons.context;

import dk.skat.spilkontrol.commons.transaction.TransactionObject;
import dk.skat.spilkontrol.commons.transaction.TransactionObjectFactory;

/**
 * The UserContext is used for sharing information within a thread
 * 
 */
public final class UserContext {
    private TransactionObject transactionObject;

    private static ThreadLocal<UserContext> userContext = new ThreadLocal<UserContext>() {
        @Override
        protected synchronized UserContext initialValue() {
            return new UserContext();
        }
    };
    
    /**
     * Klassen har kun privat instantierering. Benyt getInstance() til offentlige referencer.
     */
    private UserContext() {
    }

    public static UserContext getInstance() {
        return userContext.get();
    }
    
    /**
     * Returnerer det paagaeldende transaktionsobjekt. KMD: Change danish letters in comment
     * @return det aktuelle transaktionsobjekt
     */
    public TransactionObject getTransactionObject() {
        assertTransactionActive();
        return transactionObject;
    }

    /**
     * Returnerer om der er sat et transaktionsobjekt.
     * @return <code>true</code> hvis der er sat et transaktionsobjekt, ellers <code>false</code>
     */
    public boolean isTransactionActive() {
        return transactionObject != null;
    }
    
    public TransactionObject beginBusinessTransaction() {
        TransactionObject newTransactionObject = TransactionObjectFactory.newInstance();
        beginBusinessTransaction(newTransactionObject);
        return newTransactionObject;
    }
    
    /**
     * If a transaction object is already set, it is discarded - can occur in some rare cases where it is not properly
     * cleaned up. If it is not cleared here, the only way to release the thread is by restarting the server, as the
     * thread is pooled and reused.
     * @param transactionObject
     */
    public void beginBusinessTransaction(TransactionObject transactionObject){
        if (transactionObject == null) {
            throw new IllegalArgumentException("Business transaction can not be started with null as transaction object");
        }
        this.transactionObject = transactionObject;
    }
    
    public void endBusinessTransaction() {
        userContext.remove();
    }
    
    private void assertTransactionActive() {
        if (!isTransactionActive()) {
            throw new IllegalStateException("No active business transaction available");
        }
    }

}
