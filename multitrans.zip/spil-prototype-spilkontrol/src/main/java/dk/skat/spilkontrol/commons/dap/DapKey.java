package dk.skat.spilkontrol.commons.dap;

/**
 * Interface of DapKey enumerations
 * @author jmn
 *
 */
public interface DapKey {
	
	String getKey();
	String getNamespace();
	String getDefaultText();
	String getDefaultTooltip();
	String getDefaultCode();
	String getNamespacePrefix();
	
}
