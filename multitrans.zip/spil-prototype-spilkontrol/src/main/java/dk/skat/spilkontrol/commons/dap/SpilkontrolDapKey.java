package dk.skat.spilkontrol.commons.dap;

public enum SpilkontrolDapKey implements DapKey {

	//DataFile status
	TokenClosed("Token closed"), 
	CopiedToGamingProviderFtp("Copied to gaming authority ftp"), 
	Verified("Verified"), 
	Unpacked("Unpacked"), 
	LoadedInDb("Loaded in db"), 
	PartiallyLoadedInDb("Partialy loaded in db"),
	DeletedFromGamingProviderFtp("Deleting from gaming authority ftp"),
	
	
	//Error codes
	NoError("No error"),
	FTPError("FTP error"),
	GeneralError("General error"),
	XmlSchemaValidationError("Xml Schema validation error"),
	ZipValidationError("Zip parsing error"),
	GamingProviderFTPNotReachable ("Gaming provider FTP server is not reachable"),
	GamingAuthorityFTPNotReachable ("Gaming authority FTP server is not reachable"),
	GamingProviderFTPIncorrectLogin ("Username/password to gaming provider FTP server is not correct"),
	GamingAuthorityFTPIncorrectLogin ("Username/password to gaming authority FTP server is not correct"),
	GamingAuthorityFTPIncorrectConfiguration ("FTP authority can't be configured properly, check the property file"),
	GamingProviderFileNotFound ("We can't find data on the gaming provider FTP server"),
	InvalidTypeOfUser("Ugyldig brugertype"),
	PrintButton("Print"),
	XmlOutOfDate("Xml contains out of date data"),
	
	CouldNotConnectToIpAddress("Kan ikke forbinde til ip-adresse"),
	FileIsRejectedByTamperTokenSystem ("Filer er afvist af Tamper Token"),
	WebServiceRuntimeError ("Error is thrown in the web service, TT queue will get an error reply"),
	VerificationByTamperTokenSystemFailed ("Verifikation mod Tamper Token kunne ikke gennemf\u00f8res"),
	//Database error codes
	GamingProvidersNameDoesntExist ("TilladelsesindehaverNavn eksisterer ikke"),
	IncorrectLoginPassword("Brugernavn eller password er ikke korrekt"),
	DataFileIsNotFoundOnFTP("Filen findes ikke"),
	TransmissionOfDataFails("Overf\u00f8rsel af data mislykkedes"), 
	NotificationIgnored("Datafil notifikation er ignoreret"), 
	ServiceInvocationError("Service returned error"), 
	ContainsReplacementData("Zipfil indeholder erstatningsdata"), 
	ContainsInvalidReplacementReference("Zipfil indeholder erstatningsdata der refererer data som ikke er gemt"),
	ContainsInvalidStandardRecord("Zipfilen indeholder en standard record, der pga. datafejl ikke kan gemmes"),
	
	DataNotificationPageHeaderPrimary("DATA: "),
	DataNotificationPageHeaderSecondary("fejl"),
	DataNotificationDetailLink("Data-notifikationer"),
	DataNotificationHeaderTime("Tid"),
	DataNotificationHeaderNotification("Notifikation"),
	DataNotificationHeaderDetails("Detaljer"),
	DataNotificationHeaderSafeId("SAFE ID"),
	DataNotificationHeaderLicenseHolderType("Tilladelsesindehaver type"),
	DataNotificationHeaderProvider("Tilladelsesindehaver"),
	DataNotificationHeaderAction("Handling"),
	DataNotificationHeaderRemove("Fjern fejl"),
	DataNotificationHeaderClear("Fjern fejl og slet data"),
	DataNotificationActionRetry("Fors\u00f8g igen"),
	DataNotificationActionRemove("O"),
	DataNotificationActionClear("X"),
	DataNotificationErrorId("Fejl id"),
	DataNotificationHeaderTamperTokenId("Tampertoken Id"),
	DataNotificationFilterShowAll("(Vis alle)"),
	DataNotificationExportXmlError("Eksporter xmlfejl til Excel (csv-format)"),
	RestartTaskFlow("Start forfra"),
	
	ErstatningsfilerAdviseringer("adviseringer"),
	ErstatningsfilerKlarTilUdskiftning("Erstatningsfiler klar til udskiftning"),
	ErstatningsfilerMedFejl("Erstatningsfiler med fejl"),
	ErstatningsfilerDetailsTitle("erstatningsfiler modtaget"),
	ErstatningsfilerDetailsLink("Vis alle"),
	ErstatningsfilerSafeId("SAFE ID"),
	ErstatningsfilerOriginalstruktur("Orginalstruktur"),
	ErstatningsfilerErstattesMed("Erstattes med"),
	ErstatningsfilerSpiludbyder("Spiludbyder"),
	ErstatningsfilerHandling("Handling"),
	ErstatningsfilerRyd("Ryd"),
	
	ReplacementDialogYesButton("OK"),
	ReplacementDialogNoButton("Annuller"),
	ReplacementDialogApproveTitle("Erstat fil"),
	ReplacementDialogApproveMessagePart1("Vil du erstatte den oprindelige fil fra "),
	ReplacementDialogApproveMessagePart2("med filen modtaget d. "),
	ReplacementDialogApproveMessagePart3("Filen erstatter en "),
	
	ProviderPageHeaderPrimary("Tilladelsesindehavere"),
	ProviderPageHeaderSecondary(""),
	
	// License holders - tilladelsesindehavere / spiludbydere
	ActiveGameProviders(" tilladelsesindehavere"),
	GameProvider("Tilladelsesindehaver"),
	GameProviderType("Type"),
	GameProviderShowAll("Vis alle"),
	
	GeneralServiceError("Der opstod en fejl. Pr\u00f8v igen, eller kontakt din systemadministrator"),
	
	LicenseHolderDataPageHeader("Tilladelsesindehaver:"),
	LicenseHolderDataStamData("Stamdata: "),
	LicenseHolderDataRisiko("Risiko:"),
	LicenseHolderDataDispensation("Dispensation:"),
	LicenseHolderDataCVRSE("CVR/SE:"),
	LicenseHolderDataAddressInfo("Adresse for herboende repr\u00e6sentant"),
	LicenseHolderDataAddress("Addresse:"),
	
	LicenseHolderDataKontakt("Kontakt"),
	LicenseHolderDataKontaktPerson("Kontaktperson:"),
	LicenseHolderDataKontaktPhone("Tlf:"),
	LicenseHolderDataKontaktEmail("Email:"),
	
	LicenseHolderDataSafe("SAFE"),
	LicenseHolderDataSafes("Safes"),
	LicenseHolderDataSafeId("SAFE ID:"),
	LicenseHolderDataSafeURL("URL:"),
	LicenseHolderDataSafeLogin("Login:"),
	LicenseHolderDataSafePassword("Password:"),
	LicenseHolderDataNote("Notat:"),
	
	LicenseHolderDataTilladelser("Tilladelser"),
	LicenseHolderDataTilladelserText("tilladelser"),
	LicenseHolderSpilTilladelser("Spiltilladelser"),
	LicenseHolderJournalNumber("Journalnumre:"),
	
	LicenseHolderDataRates("N\u00f8gletal:"),
	LicenseHolderTaxAndPlayers("Afgift"),
	LicenseHolderTaxBaseToDate("Beregnet afgiftsgrundlag til dato:"),
	LicenseHolderThisYearEstimate("\u00c5rets estimat (line\u00e6r fremskrivning):"),
	LicenseHolderMaxTaxBase("Maksimalt afgiftsgrundlag (indtastet):"),
	
	LicenseHolderDataSoftware("Software"),
	LicenseHolderDataSoftwareSupplier("Softwareleverand\u00f8r"),
	LicenseHolderDataSuppliers("Leverand\u00f8rer"),
	LicenseHolderDataTesthus("testhuse"),
	LicenseHolderDataTesthusText("Testhus"),
	LicenseHolderDataTesthusesText("Testhuse:"),
	LicenseHolderDataCertifiedRNG("Godkendt RNG"),
	LicenseHolderDataCurrencyExt("DKK"),
	
	LicenseHolderDataTaxBase("Afgiftsgrundlag"),

	LicenseHolderDataSpilSystem("Spilsystem"),
	LicenseHolderDataNoSoftwareSupplier("Ingen leverand\u00f8r"),
	LicenseHolderDataNoTestHus("Intet testhus"),
	LicenseHolderDataNoRNG("Ingen godkendt RNG"),
	LicenseHolderDataDatoIkkeSpecificeret("Uspecificeret"),
	LicenseHolderDataReturn("Tilbage til listen af tilladelseindehavere"),
		
	//Editing details about license holders
	EditProviderPageHeaderPrimary("Rediger tilladelsesindehaver: "),
	EditProviderGemRettelser("Gem rettelser:"),
	EditProviderGem("Gem"),
	EditProviderSkalAngives("* = skal angives"),
	EditProviderStamdata("Stamdata: "),
	EditProviderNavn("Navn:"),
	EditProviderRisiko("Risiko:"),
	EditProviderDispensation("Dispensation:"),
	EditProviderIndtaegtsbegraensetTilladelse("Indt\u00E6gtsb\u00E6granset tilladelse"),
	EditProviderCVRSE("CVR/SE:"),
	EditProviderCVR("CVR"),
	EditProviderSE("SE"),
	EditProviderAdresseForHerboendeRepraesentant("Adresse for herboende repr\u00E6sentant"),
	EditProviderAdresse("Adresse:"),
	EditProviderKontakt("Kontakt"),
	EditProviderKontaktPerson("Kontaktperson:"),
	EditProviderTelefon("Telefon:"),
	EditProviderEmail("Email:"),
	EditProviderSafeOverskrift("SAFE: "),
	EditProviderSafeTokensTil("Tokens til"),
	EditProviderSafe("SAFE"),
	EditProviderSafes("SAFEs"),
	EditProviderSafeId("SAFE ID:"),
	EditProviderUrl("URL:"),
	EditProviderLogin("Login:"),
	EditProviderPassword("Adgangskode:"),
	EditProviderSafeIdKommentar("Kommentar:"),
	EditProviderSpilSystem("SpilSystem:"),
	EditProviderSpilSystemKommentar("Kommentar:"),
	EditProviderTilladelserOverskrift("Tilladelser: "),
	EditProviderTilladelser("tilladelser"),
	EditProviderSpiltilladelser("Spiltilladelser"),
	EditProviderTilladelserFra("Fra:"),
	EditProviderTilladelserTil("Til:"),
	EditProviderTilladelserJournalnummer("Journalnummer:"),
	EditProviderTilladelserJournalnumre("Journalnumre"),
	EditProviderNoegletal("N\u00f8gletal: "),
	EditProviderAfgiftsgrundlagOverskrift("Afgiftsgrundlag"),
	EditProviderAfgiftsgrundlag("Afgiftsgrundlag"),
	EditProviderMaksimaltPerAar("Maksimalt /\u00E5r"),
	EditProviderSoftware("Software: "),
	EditProviderSoftwareLeverandoerMm("Leverand\u00f8r, testhus og "),
	EditProviderSoftwareRng("RNG"),
	EditProviderGodkendtRng("Godkendt RNG "),
	EditProviderRng("RNG: "),
	EditProviderSoftwareleverandoer("Softwareleverand\u00f8r"),
	EditProviderLeverandoer("Leverand\u00f8r:"),
	EditProviderTesthusOverskrift("Testhus"),
	EditProviderTesthus("Testhus:"),
	EditProviderRngFra("Fra"),
	EditProviderRngTil("Til"),
	EditProviderRngId("Id"),
	EditProviderRngSletHeader("Slet"),
	EditProviderRngSlet("Slet RNG"),
	EditProviderTilladelseType("TilladelseType:"),
	EditProviderNytJournalnummer("[+] Nyt journalnr."),
	EditProviderIngenJournalnumre("Ingen journalnumre"),
	EditProviderSpiludbyderTextBoldStyle("spiludbyderTextBold"),
	EditProviderJournalnummerHeader("Nummer"),
	EditProviderJournalnummerSletHeader("Slet"),
	EditProviderRngSpilType("Spil type"),
	EditProviderNyRng("[+] Ny RNG"),
	EditProviderReturn("Tilbage til visning af tilladelseindehaveren"),
	
	EditProviderHintMail("Fx ex@example.com"),
    
	EditProviderErrorLinesInAddress("Adressen m\u00E5 indeholde op til 7 linjer"),
	EditProviderErrorCharactersInAddress("Linjen m\u00E5 indeholde op til 70 tegn"),
    EditProviderErrorMail("Den e-mail-adresse, du har indtastet, er ikke gyldig. En gyldig e-mail-adresse er fx ex@example.com"),
    EditProviderErrorSvrSe("Det CVR/SE-nummer, du har indtastet, er ikke gyldigt. Et CVR/SE-nummer skal indeholde pr\u00E6cis 8 cifre."),
    EditProviderErrorTelephone("Det telefonnummer, du har indtastet, er ikke gyldigt. Et telefonnummer skal indeholde mellem 7 til 10 cifre"),
    EditProviderErrorAfgiftsgrundlag("Det afgiftsgrundlag, du har indtastet, er ikke gyldigt. Afgiftsgrundlag kan kun indeholde \",\" og cifre"),
    EditProviderErrorKontaktPerson("Den tekst, du har indtastet i kontaktperson, er for lang. Kontaktperson kan h\u00f8jst v\u00E6re 300 tegn lang."),
    EditProviderErrorRng("Den tekst, du har indtastet i RNG er for lang. RNG kan h\u00f8jst v\u00E6re 45 tegn lang."),
    EditProviderErrorUrl("Den tekst, du har indtastet i URL er for lang. URL kan h\u00f8jst v\u00E6re 300 tegn lang."),
    EditProviderErrorLogin("Den tekst, du har indtastet i Login er for lang. Login kan h\u00f8jst v\u00E6re 30 tegn lang."),
    EditProviderErrorPassword("Den tekst, du har indtastet i Password er for lang. Password kan h\u00f8jst v\u00E6re 45 tegn lang."),
    EditProviderErrorSafeIdKommentar("Den tekst, du har indtastet i SafeID er for lang. SafeID kan h\u00f8jst v\u00E6re 300 tegn lang."),
    EditProviderErrorTilladelserJournalnummer("Den tekst, du har indtastet i Journalnummer er for lang. Journalnummer kan h\u00f8jst v\u00E6re 17 tegn lang."),
    EditProviderErrorLeverandoer("Den tekst, du har indtastet i Leverand\u00f8r er for lang. Leverand\u00f8r kan h\u00f8jst v\u00E6re 100 tegn lang."),
    EditProviderErrorTesthus("Den tekst, du har indtastet i Testhus er for lang. Testhus kan h\u00f8jst v\u00E6re 100 tegn lang."),

	DispensationTrue("Ja"),
	DispensationFalse("No"),
	
	RISK_NOTSEGMENTED("Ikke segmenteret"),
	RISK_MINIMAL("Hvidt segment"),
	RISK_Low("Gr\u00f8nt segment"),
	RISK_Medium("Gult segment"),
	RISK_High("R\u00f8dt segment"),
	
	TableNoDataToShow("Ingen data"),

	NoContentToDisplay("Ingen data at vise"),
	AccessDenied("Du har ikke adgang til at se denne side"), 
	UnkownServiceResponse("Service returnerede uventet fejlkode"), 
	VAEDDEMAAL("V\u00E6ddem\u00E5l"), 
	ONLINEKASINO("Onlinekasino"), 
	VAEDDEMAAL_OG_ONLINEKASINO("B\u00E5de onlinekasino og v\u00E6ddem\u00E5l"),
	KASINOSPILLEAUTOMATER("KasinoSpilleautomater"),
	
	//tilladelsesindehaver types
	ONLINE("Online"), 
	SPILLEHAL("Spillehal"), 
	MONOPOL("Monopol"), 
	KASINO("Kasino"),
	MONOPOLSPIL("Monopolspil"), 

	// SAFE Dashboard
	NewUserSafePageHeaderPrimary("SAFE: "),
	NewUserSafePageHeaderSecondary("nye SAFE ID"),
	NewUserSafeNone("Ingen nye SAFE ID"),
	NewUserSafeDetailLink("Opret SAFEs"),
	NewUserSafeItemPrefix("SAFE ID:"),
	
	// SAFE Register
	SafeRegisterPageHeaderPrimary("Opret: "),
	SafeRegisterPageHeaderSecondary("nye SAFE IDs"),
	SafeCreation("Oprettelse:"),
	SafeCreationSafeId("SAFE ID:"),
	SafeCreationCreateNew("Opret ny tilladelsesindehaver"),
	SafeCreationAttachToExistingGameProvider("Tilf\u00f8j SAFE til eksisterende tilladelsesindehaver"),
	SafeCreationSecondaryCaptionOne("F\u00f8lgende SAFE IDs mangler tilknytning til tilladelsesindehavere:"),
	SafeCreationSecondaryCaptionTwo(""),
	SafeCreationURL("URL:"),
	SafeCreationSafeLogin("SAFE Login:"),
	SafeCreationSafePassword("Password:"),
	SafeCreationSelectGameProvider("V\u00e6lg spiludbyder"),
	SafeCreationCreateButton("Opret"),

	//Control Result page
	ControlResultEmptyNote ("Intet notat"),
	ControlResultPrimaryTitle("Spilkontrol: "),
	ControlResultSecondaryTitle("Find kontrolresultat"),
	ControlResultConcreteDate("Find kontrolresultat p\u00E5 bestemt dato"),
	ControlResultRangeDate("Find kontrolresultat i et datosp\u00E6nd"),
	ControlResultDate("Dato"),
	ControlResultDateFrom("Data Fra"),
	ControlResultDateTill("Data Til"),
	ControlResultExecutionStart("Afvikling start"),
	ControlResultExecutionFinish("Afvikling slut"),
	ControlResultIdentification("SpilProduktIdentifikation"),
	ControlResultNoDateHeader("Der er ingen datoer i de uds\u00f8gte resultater"),
	ControlResultApplyDate("Vis kontrolresultat"),
	ControlResultDateTillHeader(" til "),
	ControlResultDueToEmptyDraftNoteTooltip("Knappen kan ikke aktiveres f\u00f8r der er skrevet noget i notatfeltet!"),
	ControlResultAllOpenLink("Alle \u00E5bne sager"),
	ControlResultMyCasesLink("Mine sager"),
	ControlResultBiLinkLabel("BI debug:"),
	ControlResultBiLink("Vis BI data"),
	ControlResultStateAutoApproved("Automatisk godkendt"),
	ControlResultStateApproved("Godkendt"),
	ControlResultStateFailed("Fejlet"),
	
	ControlResultSummaryPulje("Pulje"),
	ControlResultSummaryPoker("Poker"),
	ControlResultSummaryFastodds("FastOdds"),
	ControlResultSummaryKasino("Kasino"),
	ControlResultSummarySpecial("Special"),
	ControlResultSummarySign("+"),
	ControlResultSummaryTitle("KONTROLLER: "),
	ControlResultSummarySecondTitle("\u00E5bne fejl"),
	ControlResultSummaryAllErrorsWithoutApprove("Alle fejl uden godkendelse"),
	ControlResultSummaryTotalCountTooltip("Antal fejl i alt"),
	ControlResultSummaryUnassignedCountTooltip("Antal fejl som ikke har nogen kontroll\u00f8r tildelt"),
	
	
	SpilTypeAlle("(Alle)"),
	SpilTypePoker("Poker"),
	SpilTypeKasino("Kasino"),
	SpilTypeFastodds("Fastodds"),
	SpilTypeMonopol("Monopolspil"),
	SpilTypePuljespil("Puljespil"),
	SpilTypeSpecial("Special"),
	SpilTypeMonopolLoerdagsLotto("Monopol L\u00f8rdagslotto"), 
	SpilTypeMonopolOnsdagsLotto("Monopol Onsdagslotto"),
	SpilTypeMonopolVikingLotto("Monopol Vikinglotto"),  // ÆA048
	SpilTypeMonopolLoerdagsJoker("Monopol L\u00f8rdagsjoker"), 
	SpilTypeMonopolOnsdagsJoker("Monopol Onsdagsjoker"), 
	SpilTypeMonopolEuroJackpot("Monopol Euro Jackpot"), 
	SpilTypeMonopolKeno("Monopol Keno"),
	SpilTypeMonopolAltEllerIntet("Monopol Alt Eller Intet"), // ÆA103
	SpilTypeMonopolLotteri("Monopol Lotteri"), // ÆA103
	SpilTypeMonopolBoxen("Monopol Boxen"), 
	SpilTypeMonopolLodtraekning("Monopol Lodtr\u00E6kning"),

	SpilTypeHestDK("HestDK"),
	SpilTypeHesteagtig("Hesteagtig"),

	SpilTypeMonopolDantoto("Monopol Dantoto"), 
	SpilTypeMonopolBingo("Monopol Bingo"), 
	SpilTypeMonopolNetskrab("Monopol Netskrab"),
	SpilTypeMonopolFindOgVind("Monopol Find Og Vind"), // ÆA103
	SpilTypeMonopolFysiskSkrab("Monopol Fysisk skrab"), 
	SpilTypeMonopolEOD("Monopol EOD"),
    SpilTypeMonopolRNG("Monopol RNG"),
    SpilTypeMonopolFejletUdenKategori("Monopol Fejlet uden Kategori"),
	
	KontrolResultatTilstandAlle("(Alle)"),
	KontrolResultatTilstandFejledeAlle("Fejlede - alle"),
	KontrolResultatTilstandFejledeAccepterede("Fejlede - accepterede"),
	KontrolResultatTilstandFejledeIkkeAcceptere("Fejlede - ikke accepterede"),
	KontrolResultatTilstandAutGodkendt("Automatisk godkendte"),
	
	KontrolResultatSpilkontrolmedarbejderAlle("(Alle)"),
	KontrolResultatSpilkontrolmedarbejderIngen("Ingen"),
	
	KontrolResultatFilterLabel("Filter"),
	KontrolResultatFilterEmployeeLabel("Spilkontroll\u00f8r"),
	KontrolResultatFilterStateLabel("Tilstand"),
	KontrolResultatTilladelsesindehaverLabel("Tilladelsesindehaver"),
	KontrolResultatSpiltypeFilter("Spilkategori"),
	KontrolResultatFilterGoLabel("Go"),
	KontrolResultatNoteColumn("Notat"),
	KontrolResultatControlColumn("Kontrolnavn"),
	KontrolResultatDatoColumn("Dato"),
	KontrolResultatIdColumn("Id"),
	KontrolResultatStartTidColumn("Starttid"),
	KontrolResultSelectDate("Skift dato"),

	
	KontrolResultHeader("Kontrolresultater: "),
	KontrolResultsAt("resultater p\u00e5"),
	KontrolResultLicenseHolders("Tilladelsesindehavere"), 
	SpilkontrolConfigurationError("Spilkontrolapplikationen er ikke konfigureret korrekt"),
	
	//Control result details page
	KontrolResultNoPreviousNotes("Ingen tidligere notater"),
	KontrolResultDetailsBackLink("Tilbage til kontrolresultat"),
	KontrolResultDetailsHeader("Kontrolresultat: "),
	KontrolResultDetailsName("Kontrol:"),
	KontrolResultDetailsResult("Resultat:"),
	KontrolResultDetailsGameProvider("Spiludbyder:"),
	KontrolResultDetailsResultFailed("Fejlet"),
	KontrolResultDetailsResultNotFailed("Ikke fejlet"),
	KontrolResultDetailsResultDetails("Detaljer:"),
	KontrolResultDetailsResponsible("Spilkontroll\u00f8r:"),
	KontrolResultDetailsDraftNote("Notat:"),
	KontrolResultDetailsManuallyApproved("Godkendelse:"),
	KontrolResultDetailsManuallyApprovedText("Fjern manuel accept"),
	KontrolResultDetailsToleranceHeader("Kontroltolerance"),
	KontrolResultDetailsSave("Gem"),
	KontrolResultDetailsSaveButtonTooltip("Gem resultatet"),
	KontrolResultDetailsSaveAndApprove("Gem og accepter"),
	KontrolResultDetailsPreviousNotes("Tidligere notater:"),
	KontrolResultDetailsPreviousNotesNote("Notat"),
	KontrolResultDetailsPreviousNotesApprovalTime("Godkendt"),
	KontrolResultDetailsPreviousNotesResponsible("Af"),
	KontrolResultDetailsManuallyApprovedValueLabel("Accepteret:"),
	KontrolResultDetailsManuallyApprovedValue("Manuelt accepteret"),
	KontrolResultDetailsNoResultDetails("Underliggende BI analyse returnerede ingen data for den valgte udbyder/dato"),
	ControlResultBiExecuteError("Fejl under afvikling af BI-analysen"),//Max 45 chars
	ControlResultBiPostProcessingError("Fejl under behandling af resultatet fra BI"),//Max 45 chars
	ControlResultBiErrorHeader("Fejlbesked"),
	
	KontrolResultDetailsRemoveManualAcceptDialogTitle("Fjern manuel accept"),
	KontrolResultDetailsRemoveManualAcceptDialogContent("Er du sikker p\u00E5, at du \u00f8nsker at fjerne den manuelle accept af denne fejl?"),
	KontrolResultDetailsRemoveManualAcceptDialogContentAdditional("Dette vil betyde, at fejlen vil blive gen\u00E5bnet og et nyt notat oprettet."),
	KontrolResultDetailsRemoveManualAcceptDialogCancel("Annuller"),
	KontrolResultDetailsRemoveManualAcceptDialogOk("Fjern accept"),
	KontrolResultDetailsSaveAndApproveDialogTitle("Manuel accept"),
	KontrolResultDetailsSaveAndApproveDialogContent("Du er ved at manuelt acceptere et kontrolresultat, som en anden er spilkontroll\u00f8r p\u00E5."),
	KontrolResultDetailsSaveAndApproveDialogContentAdditional("Hvis du accepterer kontrolresultatet, vil du blive sat p\u00E5 i stedet for denne anden spilkontroll\u00f8r."),
	KontrolResultDetailsSaveAndApproveDialogCancel("Annuller"),
	KontrolResultDetailsSaveAndApproveDialogOk("Accepter"),
	KontrolResultDetailsSaveAndApproveButtonTooltip("Gem og godkend resultatet"),
	
	KontrolResultDetailsRepeatButtonText("Gentag kontrollen"),
	KontrolResultDetailsRepeatButtonTooltip("Gem, s\u00E6t en ny kontrolk\u00f8rsel i gang og s\u00E6t dette resultat til manuelt godkendt"),
	KontrolResultDetailsRepeatDialogContent("Du er ved at manuelt acceptere et kontrolresultat, som en anden er spilkontroll\u00f8r p\u00E5."),
	KontrolResultDetailsRepeatDialogTitle("Gentag kontrollen"),
	KontrolResultDetailsRepeatDialogOk("Accepter"),
	KontrolResultDetailsRepeatDialogCancel("Annuller"),

	KontrolResultDetailsGentagError("Der skete en fejl s\u00E5 kontrolresultatet med notat blev gemt, men k\u00f8rslen af kontrollen blev ikke sat i gang. Pr\u00f8v igen, eller kontakt din systemadministrator."),
	KontrolResultDetailsOpdaterError("Der skete en fejl s\u00E5 kontrolresultatet ikke blev opdateret. Pr\u00f8v igen, eller kontakt din systemadministrator."),
	KontrolResultDetailsGentagFeedback("Gentagelsen er scheduleret og kontrolresultatet er manuelt godkendt. Det nye kontrolresultat vil v\u00E6re tilg\u00E6ngeligt, n\u00E5r gentagelsen er gennemf\u00f8rt."),
	SpilkontrolControlResultCannotUpdateAlreadyApprovedControlResult("Kan ikke opdatere et godkendt kontrol resultat"),
	SpilkontrolControlResultCannotUpdateNoteMissing("Notat mangler - godkendelse ikke mulig uden notat"),
	SpilkontrolControlResultEmployeeNotFound("Medarbejder findes ikke"),
	SpilkontrolControlResultNotFound("Kontrol resultat id findes ikke"),
	SpilkontrolDefinitionResultNotFound("Kontrol definition id findes ikke"),
	SpilkontrolDefinitionResultNotCreated("Kontrol definition ikke Oprettet"),
	SpilkontrolDefinitionResultNotUpdated("Kontrol definition ikke Opdateret"),
	SpilkontrolOptimisticLockException("Opdatering er udf\u00f8rt af en anden"), 
	InvalidSafeIdReference ("SafeId can't be referenced from ExternalUser table"),
	SaveIdAlreadyExistsForGamingProvider ("SafeId already exists for gaming provider"),

	// Token er indlæst men nogle XML filer er sprunget over
	SkippedFiles("Skippede xml filer"),
	// SkippedFiles("Indl\u00e6sning skippede xml filer"),
	NumberOfSkippedFiles("Antal skippede xml filer med fejl: "),

	ControlDefinitionsHeader("Kontroller: "),
	ControlDefinitionsSecondHeaderActiveControls("kontroller"),
	ControlDefinitionsSecondHeaderInactiveControls("inaktive kontroller"),
	ControlDefinitionStatus("Status"),
	ControlDefinitionStatusNotActive("ikke-aktiv"),
	ControlDefinitionName("Kontrol"),
	ControlDefinitionBiRef("Analyse"),
	ControlDefinitionGameCategory("Spilkategori"),
	ControlDefinitionFrequency("K\u00f8res"),
	ControlDefinitionStandardTolerance("Standardtolerance"),
	ControlDefinitionStandardToleranceYesNo("ja/nej"),
	ControlDefinitionBy("Af "),
	ControlDefinitionBackLink("Tilbage til kontroldefinitioner"),
	ControlDefinitionHeader("Opret kontrol: "),
	ControlDefinitionUpdatedMessage("Kontrollen er opdateret"),
	ControlDefinitionCreatedHeader("Kontrollen er oprettet!"),
	ControlDefinitionCreateControlDefinition("Opret ny kontrol"),
	ControlDefinitionHeaderNewControl("Ny kontrol"),
	ControlDefinitionUpdateActiveControlDefinition("Rediger aktiv kontrol: "),
	ControlDefinitionUpdateInactiveControlDefinition("Rediger ikke-aktiv kontrol: "),
	BiReferenceTreePrimaryHeader("Opret kontrol: "),
	BiReferenceTreeSecondaryHeader("V\u00E6lg BI-analyse"),
	BiReferenceTreeLable("V\u00E6lg analyse"),
	SaveControlTreeButton("Gem"),
	CancelControlTreeButton("Annull\u00e9r"),
	ControlDefinitionSpecificName("Kontrolnavn"),
	ControlDefinitionSpecificGameCategory("Spilkategori"),
	ControlDefinitionSpecificGameCategoryChooseOne("(v\u00E6lg en spilkategori)"),
	ControlDefinitionBILinkLabel("Analyse"),
	ControlDefinitionBILinkText("V\u00E6lg den BI analyse, der skal k\u00f8res"),
	ControlDefinitionControlTypeLabel("Tids-/ datadrevet"),
	ControlDefinitionControlTypeDataDrivenRadio("k\u00f8res, n\u00e5r"),
	ControlDefinitionControlTypeTimeDrivenRadio("k\u00f8res"),
	ControlDefinitionControlTypeDataDrivenEndText("ankommer"),
	ControlDefinitionSpecificStandardrecordChooseOne("(v\u00E6lg record-type)"),
	ControlDefinitionSpecificFrequencyChooseOne("(v\u00E6lg frekvens)"),
	ControlDefinitionLicenseholderLabel("k\u00f8res for"),
	ControlDefinitionLicenseholderAll("Alle spiludbydere"),
	ControlDefinitionLicenseholderAdd("Tilf\u00f8j"),
	ControlDefinitionSubmitSaveAndActivate("Gem og aktiver"),
	ControlDefinitionSubmitSaveAndNotActive("Gem som ikke-aktiv"),
	ControlDefinitionSpecificLicenseholdersChooseOne("(v\u00E6lg enkelt spiludbydere)"),
	ControlDefinitionSpecificResultType("Leverer resultatet som"),
	ControlDefinitionSpecificResultTypeBoolean("Ja/Nej"),
	ControlDefinitionSpecificResultTypeValue("V\u00E6rdi"),
	ControlDefinitionSpecificStandardTolerance("Standardtolerance"),
	ControlDefinitionSpecificStandardTolerancePercentage("%"),
	ControlDefinitionSpecificStandardToleranceInfo("Indtast et heltal mellem 0 og 100"),
	ControlDefinitionSpecificLicenseholderTableHeaderName("Tilladelsesindehaver"),
	ControlDefinitionSpecificTableAction("Handling"),
	ControlDefinitionSpecificTableActionDelete("X"),
	ControlDefinitionSpecificTolerancesLabel("Tilf\u00f8j afvigelse"),
	ControlDefinitionSpecificTolerancesPercentage("%"),
	ControlDefinitionSpecificTolerancesChooseOne("(v\u00E6lg spiludbydere)"),
	ControlDefinitionSpecificTolerancesLicenseholderHeader("Tilladelsesindehaver"),
	ControlDefinitionSpecificTolerancesToleranceHeader("Tolerance"),
	ControlDefinitionSpecificTimeDriven("Tidsdrevet"),
	ControlDefinitionSpecificDataDriven("Datadrevet"),
	ControlDefinitionDeviation("Afvigelser:"),
	ControlDefinitionSubmitSave("Gem"),
	ControlDefinitionSpecificTolerancesIsToBeDeleted("Fjernes pga. \u00E6ndring i standardtolerancen"),
	ControlDefinitionHelpManual("http://www.google.com"),
	ControlDefinitionAnalysisRequired("Du har ikke udvalgt en analyse som kontrollen skal baseres p\u00E5."),
	ControlDefinitionTriggerMethodRequired("Kontrollen skal enten v\u00E6re tids- eller data-styret."),
	
	ValidationNumberRestriction("Skal v\u00E6re et tal"),
	ValidationRequired("Skal udfyldes"),
	ValidationAlreadyAddedToList("Findes allerede i listen"),
	ValidationDateNotAfterFromDate("Datoen m\u00E5 ikke v\u00E6re f\u00f8r til-datoen"), 
		
	DataWarehouseJobInstantiationError("Kunne ikke starte datawarehousejob"), 
	DatawareHouseFtpError("Kunne ikke overf\u00f8re filer til datawarehouse"), 
	DatawareHouseFtpAccessError("Kunne ikke tilg\u00E5 FTP server"),
	DatawareHouseCleanupError("Fejl i oprydningsjobbet"),
	DatawareHouseFtpFileDeleteError("Kunne ikke slette alle de gamle filer ved oprydning"),
	DatawareHouseFtpFilelistError("Kunne ikke hente listen af filer fra FTP server"),
	DatawareHouseLogError("Kunne ikke gemme resultatet i DWLog-tabellen"), 
	DatawareHouseDatabaseError("Query fejlede"), 
	
	MonopolDetailLodtraekningPN("Lodtr\u00E6kning Spil"), 
	MonopolDetailLodtraekningDate("Lodtr\u00E6kning Tr\u00E6kningDato"), 
	MonopolDetailTalspilPN("Talspil"), 
	MonopolDetailTalspilDraw("Draw nr."), 
	MonopolDetailTalspilDate("Talspil Tr\u00E6kningDato"), 
	MonopolDetailTalspilProduktNummer("Produktnummer"), 
	MonopolDetailTalspilUgeNummer("Ugenummer"), 
	MonopolDetailSpilKategoriNavn("Spilkategori"), 
	MonopolDetailTalspilPI("Talspil ID"), 
	;
	
	private static final String NAMESPACE_PREFIX = "spilkontrol";
	private static final String NAMESPACE = "http://dap.skat.dk/spilkontrol/";
	private String text;
	private String tooltip = null;
	private String code = null;
	
	private SpilkontrolDapKey(String text) {
		this(text, null, null);
	}

	private SpilkontrolDapKey(String text, String tooltip, String code) {
		this.text = text;
		this.tooltip = tooltip;
		this.code = code;
	}

	@Override
	public String getKey() {
		return name();
	}

	@Override
	public String getNamespace() {
		return NAMESPACE;
	}

	@Override
	public String getNamespacePrefix() {
		return NAMESPACE_PREFIX;
	}

	@Override
	public String getDefaultText() {
		return this.text;
	}

	@Override
	public String getDefaultTooltip() {
		return this.tooltip;
	}

	@Override
	public String getDefaultCode() {
		return this.code;
	}
	
	@Override
	public String toString() {
		return getNamespacePrefix() + ":" + getKey();
	}
}
