package dk.skat.spilkontrol.commons.date;

import org.joda.time.DateTime;
import org.joda.time.format.*;

public enum StringToDateConverter {
	DATETIME_WITH_TIMEZONE(ISODateTimeFormat.dateTimeParser()),
	DATE(new DateTimeFormatterBuilder().append(null, new DateTimeParser[]{
			DateTimeFormat.forPattern("yyyy'-'MM'-'ddZ").getParser(),
			DateTimeFormat.forPattern("yyyy'-'MM'-'dd").getParser(),
			}).toFormatter().withZoneUTC());
	
	private DateTimeFormatter formatter;
	
	StringToDateConverter(DateTimeFormatter formatter) {
		this.formatter = formatter;		
	}
	
	public DateTime getDateTime(String str) {
		return formatter.parseDateTime(str);
	}



}
