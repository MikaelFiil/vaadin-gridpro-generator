package dk.skat.spilkontrol.commons.error;

import dk.skat.spilkontrol.commons.dap.SpilkontrolDapKey;

import java.math.BigInteger;

public enum SpilkontrolErrorCode {
	//general errors
	GeneralError(1000, SpilkontrolDapKey.GeneralError),
	XmlSchemaValidationError(1001, SpilkontrolDapKey.XmlSchemaValidationError),
	FTPError(1002, SpilkontrolDapKey.FTPError),
	ServiceInvocationError(1003, SpilkontrolDapKey.ServiceInvocationError),
	UnknownServiceResponse(1004, SpilkontrolDapKey.UnkownServiceResponse),
	SpilkontrolConfigurationError(1005, SpilkontrolDapKey.SpilkontrolConfigurationError),
	SpilkontrolOptimisticLockException(1006, SpilkontrolDapKey.SpilkontrolOptimisticLockException),
	InvalidTypeOfUser(1007, SpilkontrolDapKey.InvalidTypeOfUser),
	InvalidSaveIdReference(1008, SpilkontrolDapKey.InvalidSafeIdReference),
	SaveIdAlreadyExistsForGamingProvider(1009, SpilkontrolDapKey.SaveIdAlreadyExistsForGamingProvider),
	SkippedFiles(1010, SpilkontrolDapKey.SkippedFiles),

	//errors related to processing gaming data from game providers
	GamingProviderFTPNotReachable (2000, SpilkontrolDapKey.GamingProviderFTPNotReachable),
	GamingProviderFTPIncorrectLogin (2001, SpilkontrolDapKey.GamingProviderFTPIncorrectLogin),
	GamingProviderFileNotFound (2002, SpilkontrolDapKey.GamingProviderFileNotFound),
	GamingAuthorityFTPNotReachable (2003, SpilkontrolDapKey.GamingAuthorityFTPNotReachable),
	GamingAuthorityFTPIncorrectLogin (2004, SpilkontrolDapKey.GamingAuthorityFTPIncorrectLogin),
	GamingAuthorityFTPIncorrectConfiguration (2005, SpilkontrolDapKey.GamingAuthorityFTPIncorrectConfiguration),
	ZipValidationError(2006, SpilkontrolDapKey.ZipValidationError),
	FileIsRejectedByTamperTokenSystem(2007,SpilkontrolDapKey.FileIsRejectedByTamperTokenSystem),
	VerificationByTamperTokenSystemFailed(2008,SpilkontrolDapKey.VerificationByTamperTokenSystemFailed), 
	ZipContainsReplacementData(2009, SpilkontrolDapKey.ContainsReplacementData),
	ZipContainsInvalidReplacementReference(2010, SpilkontrolDapKey.ContainsInvalidReplacementReference),
	ZipContainsInvalidStandardRecord(2011, SpilkontrolDapKey.ContainsInvalidStandardRecord),
	GamingProvidersNameDoesntExist(2012, SpilkontrolDapKey.GamingProvidersNameDoesntExist),
	XmlOutOfDate(2013, SpilkontrolDapKey.XmlOutOfDate),
	
	//errors related to handling control results
	SpilkontrolControlResultCannotUpdateAlreadyApprovedControlResult(3000, SpilkontrolDapKey.SpilkontrolControlResultCannotUpdateAlreadyApprovedControlResult),
	SpilkontrolControlResultCannotUpdateNoteMissing(3001, SpilkontrolDapKey.SpilkontrolControlResultCannotUpdateNoteMissing),
	SpilkontrolControlResultEmployeeNotFound(3002, SpilkontrolDapKey.SpilkontrolControlResultEmployeeNotFound),
	SpilkontrolControlResultNotFound(3003, SpilkontrolDapKey.SpilkontrolControlResultNotFound),
	SpilkontrolControlDefinitionNotFound(3004, SpilkontrolDapKey.SpilkontrolDefinitionResultNotFound),
	SpilkontrolControlDefinitionNotCreated(3005, SpilkontrolDapKey.SpilkontrolDefinitionResultNotCreated),
	SpilkontrolControlDefinitionNotUpdated(3006, SpilkontrolDapKey.SpilkontrolDefinitionResultNotUpdated),
	
	//errors related to handling of datawarehouse
	DataWarehouseJobInstantiationError(4000, SpilkontrolDapKey.DataWarehouseJobInstantiationError), 
	DatawareHouseFtpError(4001, SpilkontrolDapKey.DatawareHouseFtpError), 
	DatawareHouseFtpAccessError(4002, SpilkontrolDapKey.DatawareHouseFtpAccessError),
	DatawareHouseCleanupError(4003, SpilkontrolDapKey.DatawareHouseCleanupError),
	DatawareHouseFtpFileDeleteError(4004, SpilkontrolDapKey.DatawareHouseFtpFileDeleteError),
	DatawareHouseFtpFilelistError(4005, SpilkontrolDapKey.DatawareHouseFtpFilelistError),
	DatawareHouseLogError(4006, SpilkontrolDapKey.DatawareHouseLogError), 
	DatawareHouseDatabaseError(4007, SpilkontrolDapKey.DatawareHouseDatabaseError),
	;
	
	
	private final BigInteger errorCode;
	private final SpilkontrolDapKey dapkey;
    
    private SpilkontrolErrorCode(int errorCode, SpilkontrolDapKey dapkey) {
        this.dapkey = dapkey;
        this.errorCode = BigInteger.valueOf(errorCode);
    }
        
    public BigInteger getErrorCode() {
        return errorCode;
    }
    
    public SpilkontrolDapKey getDapKey(){
        return this.dapkey;
    }
    
    public static SpilkontrolErrorCode parse(BigInteger errorCode) {
        for(SpilkontrolErrorCode errorType : SpilkontrolErrorCode.values()){
            if(errorType.getErrorCode().equals(errorCode)){
                return errorType;
            }
        }
        throw new IllegalArgumentException("Unknown error code: " + errorCode);        
    }
    
    
}
