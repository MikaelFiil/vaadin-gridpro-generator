package dk.skat.spilkontrol.commons.error;

public abstract class SpilkontrolException extends Exception {

	private static final long serialVersionUID = -418425498529647268L;
	private SpilkontrolErrorCode errorCode;

	public SpilkontrolException(SpilkontrolErrorCode errorCode, String message, Exception e) {
		super(message, e);
		this.errorCode = errorCode;
	}

	public SpilkontrolException(SpilkontrolErrorCode errorCode, Exception e) {
		super(errorCode.name(), e);
		this.errorCode = errorCode;
	}

	public SpilkontrolException(SpilkontrolErrorCode errorCode, String message) {
		super(message);
		this.errorCode = errorCode;
	}

	public SpilkontrolException(SpilkontrolErrorCode errorCode) {
		super(errorCode.name());
		this.errorCode = errorCode;
	}
	public SpilkontrolErrorCode getErrorCode() {
		return this.errorCode;
	}
}
