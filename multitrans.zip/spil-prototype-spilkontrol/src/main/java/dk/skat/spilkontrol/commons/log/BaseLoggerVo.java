package dk.skat.spilkontrol.commons.log;

import dk.skat.spilkontrol.commons.context.UserContext;
import dk.skat.spilkontrol.commons.transaction.TransactionObject;
import dk.skat.spilkontrol.log.LogStage;
import dk.skat.spilkontrol.log.layout.XmlWritable;
import dk.skat.spilkontrol.log.util.XmlHelper;

import java.io.Serializable;


/**
 * Base class for all logger objects, ensuring that all mandatory fields are provided for each log entry.
 *
 */
public abstract class BaseLoggerVo implements Serializable, XmlWritable {
	private static final long serialVersionUID = 7874833756083140239L;
    public enum LogEvent implements LogStage {
        TRANSACTION_STARTED("TRANSACTION STARTED"), 
        TRANSACTION_ENDED("TRANSACTION ENDED"),
        ERROR_OCCURRED("ERROR OCCURRED");
        
        private String logStageText;
        
        private LogEvent(String logStageText){
            this.logStageText = logStageText;
        }
        
        public String getText() {
            return logStageText;
        }
    }
	private String message;
	private LogStage logStage;
    
    protected void setMessage(String message) {
    	this.message = message;
	}

    protected void setLogStage(LogStage logStage) {
    	this.logStage = logStage;
    }

    public String toXml() {
    	return toXml(true);
    }
    
    public String toXml(boolean escapeXmlCharacters) {
        StringBuilder sb = new StringBuilder();
        if(logStage != null) {
        	XmlHelper.appendXml("logstage", logStage.getText(), sb);
        }
        if(message != null) {
        	XmlHelper.appendXml("message", message, sb, escapeXmlCharacters);
        }
        if(UserContext.getInstance().isTransactionActive()) {
            TransactionObject transactionObject = UserContext.getInstance().getTransactionObject();
            XmlHelper.appendXml("transaktionsID", transactionObject.getTransactionId(), sb);
            XmlHelper.appendXml("transaktionsTid", transactionObject.getTransactionTimeString(), sb);
        }
        return sb.toString();
    }
    
    @Override
    public String toString() {
    	return message;
    }

}
