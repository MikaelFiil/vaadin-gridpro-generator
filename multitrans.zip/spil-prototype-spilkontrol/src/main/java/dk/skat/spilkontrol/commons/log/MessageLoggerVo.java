package dk.skat.spilkontrol.commons.log;



/**
 * A LoggerVo for logging plain messages. 
 */
public class MessageLoggerVo extends BaseLoggerVo {
    
    private static final long serialVersionUID = 1241705493120945489L;

    public MessageLoggerVo(String message) {
        setMessage(message);
    }

    
}
