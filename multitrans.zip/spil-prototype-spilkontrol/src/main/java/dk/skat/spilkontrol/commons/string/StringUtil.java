package dk.skat.spilkontrol.commons.string;


public final class StringUtil {

	private StringUtil() {
	}

	public static String removeCharAt(String s, int pos) {
		StringBuilder buf = new StringBuilder(s.length() - 1);
		buf.append(s.substring(0, pos)).append(s.substring(pos + 1));
		return buf.toString();
	}

	public static String replaceDanishChars(String input) {
		String danString = input;
		danString = danString.replace("\u00c5", "Aa");// Å
		danString = danString.replace("\u00e5", "aa");// å
		danString = danString.replace("\u00c6", "Ae");// Æ
		danString = danString.replace("\u00e6", "ae");// æ
		danString = danString.replace("\u00d8", "Oe");// Ø
		danString = danString.replace("\u00f8", "oe");// ø

		return danString;
	}

}
