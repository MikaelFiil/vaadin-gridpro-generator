package dk.skat.spilkontrol.commons.transaction;

import java.util.GregorianCalendar;

public interface TransactionAccessor {

	GregorianCalendar getTransactionTime();
	
	String getTransactionId();
}
