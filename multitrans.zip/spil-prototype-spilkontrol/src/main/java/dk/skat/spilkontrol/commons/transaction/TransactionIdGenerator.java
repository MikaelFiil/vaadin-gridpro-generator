package dk.skat.spilkontrol.commons.transaction;

import java.util.UUID;

public final class TransactionIdGenerator {

	private TransactionIdGenerator() {}

	public static synchronized String generateId() {
		return UUID.randomUUID().toString();
	}

}
