package dk.skat.spilkontrol.commons.transaction;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

import java.io.Serializable;
import java.util.GregorianCalendar;

/**
 * The purpose of the object is to contain the transaction id and time
 * The TransactionObject models the business transactions across service invocations
 *
 */
public class TransactionObject implements Serializable {
    private static final long serialVersionUID = -6264487115586674151L;
    private final String transactionId;
    private final GregorianCalendar transactionTime;
    private int transactionLevelCounter;

    TransactionObject(String transactionId, GregorianCalendar transactionTime) {
        this.transactionId = transactionId;
        this.transactionTime = transactionTime;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public GregorianCalendar getTransactionTime() {
        return transactionTime;
    }

    public String getTransactionTimeString() {
    	DateTimeFormatter formatter = ISODateTimeFormat.dateTime();
    	DateTime dt = new DateTime(transactionTime.getTime());
    	return dt.toString(formatter);
    }
    
    @Override
    public String toString(){
        return "TransactionObject[transactionID: "+transactionId+ " transactionTime "+transactionTime.toString()+"]";
    }

    public TransactionObject newSubLevelTransactionObject(){
        return new TransactionObject(
                transactionId + "." + (++transactionLevelCounter),
                transactionTime);
    }    
}
