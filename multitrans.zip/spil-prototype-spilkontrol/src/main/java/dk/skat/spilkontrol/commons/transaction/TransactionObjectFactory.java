package dk.skat.spilkontrol.commons.transaction;

import java.util.GregorianCalendar;

public final class TransactionObjectFactory {
    private TransactionObjectFactory() {
        // Utility class
    }

    public static TransactionObject newInstance() {
        return newInstance(
                TransactionIdGenerator.generateId(),
                (GregorianCalendar)GregorianCalendar.getInstance());
    }

    public static TransactionObject newInstance(TransactionAccessor accessor) {
        return newInstance(
        		accessor.getTransactionId(),
        		accessor.getTransactionTime());
    }

    private static TransactionObject newInstance(String transactionId, GregorianCalendar transactionTime) {
        return new TransactionObject(transactionId, transactionTime);
    }
}
