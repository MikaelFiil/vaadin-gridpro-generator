package dk.skat.spilkontrol.datalayer.xml;

import dk.skat.spilkontrol.commons.log.MessageLoggerVo;
import dk.skat.spilkontrol.log.Logger;

public abstract class CommonStandardRecordParser extends StandardRecordStructureParser {
	
	private static final Logger logger  = Logger.getLogger(CommonStandardRecordParser.class);

	protected CommonStandardRecordParser(Class<?> parserClass) {
		super();
		for(Class<?> innerClass : parserClass.getClasses()) {
			if (innerClass.isAnnotationPresent(XmlElementParser.class) ) {
				XmlElementParser an = innerClass.getAnnotation(XmlElementParser.class);
				try {
					getElementParsers().put(
							emptyTagName.equals(an.tagName()) ? innerClass.getSimpleName() : an.tagName(), 
							(IElementParser) innerClass.getConstructor(new Class[]{ innerClass.getEnclosingClass() }).newInstance(new Object[]{ this }));
				} catch (Exception e) {
					logger.error( new MessageLoggerVo("Critical exception when process standard record data"), e );
					throw new IllegalStateException("Critical exception when process standard record data", e);
				} 
			}
		}
	}
			
	@XmlElementParser
	public class SpilFilIdentifikation implements IElementParser {

		@Override
		public void parse(String value) {
			getStdRecord().setSpilFilIdentifikation(value);
		}
		
	}
	
	@XmlElementParser
	public class SpilFilErstatningIdentifikation implements IElementParser {

		@Override
		public void parse(String value) {
			getStdRecord().setSpilFilErstatningIdentifikation(value);
		}
		
	}
	
	@XmlElementParser
	public class SpilCertifikatIdentifikation implements IElementParser {

		@Override
		public void parse(String value) {
			getStdRecord().setSpilCertifikatIdentifikation(value);
		}
		
	}
	
}
