package dk.skat.spilkontrol.datalayer.xml;

import dk.skat.spilkontrol.business.model.EndOfDayStandardRecord;
import dk.skat.spilkontrol.commons.date.StringToDateConverter;
import dk.skat.spilkontrol.datalayer.xml.exceptions.ParseDataXmlFileException;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class EndOfDayParser extends CommonStandardRecordParser {
	
//	private static final Logger logger  = Logger.getLogger(EndOfDayParser.class);
	
	EndOfDayParser() {
		super(EndOfDayParser.class);
	}
	
	public EndOfDayStandardRecord getStandardRecord() {
		return (EndOfDayStandardRecord) getStdRecord();
	}
	
	@Override
	public void startElement(String namespaceURI, String localName, String qName,
			Attributes attributes) throws SAXException {

		if ( "SpilOpg\u00F8relse".equals(localName) ) {
			getStandardRecord().addSpilOpgoerelse(getStandardRecord().new SpilOpgoerelseType());
		}
		
		super.startElement(namespaceURI, localName, qName, attributes);
	}
	
	@XmlElementParser
	public class EndOfDayRapportDato implements IElementParser {

		@Override
		public void parse(String value) {
			getStandardRecord().setEndOfDateRapportDatoString(value);
			getStandardRecord().setEndOfDateRapportDato( StringToDateConverter.DATE.getDateTime(value) );
		}
		
	}
	
	@XmlElementParser
	public class ValutaOplysningKode implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			getStandardRecord().setValuta(value);
		}
		
	}
	
	@XmlElementParser
	public class SpilKategoriNavn implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			getStandardRecord().getLastSpilOpgoerelse().setSpilKategoryNavn(value);
		}
		
	}
	
	@XmlElementParser
	public class EndOfDayRapportAntalSpil implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			getStandardRecord().getLastSpilOpgoerelse().setEndOfDayRapportAntalSpil( Long.parseLong(value) );
		}
		
	}

	@XmlElementParser
	public class EndOfDayRapportIndskudSpil implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			getStandardRecord().getLastSpilOpgoerelse().setEndOfDayRapportIndskudSpil( Double.valueOf(value) );
		}
		
	}
	
	@XmlElementParser
	public class EndOfDayRapportIndskudJackpot implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			getStandardRecord().getLastSpilOpgoerelse().setEndOfDayRapportIndskudJackpot( Double.valueOf(value) );
		}
		
	}
	
	@XmlElementParser
	public class EndOfDayRapportGevinster implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			getStandardRecord().getLastSpilOpgoerelse().setEndOfDayRapportGevinster( Double.valueOf(value) );
		}
		
	}

	@XmlElementParser
	public class EndOfDayRapportKommissionRake implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			getStandardRecord().getLastSpilOpgoerelse().setEndOfDayRapportKommissionRake( Double.valueOf(value) );
		}
		
	}

}
