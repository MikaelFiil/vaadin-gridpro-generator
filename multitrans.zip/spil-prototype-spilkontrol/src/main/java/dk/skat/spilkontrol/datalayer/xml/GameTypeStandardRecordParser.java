package dk.skat.spilkontrol.datalayer.xml;

import dk.skat.spilkontrol.business.model.AbstractGameStandardRecord;

public class GameTypeStandardRecordParser extends CommonStandardRecordParser {
	
//	private static final Logger logger  = Logger.getLogger(GameTypeStandardRecordParser.class);

	protected GameTypeStandardRecordParser(Class<?> parserClass) {

		super(parserClass);
	}
	
	public AbstractGameStandardRecord stdRecord() {
		return (AbstractGameStandardRecord) getStdRecord();
	}
	
	
	
	@XmlElementParser
	public class SpilKategoriNavn implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilKategoriNavn(value);
		}
		
	}
	
	@XmlElementParser
	public class SpilProduktNavn implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilProduktNavn(value);
		}
		
	}
	
	@XmlElementParser
	public class SpilProduktIdentifikation implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilProduktIdentifikation(value);
			stdRecord().setSpilTypeIdentifikation2(value);
		}
		
	}

}
