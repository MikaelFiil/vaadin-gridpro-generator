package dk.skat.spilkontrol.datalayer.xml;


import dk.skat.spilkontrol.business.model.MonopolTalspilEndOfGameStandardRecord;
import dk.skat.spilkontrol.commons.date.StringToDateConverter;
import dk.skat.spilkontrol.datalayer.xml.exceptions.ParseDataXmlFileException;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class MonopolTalspilEndOfGameStrukturParser extends GameTypeStandardRecordParser {
	
//	private static final Logger logger  = Logger.getLogger(MonopolTalspilEndOfGameStrukturParser.class);

	protected MonopolTalspilEndOfGameStrukturParser() {
		super(MonopolTalspilEndOfGameStrukturParser.class);
	}
	
	@Override
	public void startElement(String namespaceURI, String localName, String qName,
			Attributes attributes) throws SAXException {

		if ( "ResultatTalSpil".equals(localName) ) {
			stdRecord().addNewResultatTalSpil();
		}

		super.startElement(namespaceURI, localName, qName, attributes);

	}
	
	public MonopolTalspilEndOfGameStandardRecord stdRecord() {
		return (MonopolTalspilEndOfGameStandardRecord) getStdRecord();
	}
	
	@XmlElementParser
	public class MonopolSpilKategoriNavn implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilKategoriNavn(value);
		}
		
	}
	@XmlElementParser
	public class MonopolSpilProduktNavn implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilProduktNavn(value);
		}
		
	}
	
	@XmlElementParser
	public class MonopolSpilProduktIdentifikation implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilProduktIdentifikation(value);
			stdRecord().setSpilTypeIdentifikation2(value);
		}
		
	}
	
	@XmlElementParser
	public class MonopolTalspilEndOfGameDatoTid implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setEndOfGameDatoTidString(value);
			stdRecord().setEndOfGameDatoTid(StringToDateConverter.DATETIME_WITH_TIMEZONE.getDateTime(value));
		}
	}
	
	@XmlElementParser
	public class MonopolTalspilIndskudSpilTillIndh implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setIndskudSpilTillIndh(Double.parseDouble(value));
		}
	}

	@XmlElementParser
	public class MonopolTalspilIndskudSpilTotal implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setIndskudSpilTotal(Double.parseDouble(value));
		}
	}
	
	@XmlElementParser
	public class MonopolTalspilIndskudJackpotTillIndh implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setIndskudJackpotTillIndh(Double.parseDouble(value));
		}
	}
	
	@XmlElementParser
	public class MonopolTalspilIndskudJackpotTotal implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setIndskudJackpotTotal(Double.parseDouble(value));
		}
	}
	
	@XmlElementParser(tagName="MonopolTalspilAntalR\u00e6kkerTillIndh")
	public class MonopolTalspilAntalRaekkerTillIndh implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setAntalRaekkerTillIndh(Long.parseLong(value));
		}
	}
	
	@XmlElementParser(tagName="MonopolTalspilSamletAntalR\u00e6kker")
	public class MonopolTalspilSamletAntalRaekker implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setSamletAntalRaekker(Long.parseLong(value));
		}
	}

	@XmlElementParser(tagName="MonopolTalspilGevinstPuljeBel\u00f8b")
	public class MonopolTalspilGevinstPuljeBeloeb implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setGevinstPuljeBeloeb(Double.parseDouble(value));
		}
	}
	
	@XmlElementParser
	public class ValutaOplysningKode implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setValutaOplysningKode(value);
		}
	}

	// ResultatTalSpil inside elements

	@XmlElementParser
	public class GevinstPuljeIdentifikation implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getResultatTalSpilListe().peek().setPuljeIdentifikation(value);
		}
	}
	
	@XmlElementParser(tagName="GevinstPuljeOverf\u00f8rselPrimo")
	public class GevinstPuljeOverfoerselPrimo implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getResultatTalSpilListe().peek().setPuljeOverfoerselPrimo(Double.parseDouble(value));
		}
	}
}
