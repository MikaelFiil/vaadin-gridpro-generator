package dk.skat.spilkontrol.datalayer.xml;

import dk.skat.spilkontrol.business.model.MonopolTalspilSlutStandardRecord;
import dk.skat.spilkontrol.commons.date.StringToDateConverter;
import dk.skat.spilkontrol.datalayer.xml.exceptions.ParseDataXmlFileException;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class MonopolTalspilSlutStrukturParser extends GameTypeStandardRecordParser {

//	private static final Logger logger = Logger.getLogger(MonopolTalspilSlutStrukturParser.class);

	public MonopolTalspilSlutStrukturParser() {
		super(MonopolTalspilSlutStrukturParser.class);
	}

	public MonopolTalspilSlutStandardRecord stdRecord() {
		return (MonopolTalspilSlutStandardRecord) getStdRecord();
	}

	// next method is required for SAX parser
	@Override
	public void startElement(String namespaceURI, String localName, String qName,
			Attributes attributes) throws SAXException {

		if ( "GevinstkategorierOgGevinster".equals(localName) ) {
			stdRecord().addNewGevinstkategorierOgGevinster();
		} else if ( "SamletOms\u00E6tning".equals(localName) ) {
			stdRecord().addNewSamletOmsaetning();
		} else if ( "Vinder".equals(localName) ) {
			stdRecord().addNewVinder();
		} else if ( "Tilf\u00E6ldighedGenerator".equals(localName) ) {
			stdRecord().addNewTilfaeldighedGenerator();
		} else if ( "ResultatGrundlag".equals(localName) ) {
			stdRecord().addResultatGrundlag();
		} else if ( "GevinstPuljePrLand".equals(localName) ) {
			stdRecord().addNewVinder();
		} 

		super.startElement(namespaceURI, localName, qName, attributes);
	}

	@XmlElementParser
	public class MonopolSpilKategoriNavn implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilKategoriNavn(value);
		}
	}
	
	@XmlElementParser
	public class MonopolSpilProduktNavn implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilProduktNavn(value);
		}
	}
	
	@XmlElementParser
	public class MonopolSpilProduktIdentifikation implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilProduktIdentifikation(value);
		}
	}
	
	@XmlElementParser
	public class MonopolSpilProduktFaktiskSlutDatoTid implements IElementParser {
		@Override
		public void parse(String value) {
			stdRecord().setSpilProduktFaktiskSlutDatoTidString(value);
			stdRecord().setSpilProduktFaktiskSlutDatoTid(StringToDateConverter.DATETIME_WITH_TIMEZONE.getDateTime(value));
		}
	}

	@XmlElementParser
	public class ValutaOplysningKode implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setValutaOplysningKode(value);
		}
	}

	@XmlElementParser(tagName="MonopolTalspilSamletOms\u00e6tningValuta")
	public class MonopolTalspilSamletOmsaetningValuta implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSamletOmsaetningListe().peek().setValutaOplysningKode(value);
		}
	}

	@XmlElementParser(tagName="MonopolTalspilSamletOms\u00e6tningValutaKurs")
	public class MonopolTalspilSamletOmsaetningValutaKurs implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSamletOmsaetningListe().peek().setValutaOplysningKurs(Double.parseDouble(value));
		}
	}

	
	@XmlElementParser(tagName="Tilf\u00e6ldighedGeneratorIdentifikation")
	public class TilfaeldighedGeneratorIdentifikation implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
				stdRecord().getTilfaeldighedGeneratorListe().peek().setTilfaeldighedGeneratorIdentifikation(value);
		}
		
	}
	
	@XmlElementParser(tagName="Tilf\u00e6ldighedGeneratorSoftwareId")
	public class TilfaeldighedGeneratorSoftwareId implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getTilfaeldighedGeneratorListe().peek().setTilfaeldighedGeneratorSoftwareId(value);
		}
	}

	@XmlElementParser(tagName="MonopolTalspilSamletOms\u00e6tning")
	public class MonopolTalspilSamletOmsaetning implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSamletOmsaetningListe().peek().setSamletOmsaetning(Double.parseDouble(value));
		}
	}
	
	///////////////////////////////////////////////////////
	//////// Inside "GevinstkategorierOgGevinsterType" element
	///////////////////////////////////////////////////////

	@XmlElementParser
	public class GevinstPuljeIdentifikation implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getGevinstkategorierListe().peek().setGevinstPuljeIdentifikation(value);
		}
	}
	
	@XmlElementParser
	public class GevinstPuljeAntalGevinsterTillIndh implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getGevinstkategorierListe().peek().setGevinstPuljeAntalGevinsterTillIndh(Long.parseLong(value));
		}
	}

	@XmlElementParser(tagName="GevinstPuljeBel\u00f8bTillIndh")
	public class GevinstPuljeBeloebTillIndh implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getGevinstkategorierListe().peek().setGevinstPuljeBeloebTillIndh(Double.parseDouble(value));
		}
	}

	@XmlElementParser(tagName="GevinstPuljeBel\u00f8bTotal")
	public class GevinstPuljeBelobTotal implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getGevinstkategorierListe().peek().setGevinstPuljeBeloebTotal(Double.parseDouble(value));
		}
	}

	@XmlElementParser(tagName="GevinstPuljeBel\u00f8bPerR\u00e6kke")
	public class GevinstPuljeBeloebPrRaekke implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getGevinstkategorierListe().peek().setGevinstPuljeBeloebPerRaekke(Double.parseDouble(value));
		}
	}
	
	@XmlElementParser(tagName="GevinstPuljeTilf\u00f8jetBel\u00f8b")
	public class GevinstPuljeTilfoejetBeloeb implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getGevinstkategorierListe().peek().setGevinstPuljeTilfoejetBeloeb(Double.parseDouble(value));
		}
	}

	@XmlElementParser(tagName="GevinstPuljeOverf\u00f8rselUltimo")
	public class GevinstPuljeOverfoerselUltimo implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getGevinstkategorierListe().peek().setGevinstPuljeOverfoerselUltimo(Double.parseDouble(value));
		}
	}

	///////////////////////////////////////////////////////
	//////// Inside "ResultatGrundlag" element
	///////////////////////////////////////////////////////

	@XmlElementParser(tagName="PuljespilVinderR\u00e6kke")
	public class PuljespilVinderRaekke implements IElementParser {
		@Override
		public void parse(String value) {
			stdRecord().getResultatGrundlagListe().peek().setPuljespilVinderRaekke(value);
		}
	}

	///////////////////////////////////////////////////////
	//////// Inside "Vinder" element
	///////////////////////////////////////////////////////

	@XmlElementParser
	public class SpillerInformationIdentifikation implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getVinderListe().peek().setSpillerInformationIdentifikation(value);
		}
	}	
	
	@XmlElementParser
	public class SpilTransaktionIdentifikation implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getVinderListe().peek().setSpilTransaktionIdentifikation(value);
		}
	}
	
	@XmlElementParser(tagName="R\u00e6kkeNummer")
	public class RaekkeNummer implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getVinderListe().peek().setRaekkeNummer(Long.parseLong(value));
		}
	}
	
	@XmlElementParser
	public class SpilGevinstSpil implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getVinderListe().peek().setSpilGevinstSpil(Double.parseDouble(value));
		}
	}

	@XmlElementParser
	public class SpilGevinstJackpot implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getVinderListe().peek().setSpilGevinstJackpot(Double.parseDouble(value));
		}
	}
	
}
