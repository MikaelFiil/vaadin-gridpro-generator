package dk.skat.spilkontrol.datalayer.xml;

import dk.skat.spilkontrol.business.model.MonopolTalspilStartStandardRecord;
import dk.skat.spilkontrol.commons.date.StringToDateConverter;
import dk.skat.spilkontrol.datalayer.xml.exceptions.ParseDataXmlFileException;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class MonopolTalspilStartStrukturParser extends GameTypeStandardRecordParser {

//	private static final Logger logger = Logger.getLogger(MonopolTalspilStartStrukturParser.class);

	public MonopolTalspilStartStrukturParser() {
		super(MonopolTalspilStartStrukturParser.class);
	}

	public MonopolTalspilStartStandardRecord stdRecord() {
		return (MonopolTalspilStartStandardRecord) getStdRecord();
	}

	@Override
	public void startElement(String namespaceURI, String localName, String qName,
			Attributes attributes) throws SAXException {

		if ( "GenerelSpilN\u00f8gle".equals(localName) ) {
			stdRecord().addNewGenerelPuljeNoegle();
		} else if ( "ResultatTalSpil".equals(localName) ) {
			stdRecord().addNewResultatTalSpil();
		} 		

		super.startElement(namespaceURI, localName, qName, attributes);
	}
	
	@XmlElementParser
	public class MonopolSpilKategoriNavn implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilKategoriNavn(value);
		}
	}
	
	@XmlElementParser
	public class MonopolSpilProduktNavn implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilProduktNavn(value);
		}
	}
	
	@XmlElementParser
	public class MonopolSpilProduktIdentifikation implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilProduktIdentifikation(value);
		}
	}

	@XmlElementParser(tagName="MonopolSpilProdukt\u00C5bentNetv\u00E6rk")
	public class MonopolSpilProduktAabentNetvaerk implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilProduktAabentNetvaerk("1".equals(value));
			
		}
	}
	
	@XmlElementParser
	public class MonopolPuljespilGevinstPuljeProcent implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setGevinstPuljeProcent(Double.parseDouble(value));
		}
	}
	
	@XmlElementParser
	public class MonopolPuljespilAntalResultatPuljer implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setAntalResultatPuljer(Long.parseLong(value));
		}
	}
	
	@XmlElementParser
	public class MonopolTalspilAntalTal implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setAntalTal(Long.parseLong(value));
		}
	}
	
	@XmlElementParser
	public class MonopolSpilProduktNummer implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setMonopolSpilProduktNummer(Long.parseLong(value));
		}
	}
	
	
	@XmlElementParser
	public class MonopolTalspilDrawNummer implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setMonopolTalspilDrawNummer(Long.parseLong(value));
		}
	}

	@XmlElementParser
	public class MonopolTalspilUgeNummer implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setMonopolTalspilUgeNummer(Long.parseLong(value));
		}
	}

	@XmlElementParser(tagName="MonopolTalspilR\u00e6kkePris")
	public class MonopolTalspilRaekkePris implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setSpilRaekkePris(Double.parseDouble(value));
		}
	}

	@XmlElementParser
	public class SpilForventetSlutDatoTid implements IElementParser {
		@Override
		public void parse(String value)  {
			stdRecord().setSpilForventetSlutDatoTidString(value);
			stdRecord().setSpilForventetSlutDatoTid(StringToDateConverter.DATETIME_WITH_TIMEZONE.getDateTime(value));
		}
	}
	
	@XmlElementParser
	public class ValutaOplysningKode implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().setValutaOplysningKode(value);
		}
	}

	///////////////////////////////////////////////////////
	//////// Inside "GenerelPuljeNøgle" element
	///////////////////////////////////////////////////////

	@XmlElementParser(tagName="MonopolPuljespilN\u00f8gleNummer")
	public class MonopolPuljespilNoegleNummer implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getGenerelSpilNoegleListe().peek().setNoegleNummer(Long.parseLong(value));
		}
	}

	@XmlElementParser(tagName="MonopolPuljespilN\u00f8gleBeskrivelse")
	public class MonopolPuljespilNoegleBeskrivelse implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getGenerelSpilNoegleListe().peek().setNoegleBeskrivelse(value);
		}
	}

	@XmlElementParser(tagName="MonopolPuljespilN\u00f8gleValideTal")
	public class MonopolTalspilNoegleValideTal implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getGenerelSpilNoegleListe().peek().setNoegleValideTal(value);
		}
	}

	///////////////////////////////////////////////////////
	//////// Inside "ResultatPulje" element
	///////////////////////////////////////////////////////

	@XmlElementParser
	public class GevinstPuljeIdentifikation implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getResultatTalSpilListe().peek().setGevinstPuljeIdentifikation(value);
		}
	}
	
	@XmlElementParser
	public class GevinstPuljeGevinstProcent implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getResultatTalSpilListe().peek().setGevinstPuljeGevinstProcent(Double.parseDouble(value));
		}
	}

	@XmlElementParser
	public class GevinstPuljeBeskrivelse implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getResultatTalSpilListe().peek().setGevinstPuljeBeskrivelse(value);
		}
	}

	@XmlElementParser
	public class GevinstPuljeGaranti implements IElementParser {
		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getResultatTalSpilListe().peek().setGevinstPuljeGaranti(Double.parseDouble(value));
		}
	}

}
