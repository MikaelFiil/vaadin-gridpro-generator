package dk.skat.spilkontrol.datalayer.xml;


import dk.skat.spilkontrol.business.model.MonopolTalspilTransaktionStandardRecord;
import dk.skat.spilkontrol.commons.date.StringToDateConverter;
import dk.skat.spilkontrol.datalayer.xml.exceptions.ParseDataXmlFileException;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class MonopolTalspilTransactionStrukturParser extends GameTypeStandardRecordParser {
	
//	private static final Logger logger  = Logger.getLogger(PuljespilTransactionStrukturParser.class);

	protected MonopolTalspilTransactionStrukturParser() {
		super(MonopolTalspilTransactionStrukturParser.class);
	}

	// method is required for SAX parser
	@Override
	public void startElement(String namespaceURI, String localName, String qName,
			Attributes attributes) throws SAXException {

		if ( "SpillerOgKupon".equals(localName) ) {
			stdRecord().addNewSpillerOgKupon();
		} else if ( "Spilkombinationer".equals(localName) ) {
			stdRecord().getSpillerOgKuponListe().peek().addNewSpilkombinationer();
		} else if ( "Jackpot".equals(localName) ) {
			stdRecord().getSpillerOgKuponListe().peek().addNewJackpot();
		} 		
		
		super.startElement(namespaceURI, localName, qName, attributes);
		
	}
	
	/**
	 * accesses the standard record.
	 */
	public MonopolTalspilTransaktionStandardRecord stdRecord() {
		return (MonopolTalspilTransaktionStandardRecord) getStdRecord();
	}
	
	@XmlElementParser
	public class MonopolSpilKategoriNavn implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilKategoriNavn(value);
		}
		
	}
	
	@XmlElementParser
	public class MonopolSpilProduktNavn implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilProduktNavn(value);
		}
		
	}
	
	@XmlElementParser
	public class MonopolSpilProduktIdentifikation implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().setSpilProduktIdentifikation(value);
			stdRecord().setSpilTypeIdentifikation2(value);
		}
		
	}

	@XmlElementParser
	public class SpillerInformationIdentifikation implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().setSpillerInformationIdentifikation(value);
		}
	}
	
	@XmlElementParser
	public class SpilTransaktionIdentifikation implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().setSpilTransaktionIdentifikation(value);
		}
	}
	
	@XmlElementParser
	public class MonopolTalspilOverordnetSpilTransaktionIdentifikation implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().setMonopolOverordnetSpilTransaktionIdentifikation(value);
		}
	}
	
	@XmlElementParser(tagName="SpilK\u00F8bDatoTid")
	public class SpilKoebDatoTid implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().getSpillerOgKuponListe().peek().setSpilKoebDatoTidString(value);
			stdRecord().getSpillerOgKuponListe().peek().setSpilKoebDatoTid(StringToDateConverter.DATETIME_WITH_TIMEZONE.getDateTime(value) );
		}
		
	}
	
	@XmlElementParser
	public class SpilSalgskanal implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().setSpilSalgskanal(value);
		}
	}
	
	@XmlElementParser(tagName="SpilAntalR\u00E6kker")
	public class SpilAntalRaekker implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().setSpilAntalRaekker(( Long.parseLong(value)));
		}
		
	}

	@XmlElementParser
	public class SpilTerminalIdentifikation implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().setSpilTerminalidentification(value);
		}
	}
	
	@XmlElementParser
	public class SpilHjemmeside implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().setSpilHjemmeside(value);
		}
	}
	
	@XmlElementParser
	public class SpilIndskud implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().setSpilIndskud( ( Double.parseDouble(value) ));
		}
		
	}

	@XmlElementParser
	public class SpilIndskudSpil implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().setSpilIndskudSpil( ( Double.parseDouble(value) ));
		}
		
	}

	@XmlElementParser
	public class MonopolTalspilType implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().setTalSpilType(value);
		}
	}
	
	@XmlElementParser
	public class JackpotIdentifikation implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().getJackpotListe().peek().setJackpotIdentifikation(value);
		}
		
	}

	@XmlElementParser
	public class SpilIndskudJackpot implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().getJackpotListe().peek().setSpilIndskudJackpot((Double.parseDouble(value)));
		}
		
	}

	@XmlElementParser
	public class SpilAnnullering implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			int i = Integer.parseInt(value);
			Boolean b = (1 == i);
			stdRecord().getSpillerOgKuponListe().peek().setSpilAnnullering(b);
		}
		
	}

	@XmlElementParser
	public class SpilAnnulleringDatoTid implements IElementParser {

		@Override
		public void parse(String value) {
			stdRecord().getSpillerOgKuponListe().peek().setSpilAnnulleringDatoTidString(value);
			stdRecord().getSpillerOgKuponListe().peek().setSpilAnnulleringDatoTid( StringToDateConverter.DATETIME_WITH_TIMEZONE.getDateTime(value) );
		}
		
	}
	
	@XmlElementParser
	public class ValutaOplysningKode implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().setValutaOplysningKode(value);
		}
		
	}

	@XmlElementParser(tagName="R\u00e6kkeNummer")
	public class RaekkeNummer implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().getSpilkombinationerListe().peek().setRaekkeNummer( Long.parseLong(value));
		}
		
	}

	@XmlElementParser(tagName="R\u00e6kkeSpilkombinationer")
	public class RaekkeSpilkombinationer implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().getSpilkombinationerListe().peek().setRaekkeSpilkombinationer(value);
		}
		
	}

	@XmlElementParser(tagName="MonopolTalspilKenoR\u00e6kkePris")
	public class MonopolTalspilKenoRaekkePris implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().setKenoRaekkePris( Double.parseDouble(value));
		}
		
	}

	@XmlElementParser
	public class Andel implements IElementParser {

		@Override
		public void parse(String value) throws ParseDataXmlFileException {
			stdRecord().getSpillerOgKuponListe().peek().setAndel(Double.parseDouble(value));
		}

	}

}
