package dk.skat.spilkontrol.datalayer.xml;

import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;

public final class StandardRecordParsersFactory {

	private StandardRecordParsersFactory() {

	}

	public static StandardRecordStructureParser getParser(String rootTag) {
		return getParser(getStandardRecordTypeByTagName(rootTag));
	}

	public static StandardRecordStructureParser getParser(StandardRecordTypes parserType) {
		StandardRecordStructureParser parser = null;
		switch (parserType) {
/*
			case KasinospilPrSessionStruktur:
			case KasinoSpilPrTraekStruktur:
				parser = new KasinoStructureParser();
				break;
			case JackpotUdloesningStruktur:
				parser = new JackpotStructureParser();
				break;
			case PuljespilTransaktionStruktur:
				parser = new PuljespilTransactionStrukturParser();
				break;
			case PuljespilEndOfGameStruktur:
				parser = new PuljespilEndOfGameStrukturParser();
				break;
			case PuljespilSlutStruktur:
				parser = new PuljespilSlutStrukturParser();
				break;
			case PuljespilStartStruktur:
				parser = new PuljespilStartStrukturParser();
				break;
			case EndOfDayRapportStruktur:
				parser = new EndOfDayParser();
				break;
			case FastOddsTransaktionStruktur:
				parser = new FastOddsTransaktionStrukturParser();
				break;
			case FastOddsSlutStruktur:
				parser = new FastOddsSlutStrukturParser();
				break;
			case MonopolVirtuelFastOddsTransaktionStruktur:
				parser = new MonopolFastOddsTransaktionStrukturParser();
				break;
			case MonopolVirtuelFastOddsSlutStruktur:
				parser = new MonopolFastOddsSlutStrukturParser();
				break;
			case PokerTurneringTransaktionStruktur:
				parser = new PokerTurneringTransaktionStrukturParser();
				break;
			case PokerCashGamePrHaandStruktur:
			case PokerCashGamePrSessionStruktur:
				parser = new PokerCashGameParser();
				break;
			case PokerTurneringStartStruktur:
				parser = new PokerTurneringStartStrukturParser();
				break;
			case ManagerspilTransaktionStruktur:
				parser = new ManagerSpilTransaktionStrukturParser();
				break;
			case ManagerspilStartStruktur:
				parser = new ManagerSpilStartStrukturParser();
				break;
			case ManagerspilSlutStruktur:
				parser = new ManagerSpilSlutStrukturParser();
				break;
			case PokerTurneringSlutStruktur:
				parser = new PokerTurneringSlutStrukturParser();
				break;
			case KasinoSpilleautomatTransaktionStruktur:
				parser = new KasinoSpilleautomatTransaktionStrukturParser();
				break;
			case KasinoSpilleautomatJackpotStruktur:
				parser = new KasinoSpilleautomatJackpotStrukturParser();
				break;
 */
			case MonopolTalspilEndOfGameStruktur:
				parser = new MonopolTalspilEndOfGameStrukturParser();
				break;
			case MonopolTalspilTransaktionStruktur:
				parser = new MonopolTalspilTransactionStrukturParser();
				break;
/*
			case MonopolBingoNetskrabTransaktionStruktur:
				parser = new MonopolBingoNetskrabTransaktionStrukturParser();
				break;
 */
			case MonopolTalspilStartStruktur:
				parser = new MonopolTalspilStartStrukturParser();
				break;
			case MonopolTalspilSlutStruktur:
				parser = new MonopolTalspilSlutStrukturParser();
				break;
/*
			case MonopolLodtraekningStartStruktur:
				parser = new MonopolLodtraekningStartStrukturParser();
				break;
			case MonopolLodtraekningSlutStruktur:
				parser = new MonopolLodtraekningSlutStrukturParser();
				break;
			case MonopolEndOfDayRapportStruktur:
				parser = new MonopolEndOfDayParser();
				break;
			case MonopolBingoNetskrabStartStruktur:
				parser = new MonopolBingoNetskrabStartParser();
				break;
			case MonopolFysiskSkrabStartStruktur:
				parser = new MonopolFysiskskrabStartParser();
				break;
			case MonopolFysiskSkrabTransaktionStruktur:
				parser = new MonopolFysiskskrabTransaktionStrukturParser();
				break;
			case MonopolFysiskSkrabSlutStruktur:
				parser = new MonopolFysiskskrabSlutStrukturParser();
				break;
			case MonopolDantotoEventStartStruktur:
				parser = new MonopolDantotoEventStartStrukturParser();
				break;
			case MonopolDantotoTransaktionStruktur:
				parser = new MonopolDantotoTransaktionStrukturParser();
				break;
			case MonopolDantotoStartStruktur:
				parser = new MonopolDantotoSpilStartStrukturParser();
				break;
			case MonopolDantotoSlutStruktur:
				parser = new MonopolDantotoSpilSlutStrukturParser();
				break;
			case MonopolDantotoEventSlutStruktur:
				parser = new MonopolDantotoEventSlutStrukturParser();
				break;
			case MonopolDantotoEventTotalStruktur:
				parser = new MonopolDantotoTotalStrukturParser();
				break;

			case HesteagtigEventStartStruktur:
				parser = new HesteagtigEventStartStrukturParser();
				break;
			case HesteagtigTransaktionStruktur:
				parser = new HesteagtigTransaktionStrukturParser();
				break;
			case HesteagtigStartStruktur:
				parser = new HesteagtigSpilStartStrukturParser();
				break;
			case HesteagtigSlutStruktur:
				parser = new HesteagtigSpilSlutStrukturParser();
				break;
			case HesteagtigEventSlutStruktur:
				parser = new HesteagtigEventSlutStrukturParser();
				break;
			case HesteagtigEventTotalStruktur:
				parser = new HesteagtigTotalStrukturParser();
				break;

			case HestDKEventStartStruktur:
				parser = new HestDKEventStartStrukturParser();
				break;
			case HestDKTransaktionStruktur:
				parser = new HestDKTransaktionStrukturParser();
				break;
			case HestDKStartStruktur:
				parser = new HestDKSpilStartStrukturParser();
				break;
			case HestDKSlutStruktur:
				parser = new HestDKSpilSlutStrukturParser();
				break;
			case HestDKEventSlutStruktur:
				parser = new HestDKEventSlutStrukturParser();
				break;
			case HestDKEventTotalStruktur:
				parser = new HestDKTotalStrukturParser();
				break;

			case MonopolLandeDataStruktur:
				parser = new MonopolLandeDataStrukturParser();
				break;
			case SpilleautomatTransaktionStruktur:
				parser = new SpilleAutomatTransaktionStrukturParser();
				break;
			case SpilleautomatJackpotUdloesningStruktur:
				parser = new SpilleautomatJackpotUdloesningStrukturParser();
				break;
			case SpilleautomatEndOfDayStruktur:
				parser = new SpilleautomatEndOfDayStrukturParser();
				break;
			case MonopolLodtraekningTotalStruktur:
				parser = new MonopolLodtraekningTotalStrukturParser();
				break;
 */
			default:
				throw new IllegalArgumentException("Unable to find parser for standard record: " + parserType);
		}

		return parser;
	}

	public static StandardRecordTypes getStandardRecordTypeByTagName(String tagName) {
		return StandardRecordTypes.getTypeByRootTagName(tagName);
	}

}
