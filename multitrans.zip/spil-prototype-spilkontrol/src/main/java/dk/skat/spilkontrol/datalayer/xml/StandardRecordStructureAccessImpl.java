package dk.skat.spilkontrol.datalayer.xml;

import dk.skat.spilkontrol.business.model.StandardRecord;
import dk.skat.spilkontrol.business.model.standardrecords.StandardRecordTypes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import java.io.IOException;
import java.io.InputStream;

public class StandardRecordStructureAccessImpl {
	
	private final SAXParser saxParser;
	
	public StandardRecordStructureAccessImpl(SAXParser saxParser) {
		this.saxParser = saxParser;
	}
	
	public StandardRecord parseXmlGameFile(InputSource is, StandardRecordTypes standardRecordTypes) throws ParserConfigurationException, SAXException, IOException {
		StandardRecordStructureParser parser = StandardRecordParsersFactory.getParser(standardRecordTypes);
		return getStandardRecord(parser, is);
	}

	
	public StandardRecord parseXmlGameFile(InputStream is, StandardRecordTypes standardRecordTypes) throws ParserConfigurationException, SAXException, IOException {
		
		StandardRecordStructureParser parser = StandardRecordParsersFactory.getParser(standardRecordTypes);
		saxParser.parse(is, parser);
		StandardRecord record = parser.getStandardRecord();
		
		return record;
	}
	
	public StandardRecord parseXmlGameFile(InputStream is, String tagName) throws ParserConfigurationException, SAXException, IOException {
		StandardRecordStructureParser parser = StandardRecordParsersFactory.getParser(tagName);
        // System.out.println("StandardRecordStructureParser = " + parser + "  - tagName = " + tagName + " - ready to parse");
		saxParser.parse(is, parser);
        // System.out.println("StandardRecordStructureParser  after parse");
		StandardRecord record = parser.getStandardRecord();
        // System.out.println("StandardRecordStructureParser after getStandardRecord - StandardRecord = " + record + " - ready to return");
		return record;
	}

	private StandardRecord getStandardRecord(StandardRecordStructureParser parser, InputSource is) throws SAXException, IOException {
		saxParser.parse(is, parser);
		
		return parser.getStandardRecord();
	}
	
}
