package dk.skat.spilkontrol.datalayer.xml;

import dk.skat.spilkontrol.business.model.*;
import dk.skat.spilkontrol.datalayer.xml.exceptions.ParseDataXmlFileException;
import dk.skat.spilkontrol.datalayer.xml.exceptions.SchemaValidationException;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class StandardRecordStructureParser extends DefaultHandler {
		
	protected static final String emptyTagName = "";
	private final Map<String, IElementParser> elementParsers = new HashMap<String, IElementParser>();
	
	private final Deque<String> path = new LinkedList<String>(); // path to current processed element
	
	private StandardRecord stdRecord;
	
	
	private static final Map<String, Class<? extends StandardRecord>> standardRecordMap;
	
	static{
		standardRecordMap = new HashMap<String, Class<? extends StandardRecord>>();

/*
		standardRecordMap.put("KasinospilPrSessionStruktur", GameKasinoStandardStructure.class);
		standardRecordMap.put("KasinoSpilPrTr\u00e6kStruktur", GameKasinoStandardStructure.class);
*/
		standardRecordMap.put("PuljespilTransaktionStruktur", PuljespilTransaktionStandardRecord.class);
		standardRecordMap.put("PokerTurneringTransaktionStruktur", PokerTurneringTransaktionStrukturStandardRecord.class);
/*
		standardRecordMap.put("PokerCashGamePrH\u00E5ndStruktur", PokerGameStandardStructure.class);
		standardRecordMap.put("PokerCashGamePrSessionStruktur", PokerGameStandardStructure.class);
 */
		standardRecordMap.put("FastOddsTransaktionStruktur", FastOddsTransaktionStrukturRecord.class);
		standardRecordMap.put("FastOddsSlutStruktur", FastOddsSlutStrukturRecord.class);
		standardRecordMap.put("MonopolVirtuelFastOddsTransaktionStruktur", MonopolFastOddsTransaktionStrukturRecord.class);
		standardRecordMap.put("MonopolVirtuelFastOddsSlutStruktur", MonopolFastOddsSlutStrukturRecord.class);
		standardRecordMap.put("MonopolTalspilTransaktionStruktur", MonopolTalspilTransaktionStandardRecord.class);
		standardRecordMap.put("MonopolBingoNetskrabTransaktionStruktur", MonopolBingoNetskrabTransaktionStandardRecord.class);
		standardRecordMap.put("MonopolTalspilEndOfGameStruktur", MonopolTalspilEndOfGameStandardRecord.class);
		standardRecordMap.put("MonopolTalspilStartStruktur", MonopolTalspilStartStandardRecord.class);
		standardRecordMap.put("MonopolTalspilSlutStruktur", MonopolTalspilSlutStandardRecord.class);
		standardRecordMap.put("MonopolLandeDataStruktur", MonopolLandeDataStandardRecord.class);
		standardRecordMap.put("PokerTurneringSlutStruktur", PokerTurneringSlutStrukturStandardRecord.class);
		standardRecordMap.put("PokerTurneringStartStruktur", PokerTurneringStartStrukturStandardRecord.class);
		standardRecordMap.put("KasinoSpilleautomatTransaktionStruktur", KasinoSpilleautomatTransaktionStandardRecord.class);
		standardRecordMap.put("KasinoSpilleautomatJackpotStruktur", KasinoSpilleautomatJackpotStandardRecord.class);
/*
		standardRecordMap.put("ManagerspilTransaktionStruktur", ManagerSpilTransaktionStrukturStandardRecord.class);
 */
		standardRecordMap.put("PuljespilStartStruktur", PuljespilStartStandardRecord.class);
		standardRecordMap.put("PuljespilSlutStruktur", PuljespilSlutStandardRecord.class);
		standardRecordMap.put("PuljespilEndOfGameStruktur", PuljespilEndOfGameStandardRecord.class);
		standardRecordMap.put("EndOfDayRapportStruktur", EndOfDayStandardRecord.class);
		standardRecordMap.put("MonopolEndOfDayRapportStruktur", MonopolEndOfDayStandardRecord.class);
		standardRecordMap.put("JackpotUdl\u00f8sningStruktur", JackpotStandardRecord.class);
/*
		standardRecordMap.put("ManagerspilStartStruktur", ManagerSpilStartStrukturStandardRecord.class);
		standardRecordMap.put("ManagerspilSlutStruktur", ManagerSpilSlutStrukturStandardRecord.class);
 */
		standardRecordMap.put("MonopolLodtr\u00e6kningSlutStruktur", MonopolLodtraekningSlutStandardRecord.class);
		standardRecordMap.put("MonopolLodtr\u00e6kningStartStruktur", MonopolLodtraekningStartStandardRecord.class);
		standardRecordMap.put("MonopolBingoNetskrabStartStruktur", MonopolBingoNetskrabStartStandardRecord.class);
		standardRecordMap.put("MonopolFysiskSkrabStartStruktur", MonopolFysiskskrabStartStandardRecord.class);
		standardRecordMap.put("MonopolFysiskSkrabTransaktionStruktur", MonopolFysiskskrabTransaktionStandardRecord.class);
		standardRecordMap.put("MonopolFysiskSkrabSlutStruktur", MonopolFysiskskrabSlutStandardRecord.class);

		standardRecordMap.put("MonopolDantotoEventStartStruktur", MonopolDantotoEventStartStandardRecord.class);
		standardRecordMap.put("MonopolDantotoTransaktionStruktur", MonopolDantotoTransaktionStandardRecord.class);
		standardRecordMap.put("MonopolDantotoStartStruktur", MonopolDantotoSpilStartStandardRecord.class);
		standardRecordMap.put("MonopolDantotoSlutStruktur", MonopolDantotoSpilSlutStandardRecord.class);
		standardRecordMap.put("MonopolDantotoEventSlutStruktur", MonopolDantotoEventSlutStandardRecord.class);
		standardRecordMap.put("MonopolDantotoEventTotalStruktur", MonopolDantotoEventTotalStandardRecord.class);
/*
		standardRecordMap.put("HesteagtigEventStartStruktur", HesteagtigEventStartStandardRecord.class);
		standardRecordMap.put("HesteagtigTransaktionStruktur", HesteagtigTransaktionStandardRecord.class);
		standardRecordMap.put("HesteagtigStartStruktur", HesteagtigSpilStartStandardRecord.class);
		standardRecordMap.put("HesteagtigSlutStruktur", HesteagtigSpilSlutStandardRecord.class);
		standardRecordMap.put("HesteagtigEventSlutStruktur", HesteagtigEventSlutStandardRecord.class);
		standardRecordMap.put("HesteagtigEventTotalStruktur", HesteagtigEventTotalStandardRecord.class);

		standardRecordMap.put("HestDKEventStartStruktur", HestDKEventStartStandardRecord.class);
		standardRecordMap.put("HestDKTransaktionStruktur", HestDKTransaktionStandardRecord.class);
		standardRecordMap.put("HestDKStartStruktur", HestDKSpilStartStandardRecord.class);
		standardRecordMap.put("HestDKSlutStruktur", HestDKSpilSlutStandardRecord.class);
		standardRecordMap.put("HestDKEventSlutStruktur", HestDKEventSlutStandardRecord.class);
		standardRecordMap.put("HestDKEventTotalStruktur", HestDKEventTotalStandardRecord.class);

		standardRecordMap.put("SpilleautomatTransaktionStruktur", SpilleautomatTransaktionStandardRecord.class);
		standardRecordMap.put("SpilleautomatJackpotUdloesningStruktur", SpilleautomatJackpotUdloesningStandardRecord.class);
		standardRecordMap.put("SpilleautomatEndOfDayStruktur", SpilleautomatEndOfDayStandardRecord.class);
*/
		standardRecordMap.put("MonopolLodtr\u00e6kningTotalStruktur", MonopolLodtraekningTotalStrukturStandardRecord.class);


	}
	
	protected StandardRecordStructureParser() {
	}
	
	// return business object - standard record
	public StandardRecord getStandardRecord() {
		return stdRecord;
	}
	
	@Override
	public void startElement(String namespaceURI, String localName, String qName,
			Attributes attributes) throws SAXException {
		
		Class<? extends StandardRecord> standardRecordClazz = standardRecordMap.get(localName);
		if(standardRecordClazz != null){
			try {
				stdRecord = standardRecordClazz.newInstance();
			} catch (Exception e) {
				throw new IllegalArgumentException("Unable to create instance of type " + localName, e);
			}
		}
/*
        else	if ( "KasinospilSession".equals(localName) ) {
			((GameKasinoStandardStructure)stdRecord).addStandardRecordDetails(new KasinospilPrSessionStandardRecord());
		} else if ( "KasinospilPrTr\u00e6k".equals(localName) ) {
			((GameKasinoStandardStructure)stdRecord).addStandardRecordDetails(new KasinospilPrTraekStandardRecord());
		} else if ("PokerCashGamePrH\u00E5nd".equals(localName)) {
			((PokerGameStandardStructure)stdRecord).addStandardRecordDetails(new PokerCashPrHandStandardRecord());
		} else if ("CashGameSession".equals(localName)) {
			((PokerGameStandardStructure)stdRecord).addStandardRecordDetails(new PokerCashPrSessionStandardRecord());
		}
 */

		path.push(localName);
	}
	
	@Override
	public void characters(char[] chars, int start, int length) throws SAXException {
		IElementParser parser = getElementParserByTagName();
		if ( parser != null ) {
			try {
				parser.parse(new String(chars, start, length));
			} catch (ParseDataXmlFileException e) {
				throw new SAXException(e);
			}
		}
	}
	
	@Override
	public void error(SAXParseException e) throws SAXException {
		super.error(e);
		throw new SchemaValidationException("Standard record does not validate: "+e.getMessage(), e);
	}
	
	@Override
	public void endElement(String namespaceURI, String localName, String qName)
			throws SAXException {
		path.pop();
	}
	
	private IElementParser getElementParserByTagName() {
		return elementParsers.get( path.peek() );
	}
	
	public interface IElementParser {
		void parse(String value) throws ParseDataXmlFileException;
	}

	// customize parsing of xml elements
	@Target(ElementType.TYPE)
	@Retention(value=RetentionPolicy.RUNTIME)
	public @interface XmlElementParser {
		String tagName() default emptyTagName;	// it means use class name as tag name
	}

	public StandardRecord getStdRecord() {
		return stdRecord;
	}

	public void setStdRecord(StandardRecord stdRecord) {
		this.stdRecord = stdRecord;
	}

	public Map<String, IElementParser> getElementParsers() {
		return elementParsers;
	}

	public Deque<String> getPath() {
		return path;
	}
}
