package dk.skat.spilkontrol.datalayer.xml.exceptions;

import dk.skat.spilkontrol.commons.error.SpilkontrolErrorCode;
import dk.skat.spilkontrol.commons.error.SpilkontrolException;

/**
 *	Throw this when there is some error in the data, that prevents saving a standard record in the database.  
 *
 */
public class GameDataSemanticException extends SpilkontrolException {

	private static final long serialVersionUID = 939294534202056633L;

	public GameDataSemanticException(String message) {
		super(SpilkontrolErrorCode.ZipContainsInvalidStandardRecord, message);
	}
	
	public GameDataSemanticException(String message, Exception e) {
		super(SpilkontrolErrorCode.ZipContainsInvalidStandardRecord, message, e);
	}

}
