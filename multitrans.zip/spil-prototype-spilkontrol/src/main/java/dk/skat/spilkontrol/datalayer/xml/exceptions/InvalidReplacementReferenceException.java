package dk.skat.spilkontrol.datalayer.xml.exceptions;

import dk.skat.spilkontrol.commons.error.SpilkontrolErrorCode;
import dk.skat.spilkontrol.commons.error.SpilkontrolException;

public class InvalidReplacementReferenceException extends SpilkontrolException {

	public InvalidReplacementReferenceException(String message) {
		super(SpilkontrolErrorCode.ZipContainsInvalidReplacementReference, message);
	}

	private static final long serialVersionUID = 757393700620145288L;

}
