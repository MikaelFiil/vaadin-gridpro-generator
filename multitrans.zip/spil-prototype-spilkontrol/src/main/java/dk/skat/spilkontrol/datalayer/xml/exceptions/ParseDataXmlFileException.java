package dk.skat.spilkontrol.datalayer.xml.exceptions;


public class ParseDataXmlFileException extends Exception {

	/**
	 * Auto-generated
	 */
	private static final long serialVersionUID = 3515802982946567919L;

	public ParseDataXmlFileException(Exception e) {
		super(e);
	}
	
}
