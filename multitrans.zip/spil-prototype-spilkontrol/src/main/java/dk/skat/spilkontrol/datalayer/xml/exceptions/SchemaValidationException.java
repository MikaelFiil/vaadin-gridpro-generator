package dk.skat.spilkontrol.datalayer.xml.exceptions;

import org.xml.sax.SAXException;

public class SchemaValidationException extends SAXException {

	private static final long serialVersionUID = -8644051182708612069L;

	public SchemaValidationException(String message) {
		super(message);
	}

	public SchemaValidationException(String message, Exception e) {
		super(message, e);
	}


}
