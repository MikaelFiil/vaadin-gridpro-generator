package dk.skat.spilkontrol.datalayer.xml.exceptions;

import org.xml.sax.SAXException;

public class StopXmlSaxParserException extends SAXException{

	/**
	 * Auto-generated value
	 */
	private static final long serialVersionUID = 3623019147410569379L;

	public StopXmlSaxParserException(String message) {
		super(message);
	}
	
	public StopXmlSaxParserException(String message, Exception e) {
		super(message, e);
	}
}
