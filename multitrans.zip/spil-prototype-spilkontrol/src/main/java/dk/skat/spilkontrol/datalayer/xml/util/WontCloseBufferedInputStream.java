package dk.skat.spilkontrol.datalayer.xml.util;


import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;


public class WontCloseBufferedInputStream extends BufferedInputStream {
    private InputStream input;

    public WontCloseBufferedInputStream(InputStream input) {
        super(input);
        this.input = input;
    }

    public void close () {
        // Do nothing.
    }

    public void reallyClose() throws IOException {
        super.close ();
    }
}