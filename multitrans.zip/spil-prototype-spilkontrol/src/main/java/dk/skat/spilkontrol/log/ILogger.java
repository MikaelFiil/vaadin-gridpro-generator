package dk.skat.spilkontrol.log;

import org.apache.log4j.Priority;

import dk.skat.spilkontrol.log.layout.XmlWritable;

/**
 * An interface for logger implementations
 */
public interface ILogger {
    void trace(XmlWritable baseLogger);

    void trace(XmlWritable baseLogger, Throwable t);

    void debug(XmlWritable baseLogger);

    void debug(XmlWritable baseLogger, Throwable t);

    void info(XmlWritable baseLogger);
    
    void info(XmlWritable baseLogger, Throwable t);

    void warn(XmlWritable baseLogger);

    void warn(XmlWritable baseLogger, Throwable t);

    void error(XmlWritable baseLogger);

    void error(XmlWritable baseLogger, Throwable t);

    void fatal(XmlWritable baseLogger);

    void fatal(XmlWritable baseLogger, Throwable t);
    
    boolean isDebugEnabled();

    boolean isEnabledFor(Priority priority);

    boolean isInfoEnabled();

    boolean isTraceEnabled();
}
