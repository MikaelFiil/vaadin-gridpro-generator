package dk.skat.spilkontrol.log;

public interface LogStage {
	String getText();
}
