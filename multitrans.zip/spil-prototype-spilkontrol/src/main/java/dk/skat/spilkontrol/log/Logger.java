package dk.skat.spilkontrol.log;

import java.io.Serializable;
import java.lang.reflect.Method;

import org.apache.log4j.Priority;

import dk.skat.spilkontrol.log.layout.XmlWritable;

/**
 * Logger class for spilkontrol. The class instantiates the needed logger implementation and delegates all
 * calls to the implementation.
 * The implementation must implement <code>ILogger</code> and implement a static method <code>public static ILogger getLogger(Class<?> clazz)</code>
 *
 */
public final class Logger implements Serializable {

    private static final long serialVersionUID = 2091689497172019774L;
    private ILogger loggerImpl;
    
    private Logger(ILogger loggerImpl) {
    	this.loggerImpl = loggerImpl;
    }

    public static Logger getLogger(Class<?> clazz) {
    	ILogger loggerImpl;
    	String loggerClassName = System.getProperty("spilkontrol.log.class", "dk.skat.spilkontrol.log.logging.Log4JLogger");
		try {
			@SuppressWarnings("unchecked")
			Class<ILogger> loggerClass = (Class<ILogger>) Class.forName(loggerClassName);
			Method getLoggerMethod = loggerClass.getMethod("getLogger", new Class[] {Class.class});
			loggerImpl = (ILogger) getLoggerMethod.invoke(null, new Object[]{clazz});
			return new Logger(loggerImpl);
		} catch (Exception e) {
			throw new IllegalArgumentException("Error instantiating logger implementation: " + loggerClassName, e);
		}
    }

    public void trace(XmlWritable baseLogger) {
    	loggerImpl.trace(baseLogger);
    }

    public void trace(XmlWritable baseLogger, Throwable t) {
    	loggerImpl.trace(baseLogger, t);
    }

    public void debug(XmlWritable baseLogger) {
    	loggerImpl.debug(baseLogger);
    }

    public void debug(XmlWritable baseLogger, Throwable t) {
    	loggerImpl.debug(baseLogger, t);
    }

    public void info(XmlWritable baseLogger) {
    	loggerImpl.info(baseLogger);
    }

    public void info(XmlWritable baseLogger, Throwable t) {
    	loggerImpl.info(baseLogger, t);
    }
    
    public void warn(XmlWritable baseLogger) {
    	loggerImpl.warn(baseLogger);
    }

    public void warn(XmlWritable baseLogger, Throwable t) {
    	loggerImpl.warn(baseLogger, t);
    }

    public void error(XmlWritable baseLogger) {
    	loggerImpl.error(baseLogger);
    }

    public void error(XmlWritable baseLogger, Throwable t) {
    	loggerImpl.error(baseLogger, t);
    }

    public void fatal(XmlWritable baseLogger) {
    	loggerImpl.fatal(baseLogger);
    }

    public void fatal(XmlWritable baseLogger, Throwable t) {
    	loggerImpl.fatal(baseLogger, t);
    }

    public boolean isDebugEnabled() {
        return loggerImpl.isDebugEnabled();
    }

    public boolean isEnabledFor(Priority priority) {
        return loggerImpl.isEnabledFor(priority);
    }

    public boolean isInfoEnabled() {
        return loggerImpl.isInfoEnabled();
    }

    public boolean isTraceEnabled() {
        return loggerImpl.isTraceEnabled();
    }

}
