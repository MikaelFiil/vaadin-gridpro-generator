package dk.skat.spilkontrol.log.layout;

import org.apache.log4j.Layout;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;
import org.apache.log4j.spi.ThrowableInformation;
import org.joda.time.DateTime;
import org.joda.time.format.ISODateTimeFormat;

import dk.skat.spilkontrol.log.logging.LoggerData;
import dk.skat.spilkontrol.log.util.XmlHelper;

public class XmlLayout extends Layout {
	
	public static final String EXCEPTION_ELEMENT_NAME = "exception";
	private boolean escapeXMLCharacters = true;

	@Override
	public String format(LoggingEvent event) {
		Object logEvent = event.getMessage();
	    long timestamp = event.timeStamp;

	    if ((logEvent instanceof XmlWritable)) {
	      return writeAsXml((XmlWritable)logEvent, timestamp, event.getThrowableInformation());
	    }

	    LogLog.warn("Message does not implement the toXML method: '" + logEvent.toString() + "'");

	    if (event.getThrowableInformation() != null) {
	      StringBuilder sb = new StringBuilder(logEvent.toString());
	      String[] s = event.getThrowableInformation().getThrowableStrRep();

	      if (s != null) {
	        sb.append("Exception: ");
	        for (String line : s) {
	          sb.append(line);
	        }
	      }
	      return XmlHelper.LINE_SEPARATOR;
	    }
	    return logEvent.toString() + XmlHelper.LINE_SEPARATOR;
	}
	
	private String writeAsXml(XmlWritable writeableObject, long timestamp, ThrowableInformation throwableInformation)
	  {
	    StringBuilder sb = new StringBuilder();

	    sb.append("<log>");

	    if ((writeableObject instanceof LoggerData)) {
	      XmlHelper.appendXml("currentDateTime", new DateTime(timestamp).toString(ISODateTimeFormat.dateTime()), sb);
	    }

	    if ((writeableObject instanceof XmlWritable)) {
	      sb.append(((XmlWritable)writeableObject).toXml(this.escapeXMLCharacters));
	    }
	    else {
	      sb.append(writeableObject.toXml());
	    }

	    if (throwableInformation != null) {
	      sb.append("<").append("exception").append(">");
	      String[] s = throwableInformation.getThrowableStrRep();
	      if (s != null) {
	        for (String line : s) {
	          sb.append(line);
	          sb.append(XmlHelper.LINE_SEPARATOR);
	        }
	      }
	      sb.append("</").append("exception").append(">");
	    }

	    sb.append("</log>");
	    sb.append(XmlHelper.LINE_SEPARATOR);

	    return sb.toString();
	  }

	@Override
	public void activateOptions() {
	}
	
	@Override
	public boolean ignoresThrowable() {
		return false;
	}

}
