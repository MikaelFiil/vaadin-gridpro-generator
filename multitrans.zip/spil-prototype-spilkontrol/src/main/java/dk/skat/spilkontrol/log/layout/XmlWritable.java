package dk.skat.spilkontrol.log.layout;

public interface XmlWritable {
	String toXml();
	
	String toXml(boolean escapeXmlCharacters);
}
