package dk.skat.spilkontrol.log.logging;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;

import dk.skat.spilkontrol.log.ILogger;
import dk.skat.spilkontrol.log.layout.XmlWritable;
import dk.skat.spilkontrol.log.util.ServerInfo;

/**
 * The default implementation which only logs to standard out. Should only be
 * used in early development or in fall back cases where the logger can not be
 * instantiated.
 * 
 */
public class Log4JLogger implements ILogger {


	public static final String DOMAIN_SERVER_NAME = "domainservername";
	public static final String SERVER_NAME = "servername";

	private Logger logger;

	private static LogConfig logConfig;
	
	private synchronized void init() {
		if(logConfig == null) {
			logConfig = new LogConfig();
			logConfig.init();
		}
	}
	
	public Log4JLogger(Class<?> clazz) {
		init();
		this.logger = org.apache.log4j.Logger.getLogger(clazz);
	}

	public static ILogger getLogger(Class<?> clazz) {
		return new Log4JLogger(clazz);
	}
	
	private void log(Priority p, XmlWritable baseLogger, Throwable t) {
	    LoggerData loggerData = new LoggerData(baseLogger);
	    loggerData.setServerName(ServerInfo.getServerName());
	    loggerData.setDomain(ServerInfo.getDomainServerName());
	    loggerData.setLevel(p.toString());
	    if (t == null){
	    	this.logger.log(p, loggerData);
	    } else {
	    	this.logger.log(p, loggerData , t);
	    }
	  }

	@Override
	public void trace(XmlWritable baseLogger) {
		log(Level.TRACE, baseLogger, null);
	}

	@Override
	public void trace(XmlWritable baseLogger, Throwable t) {
		log(Level.TRACE, baseLogger, t);
	}

	@Override
	public void debug(XmlWritable baseLogger) {
		log(Level.DEBUG, baseLogger, null);

	}

	@Override
	public void debug(XmlWritable baseLogger, Throwable t) {
		log(Level.DEBUG, baseLogger, t);
	}

	@Override
	public void info(XmlWritable baseLogger) {
		log(Level.INFO, baseLogger, null);
	}

	@Override
	public void info(XmlWritable baseLogger, Throwable t) {
		log(Level.INFO, baseLogger, t);
	}

	@Override
	public void warn(XmlWritable baseLogger) {
		log(Level.WARN, baseLogger, null);
	}

	@Override
	public void warn(XmlWritable baseLogger, Throwable t) {
		log(Level.WARN, baseLogger, t);
	}

	@Override
	public void error(XmlWritable baseLogger) {
		log(Level.ERROR, baseLogger, null);
	}

	@Override
	public void error(XmlWritable baseLogger, Throwable t) {
		log(Level.ERROR, baseLogger, t);
	}

	@Override
	public void fatal(XmlWritable baseLogger) {
		log(Level.FATAL, baseLogger, null);
	}

	@Override
	public void fatal(XmlWritable baseLogger, Throwable t) {
		log(Level.FATAL, baseLogger, t);
	}

	@Override
	public boolean isDebugEnabled() {
		return this.logger.isDebugEnabled();
	}

	@Override
	public boolean isEnabledFor(Priority priority) {
		 return this.logger.isEnabledFor(priority);
	}

	@Override
	public boolean isInfoEnabled() {
	    return this.logger.isInfoEnabled();
	}

	@Override
	public boolean isTraceEnabled() {
	    return this.logger.isTraceEnabled();
	}
	
}
