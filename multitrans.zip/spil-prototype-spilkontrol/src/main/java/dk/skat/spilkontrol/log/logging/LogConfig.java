package dk.skat.spilkontrol.log.logging;

import java.net.URL;

import org.apache.log4j.xml.DOMConfigurator;

public class LogConfig {

	public void init() {
		URL url = LogConfig.class.getResource("/log4jconfig.xml");
        DOMConfigurator.configure(url);
	}

}
