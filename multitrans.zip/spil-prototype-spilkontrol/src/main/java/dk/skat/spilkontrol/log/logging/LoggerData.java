package dk.skat.spilkontrol.log.logging;

import java.io.Serializable;

import dk.skat.spilkontrol.log.layout.XmlWritable;
import dk.skat.spilkontrol.log.util.XmlHelper;

public class LoggerData implements Serializable, XmlWritable {

	private static final long serialVersionUID = 4806762029514647407L;
	private XmlWritable payload;
	private String level;
	private String domain;
	private String serverName;

	public LoggerData(XmlWritable payload) {
		this.payload = payload;
	}

	public XmlWritable getPayload() {
		return this.payload;
	}

	public String getLevel() {
		return this.level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getDomain() {
		return this.domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getServerName() {
		return this.serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	
	@Override
	public String toXml() {
		return toXml(true);
	}

	@Override
	public String toXml(boolean escapeXmlCharacters) {
		StringBuilder sb = new StringBuilder();

		XmlHelper.appendXml("logType", getLevel(), sb);
		XmlHelper.appendXml("domain", getDomain(), sb);
		XmlHelper.appendXml("serverName", getServerName(), sb);
		if (this.payload != null) {
			sb.append(this.payload.toXml(escapeXmlCharacters));
		}
		return sb.toString();
	}

	public String toString() {
		if (this.payload != null) {
			return this.payload.toString();
		}
		return toXml();
	}

}
