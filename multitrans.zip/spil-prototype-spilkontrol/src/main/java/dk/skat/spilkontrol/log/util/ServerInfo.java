package dk.skat.spilkontrol.log.util;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.helpers.LogLog;

public final class ServerInfo {
	private static boolean initialized = false;
	private static String servername = null;
	private static String domainservername = null;
	
	private ServerInfo() {}

	private static synchronized void initialize() {
		try {
			ObjectName service = new ObjectName(
					"com.bea:Name=RuntimeService,Type=weblogic.management.mbeanservers.runtime.RuntimeServiceMBean");

			InitialContext ctx = new InitialContext();
			MBeanServer server = (MBeanServer) ctx
					.lookup("java:comp/env/jmx/runtime");

			ObjectName serverrt = (ObjectName) server.getAttribute(service,
					"ServerRuntime");
			servername = (String) server.getAttribute(serverrt, "Name");

			ObjectName domainconfig = (ObjectName) server.getAttribute(service,
					"DomainConfiguration");
			domainservername = (String) server.getAttribute(domainconfig,
					"Name");

			initialized = true;
		} catch (NamingException e) {
			LogLog.debug(
					"Got a "
							+ e
							+ " while trying to look up server info. Running outside server context?");
		} catch (Exception e) {
			throw new IllegalStateException(e.getMessage());
		}
	}

	public static String getServerName() {
		if (!initialized) {
			initialize();
		}
		return servername;
	}

	public static String getDomainServerName() {
		if (!initialized) {
			initialize();
		}
		return domainservername;
	}

	static {
		initialize();
	}
}