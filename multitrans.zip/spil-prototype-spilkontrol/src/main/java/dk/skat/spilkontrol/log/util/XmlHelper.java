package dk.skat.spilkontrol.log.util;

import org.apache.commons.lang.StringEscapeUtils;

public final class XmlHelper {
	public static final String CURRENT_DATE_TIME = "currentDateTime";
	public static final String DOMAIN = "domain";
	public static final String SERVER_NAME = "serverName";
	public static final String LEVEL = "logType";
	public static final String LINE_SEPARATOR = System
			.getProperty("line.separator");

	private XmlHelper() {}
	
	public static void appendXml(String tag, String value, StringBuilder sb) {
		appendXml(tag, value, sb, true);
	}

	public static void appendXml(String tag, String value, StringBuilder sb,
			boolean escapeXMLCharacters) {
		if (value == null) {
			return;
		}

		sb.append('<');
		sb.append(tag);
		sb.append('>');
		if (escapeXMLCharacters) {
			sb.append(StringEscapeUtils.escapeXml(value));
		} else {
			sb.append(value);
		}
		sb.append('<');
		sb.append('/');
		sb.append(tag);
		sb.append('>');
	}
}