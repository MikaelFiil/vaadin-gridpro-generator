package dk.skat.spilkontrol.validate;

import dk.skat.spilkontrol.commons.configuration.SpilkontrolConfiguration;
import dk.skat.spilkontrol.commons.configuration.SpilkontrolConfigurationException;
import dk.skat.spilkontrol.commons.log.MessageLoggerVo;
import dk.skat.spilkontrol.log.Logger;

import java.util.zip.ZipEntry;

public abstract class BaseZipProcessor {

    private static Logger logger = Logger.getLogger(BaseZipProcessor.class);

    public static final int MAX_ZIP_ENTRY_SIZE = 180000000;

    private static final String CONFIG_PROPERTY_UNZIP_PATH = "XmlFileProcessing.unzipPath";
    private static final String DEFAULT_UNZIP_PATH = "/opt/oracle/middleware/wlsdomains/wlsa-domain/unzipped";

    private String baseUnzipPath;
    private String safeIdHandledIndividually;

    /**
     * reads the marksize property from the configuration, for buffer using mark in XmlFileProcessor.
     * 200 megabyte is the default value. We have seen files ~50 megabytes.
     */
    int readMarkSize() {

        int markSize = 2147000000;
        try {
            markSize = Integer.parseInt((SpilkontrolConfiguration.getValue("XmlFileProcessing.marksize")));

        } catch (NumberFormatException | SpilkontrolConfigurationException e1) {
            logger.warn(new MessageLoggerVo("Can not parse the configuration property XmlFileProcessing.marksize, " + e1.getMessage()));
        }
        return markSize;
    }

/*
    boolean processedSuccessfully(ZipFileProcessor.ProcessingResult result) {
        return result.equals(ZipFileProcessor.ProcessingResult.OK) || result.equals(ZipFileProcessor.ProcessingResult.ReplacementData);
    }
 */
    protected String readConfigurationString(String key, String defaultValue) {
        String value;

        try {
            value = SpilkontrolConfiguration.getValue(key);
            if (value == null) {
                value = defaultValue;
            }
        } catch (Exception e) {
            logger.warn(new MessageLoggerVo("Can not parse the configuration property '" + key + "', default value used: " + defaultValue));
            value = defaultValue;
        }

        return value;
    }

    /**
     * @param dataFile source zip file wrapper
     * @return full path to the directory where the entire zip file gets extracted
     */
/*
    protected String getTargetExtractPath(DataFile dataFile) {
        if (baseUnzipPath == null) {
            baseUnzipPath = readConfigurationString(CONFIG_PROPERTY_UNZIP_PATH, DEFAULT_UNZIP_PATH);
        }
        String zipFileName = dataFile.getDataFileName();
        String extractFolderName = zipFileName.substring(0, zipFileName.length() - ".zip".length());
        return baseUnzipPath + '/' + extractFolderName;
    }
 */

    /**
     * @param dataFile source zip file wrapper
     * @param zipEntry a single entry within the zip file
     * @return full path to a single extracted zip entry
     */
/*
    protected String getZipEntryExtractPath(DataFile dataFile, ZipEntry zipEntry) {
        return getTargetExtractPath(dataFile) + '/' + zipEntry.getName();
    }

    boolean isZipFileHandledIndividually(DataFile dataFile) {
        if (safeIdHandledIndividually == null) {
            safeIdHandledIndividually = readConfigurationString("timerjob.safeIdHandledIndividually", "DLOLoerdagsLotto");
        }
        return safeIdHandledIndividually.equals(dataFile.getSafeIdFromFilename());
    }
 */
}
