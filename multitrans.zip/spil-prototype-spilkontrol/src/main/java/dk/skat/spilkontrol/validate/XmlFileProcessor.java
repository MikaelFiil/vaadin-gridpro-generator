package dk.skat.spilkontrol.validate;

import dk.skat.spilkontrol.business.model.StandardRecord;
import dk.skat.spilkontrol.commons.configuration.SpilkontrolConfiguration;
import dk.skat.spilkontrol.commons.configuration.SpilkontrolConfigurationException;
import dk.skat.spilkontrol.commons.log.MessageLoggerVo;
import dk.skat.spilkontrol.commons.string.StringUtil;
import dk.skat.spilkontrol.datalayer.xml.StandardRecordStructureAccessImpl;
import dk.skat.spilkontrol.datalayer.xml.exceptions.StopXmlSaxParserException;
import dk.skat.spilkontrol.log.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class XmlFileProcessor {

	private static Logger logger  = Logger.getLogger(XmlFileProcessor.class);

    private SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
	private static final Map<String, Schema> schemaCache = new ConcurrentHashMap<String, Schema>();
	private int markSize = 2147000000;
	private final FirstXmlElementReader xmlReader;


    public XmlFileProcessor() {
        saxParserFactory = SAXParserFactory.newInstance();
        String name = saxParserFactory.getClass().getName();

        try {
            // saxParserFactory.setValidating(true);
            saxParserFactory.setNamespaceAware(true);
            saxParserFactory.setFeature("http://xml.org/sax/features/namespace-prefixes", true);
            saxParserFactory.setFeature("http://xml.org/sax/features/namespaces", true);
        } catch (ParserConfigurationException | SAXNotRecognizedException | SAXNotSupportedException e) {
            throw new RuntimeException(e);
        }
        this.xmlReader = new FirstXmlElementReader();
        markSize = readMarkSize();
    }

    /**
     * reads the marksize property from the configuration, for buffer using mark in XmlFileProcessor.
     * 200 megabyte is the default value. We have seen files ~50 megabytes.
     */
    int readMarkSize() {

        int markSize = 2147000000;
        try {
            markSize = Integer.parseInt((SpilkontrolConfiguration.getValue("XmlFileProcessing.marksize")));

        } catch (NumberFormatException | SpilkontrolConfigurationException e1) {
            logger.warn(new MessageLoggerVo("Can not parse the configuration property XmlFileProcessing.marksize, " + e1.getMessage()));
        }
        return markSize;
    }


	private String findRootTagName(InputStream is) throws SAXException, IOException, ParserConfigurationException {
		SAXParser saxParser = saxParserFactory.newSAXParser();
		is.mark(markSize);  // magic number required for successful reset of stream
		try {
			saxParser.parse(is, xmlReader);
		} catch(StopXmlSaxParserException stop) {
			// all fine, just stop parsing
            // System.out.println("StopXmlSaxParserException = " + stop);
		}
		is.reset(); // go to the beginning of the file
		return xmlReader.getFirstTagQName();
	}

	/**
	 * parses file and creates the standard record pojo.
	 * @param is
	 * @return
	 * @throws SAXException
	 * @throws IOException
	 * @throws ParserConfigurationException
	 */
	public StandardRecord getStardardRecord(InputStream is) throws SAXException, IOException, ParserConfigurationException {
		String rootTagName = findRootTagName(is);
		SAXParser saxParser = getValidatingParser(is, rootTagName);

		StandardRecordStructureAccessImpl standardRecordStructureAccess = new StandardRecordStructureAccessImpl(saxParser);
		logger.debug( new MessageLoggerVo(Thread.currentThread().getId()+",TIMEMESSUREMENT2, Inside getStardardRecord just before actuall parsing of roottagname : "+rootTagName +" time: ,"  +System.nanoTime() ));
		StandardRecord standardRecord = standardRecordStructureAccess.parseXmlGameFile(is, rootTagName);
		logger.debug( new MessageLoggerVo(Thread.currentThread().getId()+",TIMEMESSUREMENT2, Inside getStardardRecord just after actuall parsing of roottagname : "+rootTagName +" time: ,"  +System.nanoTime() ));

		return standardRecord;
	}


	private class FirstXmlElementReader extends DefaultHandler {

		private String firstTagName = "";

		@Override
		public void startElement(String namespaceURI, String localName, String qName, Attributes attributes) throws SAXException {
			this.firstTagName = localName;
			throw new StopXmlSaxParserException("Stop processing, because first element was read");
		}

		public String getFirstTagQName() {
			return firstTagName;
		}

	}

	private SAXParser getValidatingParser(InputStream is, String rootTagName) throws SAXException, IOException {
		try {
			Schema schema = getSchemaForXmlFile(rootTagName);
			// Create a new factory for validation to avoid threading issues and state corruption on the shared factory
			SAXParserFactory factory = SAXParserFactory.newDefaultNSInstance();
            // factory.setValidating(true);
			factory.setNamespaceAware(true);
			factory.setFeature("http://xml.org/sax/features/namespace-prefixes", true);
			factory.setFeature("http://xml.org/sax/features/namespaces", true);
            factory.setSchema(schema);
			return factory.newSAXParser();
		} catch (Exception e) {
			throw new StopXmlSaxParserException("Error configuring validating XML parser", e);
		}
	}

	private Schema getSchemaForXmlFile(String rootTagName) throws SAXException, IOException {
		Schema schema;
		if (schemaCache.containsKey(rootTagName)) {
			schema = schemaCache.get(rootTagName);
		} else {
			String urlString = String.format("xsd/Monopol/view/%1$sType.xsd", StringUtil.replaceDanishChars(rootTagName));
			SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			URL schemaUrl = ClassLoader.getSystemResource(urlString);
			if (schemaUrl == null) {
				throw new SAXException("Could not find schema file: " + urlString);
			}
			schema = schemaFactory.newSchema(schemaUrl);
			logger.debug(new MessageLoggerVo(String.format("Returning schema %s for standard record root element %s", urlString, rootTagName)));
			if (!schemaCache.containsKey(rootTagName)) {
				schemaCache.put(rootTagName, schema);
			}
		}
		return schema;
	}
}