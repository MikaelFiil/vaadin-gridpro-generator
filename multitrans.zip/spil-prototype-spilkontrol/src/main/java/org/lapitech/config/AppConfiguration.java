package org.lapitech.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import static org.springframework.transaction.annotation.RollbackOn.ALL_EXCEPTIONS;



@Configuration
@EnableTransactionManagement(rollbackOn=ALL_EXCEPTIONS)
public class AppConfiguration {



}
