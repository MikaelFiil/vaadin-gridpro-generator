package org.lapitech.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Data
@Component
@PropertySource("classpath:application.properties")
public class SPMValueProvider {

    @Value("${xml.root.dir}")
    private String xmlRootDir;

    public static final String SPILLER_INFORMATION_IDENTIFICATION = "SpillerInformationIdentifikation";
    public static final String SPIL_TRANSAKTION_IDENTIFICATION = "SpilTransaktionIdentifikation";

}
