package org.lapitech.errorlogs.domain;

import lombok.Data;

import java.time.LocalDateTime;


/**
 * create table error_log
 *   (error_log_id          number primary key,
 *    log_timestamp         timestamp(3),
 *    spiludbyder           varchar2(45 CHAR),
 *    spilfilidentifikation varchar2(300 CHAR),
 *    originating_from      varchar2(300 CHAR),
 *    error_text            varchar2(2000 CHAR),
 *    full_error            CLOB);
 *
 * create or replace procedure log_errors
 *    (p_spiludbyder           in varchar2,
 *     p_spilfilidentifikation in varchar2,
 *     p_originating_from      in varchar2,
 *     p_error_text            in varchar2,
 *     p_full_error            in CLOB)
 */
@Data
public class ErrorMessage {

    private long Id;
    private LocalDateTime logTimestamp;

    private String spilUdbyder;
    private String spilfilIdentifikation;
    private String originatingFrom;
    private String errorMessage;
    private String errorMessageLong;

}
