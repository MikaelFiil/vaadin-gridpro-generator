package org.lapitech.errorlogs.service;

import org.lapitech.errorlogs.domain.ErrorMessage;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


/**
 * create table error_log
 *   (error_log_id          number primary key,
 *    log_timestamp         timestamp(3),
 *    spiludbyder           varchar2(45 CHAR),
 *    spilfilidentifikation varchar2(300 CHAR),
 *    originating_from      varchar2(300 CHAR),
 *    error_text            varchar2(2000 CHAR),
 *    full_error            CLOB);
 *
 * create or replace procedure log_errors
 *    (p_spiludbyder           in varchar2,
 *     p_spilfilidentifikation in varchar2,
 *     p_originating_from      in varchar2,
 *     p_error_text            in varchar2,
 *     p_full_error            in CLOB)
 */

@Repository
public class ErrorMessageRepository {

    private final DataSource dataSource;

    ErrorMessageRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }


    @Transactional
    public void saveErrorMessage(ErrorMessage errorMessage) throws SQLException {
        String sql = """
            {call log_errors(?, ?, ?, ?, ?)}
         """;
        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, errorMessage.getSpilUdbyder());
            ps.setString(2, errorMessage.getSpilfilIdentifikation());
            ps.setString(3, errorMessage.getOriginatingFrom());
            ps.setString(4, errorMessage.getErrorMessage());
            ps.setString(5, errorMessage.getErrorMessageLong());
            ps.executeUpdate();
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
    }


    @Transactional(readOnly = true)
    public List<ErrorMessage> listErrorMessages() throws SQLException {
        String sql = """
            select error_log_id, log_timestamp, spiludbyder, spilfilidentifikation, originating_from, error_text, full_error from error_log
            order by log_timestamp desc
         """;
        List<ErrorMessage> errorMessageList = new ArrayList<>();
        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ResultSet rs =  ps.executeQuery();
            while (rs.next()) {
                ErrorMessage errorMessage = new ErrorMessage();
                errorMessage.setId(rs.getLong("error_log_id"));
                errorMessage.setLogTimestamp(rs.getTimestamp("log_timestamp").toLocalDateTime());
                errorMessage.setSpilUdbyder(rs.getString("spiludbyder"));
                errorMessage.setSpilfilIdentifikation(rs.getString("spilfilidentifikation"));
                errorMessage.setOriginatingFrom(rs.getString("originating_from"));
                errorMessage.setErrorMessage(rs.getString("error_text"));
                errorMessage.setErrorMessageLong(rs.getString("full_error"));
                errorMessageList.add(errorMessage);
            }

        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return errorMessageList;
    }

}
