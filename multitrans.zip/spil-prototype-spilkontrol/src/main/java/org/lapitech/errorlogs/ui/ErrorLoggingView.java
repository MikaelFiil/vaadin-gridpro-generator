package org.lapitech.errorlogs.ui;


import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Main;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.shared.SelectionPreservationMode;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Menu;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.theme.lumo.LumoUtility;
import org.lapitech.base.ui.component.ViewToolbar;
import org.lapitech.errorlogs.domain.ErrorMessage;
import org.lapitech.errorlogs.service.ErrorMessageRepository;

import java.sql.SQLException;

@Route("error-logs")
@PageTitle("Error logs")
@Menu(order = 600, icon = "vaadin:clipboard-check", title = "Error Logs")
public class ErrorLoggingView extends Main {

    private final ErrorMessageRepository errorMessageRepository;

    private Grid<ErrorMessage> errorGrid;
    private TextField spilUdbyder;
    private TextField spilfilIdentifikation;
    private TextField originatingFrom;
    private TextField errorMessage;
    private TextField errorMessageTimestamp;
    private TextArea errorMessageLong;
    private Button refreshBtn;


    public ErrorLoggingView(ErrorMessageRepository errorMessageRepository) {
        this.errorMessageRepository = errorMessageRepository;
        setSizeFull();
        addClassNames(LumoUtility.BoxSizing.BORDER, LumoUtility.Display.FLEX,
                LumoUtility.FlexDirection.COLUMN,
                LumoUtility.Padding.MEDIUM, LumoUtility.Gap.SMALL);
        add(new ViewToolbar("Error Logs Demo"));
        initUI();
        add(errorGrid, refreshBtn);
        add(new HorizontalLayout(spilUdbyder, spilfilIdentifikation, originatingFrom, errorMessageTimestamp));
        add(new HorizontalLayout(errorMessage));
        add(errorMessageLong);
        buildUX();
        refresh();
    }

    private void initUI() {
        errorGrid = new Grid<>(ErrorMessage.class);
        errorGrid.setHeight("20rem");
        errorGrid.setMinHeight("20rem");
        errorGrid.removeColumns(errorGrid.getColumnByKey("errorMessageLong"));
        errorGrid.setColumnOrder(errorGrid.getColumnByKey("id"), errorGrid.getColumnByKey("logTimestamp"),
                errorGrid.getColumnByKey("spilUdbyder"), errorGrid.getColumnByKey("spilfilIdentifikation"),
                errorGrid.getColumnByKey("originatingFrom"), errorGrid.getColumnByKey("errorMessage"));
        errorGrid.setEmptyStateText("No error messages found");
        errorGrid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT);
        errorGrid.setSelectionPreservationMode(SelectionPreservationMode.PRESERVE_EXISTING);
        errorGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
        errorGrid.getColumns().forEach(col -> {
            col.setAutoWidth(true);
            col.setResizable(true);
        });

        spilUdbyder = new TextField("Spiludbyder");
        spilUdbyder.setReadOnly(true);
        spilfilIdentifikation = new TextField("Spilfilidentifikation");
        spilfilIdentifikation.setWidth("30rem");
        spilfilIdentifikation.setReadOnly(true);
        originatingFrom = new TextField("Originating from");
        originatingFrom.setWidth("30rem");
        originatingFrom.setReadOnly(true);
        errorMessage = new TextField("Error Message");
        errorMessage.setWidth("100%");
        errorMessage.setReadOnly(true);
        errorMessageTimestamp = new TextField("Error Message Timestamp");
        errorMessageTimestamp.setWidth("15rem");
        errorMessageTimestamp.setReadOnly(true);
        errorMessageLong = new TextArea("Error Message Long");
        errorMessageLong.setWidth("100%");
        errorMessageLong.setHeight("100%");
        errorMessageLong.setReadOnly(true);

        refreshBtn = new Button("Refresh");
        refreshBtn.setWidth("10rem");
        refreshBtn.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
    }

    private void buildUX() {
        errorGrid.addSelectionListener(evt -> {
            evt.getFirstSelectedItem().ifPresent(item -> {
                spilUdbyder.setValue(item.getSpilUdbyder());
                spilfilIdentifikation.setValue(item.getSpilfilIdentifikation());
                originatingFrom.setValue(item.getOriginatingFrom());
                errorMessage.setValue(item.getErrorMessage());
                errorMessageTimestamp.setValue(item.getLogTimestamp().toString());
                errorMessageLong.setValue(item.getErrorMessageLong());
            });
        });

        refreshBtn.addClickListener(_ -> refresh());
    }

    private void refresh() {
        try {
            errorGrid.setItems(errorMessageRepository.listErrorMessages());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
