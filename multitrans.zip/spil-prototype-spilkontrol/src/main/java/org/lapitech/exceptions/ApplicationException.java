package org.lapitech.exceptions;

import lombok.Data;

@Data
public class ApplicationException extends RuntimeException {

    private final String message;
    private final Exception ex;

    public ApplicationException(String msg, Exception ex) {
        super(ex);
        this.message = msg;
        this.ex = ex;
    }


}
