package org.lapitech.tampertoken.domain;

public class Safe extends Ftp {

	private String safeId;
	private String safeNote;
	
	
	public void setSafeId(String safeId) {
		this.safeId = safeId;
	}

	public Safe() {
		super();
	}

	public Safe(String safeId, String dataFilePath) {
		this.safeId = safeId;
		setDataFilePath(dataFilePath);
	}

	public Safe(String safeId) {
		this.safeId = safeId;
	}

	public String getSafeId() {
		return safeId;
	}
	
	public String getSafeNote() {
		return safeNote;
	}

	public void setSafeNote(String safeNote) {
		this.safeNote = safeNote;
	}

    @Override
	public String toString() {
		return "Safe [safeId=" + safeId + ", host=" + getHost()
				+ ", port=" + getPort() + ", userName=" + getUserName() + ", password="
				+ getPassword() + "]";
	}
}
