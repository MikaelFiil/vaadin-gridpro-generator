package org.lapitech.tampertoken.domain;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class TamperTokenZipQueue {

    String spilUdbyderNavn;
    String spilfilIdentifikation;
    String zipFileName;
    LocalDateTime created;

}
