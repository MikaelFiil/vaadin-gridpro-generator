package org.lapitech.tampertoken.service;


import org.lapitech.exceptions.ApplicationException;
import org.lapitech.tampertoken.domain.TamperTokenZipQueue;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.*;
import java.util.Optional;

@Service
public class QueueProducerConsumer {

    private final DataSource dataSource;

    public QueueProducerConsumer(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Transactional
    public String addTamperTokenToQueue(TamperTokenZipQueue tamperToken) throws SQLException {
        String sql = """
                {call queue_tampertoken(TAMPER_TOKEN_ZIP_QUEUE_TYPE(?, ?, ?, CURRENT_TIMESTAMP), ?)}
        """;

        Connection con = DataSourceUtils.getConnection(dataSource);
        int idx = 1;
        try (CallableStatement cs = con.prepareCall(sql)) {
            cs.setString(idx++, tamperToken.getSpilUdbyderNavn());
            cs.setString(idx++, tamperToken.getSpilfilIdentifikation());
            cs.setString(idx++, tamperToken.getZipFileName());
            cs.registerOutParameter(4, Types.VARCHAR);

            cs.execute();
            String msgId = cs.getString(4);
            System.out.println("Message ID: " + msgId);
            return msgId;
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
    }


    @Transactional
    public Optional<TamperTokenZipQueue> getTamperTokenFromQueue(String spilUdbyderNavn) throws SQLException {
        String sql = """
                {call next_tampertoken(?, ?)}
        """;

        TamperTokenZipQueue tamperToken = new TamperTokenZipQueue();
        Connection con = DataSourceUtils.getConnection(dataSource);

        try (CallableStatement cs = con.prepareCall(sql)) {
            cs.setString(1, spilUdbyderNavn);
            cs.registerOutParameter(2, Types.STRUCT, "TAMPER_TOKEN_ZIP_QUEUE_TYPE");

            cs.execute();
            Struct tamperTokenStruct = (Struct) cs.getObject(2);
            Object[] attrs = tamperTokenStruct.getAttributes();
            tamperToken.setSpilUdbyderNavn((String) attrs[0]);
            tamperToken.setSpilfilIdentifikation((String) attrs[1]);
            tamperToken.setZipFileName((String) attrs[2]);
            Timestamp ts = (Timestamp) attrs[3];
            tamperToken.setCreated(ts.toLocalDateTime());
        } catch(SQLException ex) {
            if (ex.getSQLState().equals("99999") && ex.getErrorCode() == 25228) {   // No more records in the queue
                return Optional.empty();
            } else {
                throw new ApplicationException("Exception when calling next_tampertoken()", ex);
            }
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return Optional.of(tamperToken);
    }


}
