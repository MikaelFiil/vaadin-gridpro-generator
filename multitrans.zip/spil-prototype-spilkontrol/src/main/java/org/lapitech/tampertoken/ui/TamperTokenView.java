package org.lapitech.tampertoken.ui;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Main;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.select.Select;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Menu;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.theme.lumo.LumoUtility;
import org.lapitech.base.ui.component.ViewToolbar;
import org.lapitech.tampertoken.domain.TamperTokenZipQueue;
import org.lapitech.tampertoken.service.QueueProducerConsumer;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Optional;

@Route("tamper-token")
@PageTitle("Tamper Token")
@Menu(order = 300, icon = "vaadin:clipboard-check", title = "Tamper Token")
public final class TamperTokenView extends Main {

    String[] SPILUDBYDERLIST = {"Lotto", "Hestespil", "Jackpot"};

    private final QueueProducerConsumer queueProducerConsumer;
    private VerticalLayout verticalLayout;
    private Select<String> spilUdbyderNavn;
    private TextField spilfilIdentifikation;
    private TextField zipFileName;
    private Button addTamperTokenBtn;
    private Button clearTamperTokenBtn;
    private TextArea logTextArea;
    private StringBuffer loggedTamperTokens = new StringBuffer();

    private Button getLottoTamperTokenBtn;
    private Button getHestespilTamperTokenBtn;
    private Button getJackpotTamperTokenBtn;
    private TextArea lottoResultTextArea;
    private TextArea hestespilResultTextArea;
    private TextArea jackpotResultTextArea;

    TamperTokenView(QueueProducerConsumer queueProducerConsumer) {
        this.queueProducerConsumer = queueProducerConsumer;
        addClassNames(LumoUtility.Padding.MEDIUM, LumoUtility.Display.FLEX, LumoUtility.FlexDirection.COLUMN,
                LumoUtility.BoxSizing.BORDER);
        setSizeFull();

        add(new ViewToolbar("Tamper Token Queue Demo"));
        initUI();
        buildUX();

        add(verticalLayout);
    }

    private void initUI() {
        verticalLayout = new VerticalLayout();

        spilUdbyderNavn = new Select<>();
        spilUdbyderNavn.setLabel("Select Spiludbyder");
        spilUdbyderNavn.setRequiredIndicatorVisible(true);
        spilUdbyderNavn.setItems(SPILUDBYDERLIST);

        spilfilIdentifikation = new TextField("Spilfil identifikation");
        spilfilIdentifikation.setMaxLength(300);
        zipFileName = new TextField("Zip file name");
        zipFileName.setMaxLength(300);
        addTamperTokenBtn = new Button("Add Tamper Token to Queue");
        clearTamperTokenBtn = new Button("Clear Tamper Token log");
        logTextArea = new TextArea("Logging");
        logTextArea.setWidth("70rem");
        logTextArea.setHeight("15rem");

        getLottoTamperTokenBtn = new Button("Get Lotto Tamper Token from Queue");
        getHestespilTamperTokenBtn = new Button("Get Hestespil Tamper Token from Queue");
        getJackpotTamperTokenBtn = new Button("Get Jackpot Tamper Token from Queue");

        lottoResultTextArea = new TextArea("Lotto result");
        lottoResultTextArea.setWidth("25rem");
        lottoResultTextArea.setHeight("25rem");
        hestespilResultTextArea = new TextArea("Hestespil result");
        hestespilResultTextArea.setWidth("25rem");
        hestespilResultTextArea.setHeight("25rem");
        jackpotResultTextArea = new TextArea("Jackpot result");
        jackpotResultTextArea.setWidth("25rem");
        jackpotResultTextArea.setHeight("25rem");

    }

    private void buildUX() {
        HorizontalLayout horizontalLayout = new HorizontalLayout(spilUdbyderNavn, spilfilIdentifikation, zipFileName, addTamperTokenBtn, clearTamperTokenBtn);
        horizontalLayout.setAlignItems(FlexComponent.Alignment.BASELINE);
        verticalLayout.add(horizontalLayout, logTextArea);

        VerticalLayout lottoVertical = new VerticalLayout();
        VerticalLayout hestespilVertical = new VerticalLayout();
        VerticalLayout jackpotVertical = new VerticalLayout();
        lottoVertical.add(getLottoTamperTokenBtn, lottoResultTextArea);
        hestespilVertical.add(getHestespilTamperTokenBtn, hestespilResultTextArea);
        jackpotVertical.add(getJackpotTamperTokenBtn, jackpotResultTextArea);

        HorizontalLayout horizontalLayoutResults = new HorizontalLayout(lottoVertical, hestespilVertical, jackpotVertical);
        horizontalLayoutResults.setAlignItems(FlexComponent.Alignment.BASELINE);
        verticalLayout.add(horizontalLayoutResults);

        addTamperTokenBtn.addClickListener(_ -> {
            TamperTokenZipQueue tamperTokenZipQueue = new TamperTokenZipQueue();
            tamperTokenZipQueue.setSpilUdbyderNavn(spilUdbyderNavn.getValue());
            tamperTokenZipQueue.setSpilfilIdentifikation(spilfilIdentifikation.getValue());
            tamperTokenZipQueue.setZipFileName(zipFileName.getValue());
            tamperTokenZipQueue.setCreated(LocalDateTime.now());
            try {
                String msgId = queueProducerConsumer.addTamperTokenToQueue(tamperTokenZipQueue);
                loggedTamperTokens
                    .append("MessageID = ")
                    .append(msgId)
                    .append("\n")
                    .append(" - ")
                    .append(tamperTokenZipQueue.getSpilUdbyderNavn())
                    .append(" - ")
                    .append(tamperTokenZipQueue.getSpilfilIdentifikation())
                    .append(" - ")
                    .append(tamperTokenZipQueue.getZipFileName())
                    .append("\n");
                logTextArea.setValue(loggedTamperTokens.toString());
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });

        clearTamperTokenBtn.addClickListener(_ -> {
            loggedTamperTokens = new StringBuffer();
            logTextArea.setValue(loggedTamperTokens.toString());
        });

        getLottoTamperTokenBtn.addClickListener(_ -> {
            try {
                Optional<TamperTokenZipQueue> tamperTokenZipQueueOpt = queueProducerConsumer.getTamperTokenFromQueue(SPILUDBYDERLIST[0]);
                tamperTokenZipQueueOpt.ifPresentOrElse(tamperTokenZipQueue -> lottoResultTextArea.setValue("Message = " + SPILUDBYDERLIST[0]
                    + "\n" + tamperTokenZipQueue.getSpilfilIdentifikation()
                    + "\n" + tamperTokenZipQueue.getZipFileName()
                    + "\n" + tamperTokenZipQueue.getCreated().toString()
                    + "\n -----------------------------------------------"
                    ),
                    () -> {     // else
                        lottoResultTextArea.setValue("No messages found for Spiludbyder = " + SPILUDBYDERLIST[0]);
                    }
                );

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        });

        getHestespilTamperTokenBtn.addClickListener(_ -> {
            try {
                Optional<TamperTokenZipQueue> tamperTokenZipQueueOpt = queueProducerConsumer.getTamperTokenFromQueue(SPILUDBYDERLIST[1]);
                tamperTokenZipQueueOpt.ifPresentOrElse(tamperTokenZipQueue -> hestespilResultTextArea.setValue("Message = " + SPILUDBYDERLIST[1]
                    + "\n" + tamperTokenZipQueue.getSpilfilIdentifikation()
                    + "\n" + tamperTokenZipQueue.getZipFileName()
                    + "\n" + tamperTokenZipQueue.getCreated().toString()
                    + "\n -----------------------------------------------"
                    ),
                    () -> {     // else
                        hestespilResultTextArea.setValue("No messages found for Spiludbyder = " + SPILUDBYDERLIST[1]);
                    }
                );

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        });

        getJackpotTamperTokenBtn.addClickListener(_ -> {
            try {
                Optional<TamperTokenZipQueue> tamperTokenZipQueueOpt = queueProducerConsumer.getTamperTokenFromQueue(SPILUDBYDERLIST[2]);
                tamperTokenZipQueueOpt.ifPresentOrElse(tamperTokenZipQueue -> jackpotResultTextArea.setValue("Message = " + SPILUDBYDERLIST[2]
                    + "\n" + tamperTokenZipQueue.getSpilfilIdentifikation()
                    + "\n" + tamperTokenZipQueue.getZipFileName()
                    + "\n" + tamperTokenZipQueue.getCreated().toString()
                    + "\n -----------------------------------------------"
                    ),
                    () -> {     // else
                        jackpotResultTextArea.setValue("No messages found for Spiludbyder = " + SPILUDBYDERLIST[2]);
                    }
                );

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        });

    }

}