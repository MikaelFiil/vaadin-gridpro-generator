package org.lapitech.transactions.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class XMLFile {

    @EqualsAndHashCode.Include
    @Id
    private Integer id = null;
    private Integer zipFileId = null;
    private String description;
    private Boolean isProcessed = false;
    private Integer gameProcessedCounter = 0;
}
