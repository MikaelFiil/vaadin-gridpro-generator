package org.lapitech.transactions.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.math.BigDecimal;

@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class XMLFileGame {

    @EqualsAndHashCode.Include
    @Id
    private Integer id = null;
    private Integer xmlFileId;
    private String description;
    private Boolean isProcessed;
    private Boolean failByRollback;
    private Boolean failByException;
    private BigDecimal[] years;             // Demonstrating array columns, note that Oracle converts all numbers to BigDecimal
}




