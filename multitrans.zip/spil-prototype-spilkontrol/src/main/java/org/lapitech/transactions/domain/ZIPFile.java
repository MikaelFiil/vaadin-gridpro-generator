package org.lapitech.transactions.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ZIPFile {

    @EqualsAndHashCode.Include
    @Id
    private Integer id = null;
    private String description;
    private Integer counter;

    @Override
    public String toString() {
        return description;
    }
}
