package org.lapitech.transactions.service;

import org.lapitech.transactions.domain.XMLFileGame;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *  Demonstration application with specific transaction management.
 *  This is level 3 of the transaction boundary.
 *  Inside the transaction of the method processXMLFileGameList() is the final level of database updates.
 *  The database only updates existing rows as this is just a demonstration of multiple transaction boundaries, but it
 *  might as well have done complete inserts.
 *
 */

@Repository
public class XMLFileGameRepository {

    private final DataSource dataSource;

    XMLFileGameRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * A new transaction boundary is required here. Commit is automatic when returning normally without exceptions
     * Note that the SQL statements sets an absolute number of processed games, reflecting the variable idx
     * going from counterStart to counterStart + COMMIT_BLOCK_MAX_SIZE.
     *
     * This is basically a template for the multi layer transaction handling.
     *
     * @param gameList                          A list of POJO object with meta info on the XML file games
     * @param counterStart                      An index into the gameList pointing to the next item to process,
     *                                          this information is coming from the level above
     * @param COMMIT_BLOCK_MAX_SIZE             A configurable transaction block size for optimizing performance
     * @return                                  The number of XMLFileGame elements that were processed in this transaction
     * @throws SQLException                     Will fail and rollback, this also happens in case of a RuntimeException
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public Integer processXMLFileGameList(List<XMLFileGame> gameList, Integer counterStart, Integer COMMIT_BLOCK_MAX_SIZE) throws SQLException {
        String sql = "update xml_file_game set is_processed = 1 where id = ?";
        int idx = counterStart;

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sql)) {

            // Handle a number of updates in one transaction up to COMMIT_BLOCK_MAX_SIZE
            for (; idx < gameList.size() && idx < counterStart + COMMIT_BLOCK_MAX_SIZE; idx++) {
                XMLFileGame xmlFileGame = gameList.get(idx);

                ps.setInt(1, xmlFileGame.getId());
                ps.executeUpdate();

                // In case of an error of any kind, throw an exception to rollback current transaction, hence unplanned exceptions have the same effect
                if (xmlFileGame.getFailByException() || xmlFileGame.getFailByRollback()) {
                    throw new RuntimeException("Fail in XMLFileGameRepository");
                }
            }
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return idx;     // Return the number of processed items
    }


    /**
     *
     * @param xmlFileId primary key into xml_file table
     * @return A list of POJO objects with meta info on the XML file games pointing to the given xmlFileId
     */
    @Transactional(readOnly = true)
    public List<XMLFileGame> selectXMLFileGames(Integer xmlFileId)  {
        String sqlSelect = "select id, xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years from xml_file_game where xml_file_id = ? order by id";
        List<XMLFileGame> xmlFileGames = new ArrayList<>();

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sqlSelect)) {
            ps.setInt(1, xmlFileId);

            ResultSet result = ps.executeQuery();
            while (result.next()) {
                XMLFileGame xmlFileGame = new XMLFileGame(result.getInt("id"), result.getInt("xml_file_id"), result.getString("description"),
                        (result.getInt("is_processed") == 0? false : true), (result.getInt("fail_by_rollback") == 0? false : true),
                        (result.getInt("fail_by_exception") == 0? false : true),
                        (BigDecimal[])result.getArray("years").getArray());
                xmlFileGames.add(xmlFileGame);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return xmlFileGames;
    }


}

