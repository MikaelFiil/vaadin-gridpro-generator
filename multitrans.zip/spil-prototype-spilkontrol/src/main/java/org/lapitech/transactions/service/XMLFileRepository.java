package org.lapitech.transactions.service;

import org.lapitech.transactions.domain.XMLFile;
import org.lapitech.transactions.domain.XMLFileGame;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *  Demonstration application with specific transaction management.
 *  This is level 2 of the transaction boundary.
 *  Inside the transaction of the method processXMLFilesList() calls are made to the next level
 *  of handling in the method xmlFileGameRepository.processXMLFileGameList() which also starts a new transaction
 *  when you look at the code.
 *
 */

@Repository
public class XMLFileRepository {

    private final DataSource dataSource;
    private final XMLFileGameRepository xmlFileGameRepository;

    XMLFileRepository(DataSource dataSource, XMLFileGameRepository xmlFileGameRepository) {
        this.dataSource = dataSource;
        this.xmlFileGameRepository = xmlFileGameRepository;
    }

    /**
     * A new transaction boundary is required here. Commit is automatic when returning normally without exceptions
     * Note that the SQL statements sets an absolute number of processed games, reflecting the variable countStart
     * that is initialized with the current number of processed games and transferred ad a parameter to the next
     * level of transactions, which then returns the total number of processed games.
     *
     *
     * @param xmlFile                       A POJO with meta info on the XML file
     * @param COMMIT_BLOCK_MAX_SIZE         A configurable transaction block size for optimizing performance
     * @return                              Returns true if transaction was successful, false or an exception otherwise
     * @throws SQLException                 Will fail and rollback independent of the lower level transaction
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public boolean processXMLFile(XMLFile xmlFile, Integer COMMIT_BLOCK_MAX_SIZE) throws SQLException {
        String sql = "update xml_file set game_processed_counter = ? where id = ?";
        List<XMLFileGame> gameList = xmlFileGameRepository.selectXMLFileGames(xmlFile.getId());

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            int counter = 0;
            Integer counterStart = selectGameCounter(xmlFile.getId());

            while (counter < gameList.size()) {
                try {
                    counter = xmlFileGameRepository.processXMLFileGameList(gameList, counterStart, COMMIT_BLOCK_MAX_SIZE);
                } catch (Exception e) {
                    return false;
                }

                ps.setInt(1, counter);
                ps.setInt(2, xmlFile.getId());
                ps.executeUpdate();

                counterStart = selectGameCounter(xmlFile.getId());
            }
            setXMLFileProcessed(xmlFile);
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return true;
    }


    @Transactional(readOnly = true)
    public List<XMLFile> selectXMLFiles(Integer zipFileId)  {
        String sqlSelect = "select id, zip_file_id, description, is_processed, game_processed_counter from xml_file where zip_file_id = ? order by id";
        List<XMLFile> xmlFiles = new ArrayList<>();

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sqlSelect)) {
            ps.setInt(1, zipFileId);

            ResultSet result = ps.executeQuery();
            while (result.next()) {
                XMLFile xmlFile =
                    new XMLFile(result.getInt("id"), result.getInt("zip_file_id"),
                        result.getString("description"), (result.getInt("is_processed") != 0),
                        result.getInt("game_processed_counter"));
                xmlFiles.add(xmlFile);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return xmlFiles;
    }

    private Integer selectGameCounter(Integer xmlFileId) throws SQLException {
        String sqlSelect = "select game_processed_counter from xml_file where id = ? order by id";

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sqlSelect)) {
            ps.setInt(1, xmlFileId);

            ResultSet result = ps.executeQuery();
            if (result.next()) {
                return result.getInt("game_processed_counter");
            }
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return 0;
    }

    private void setXMLFileProcessed(XMLFile xmlFile) throws SQLException {
        String sql = "update xml_file set is_processed = 1 where id = ?";

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, xmlFile.getId());
            ps.executeUpdate();
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
    }

}

