package org.lapitech.transactions.service;

import org.lapitech.transactions.domain.XMLFile;
import org.lapitech.transactions.domain.ZIPFile;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *  Demonstration application with specific transaction management.
 *  This is the top level transaction boundary.
 *  Inside the transaction of the method updateZIPFileMultiTransCommit() calls are made to the next level
 *  of handling in the method xmlFileRepository.processXMLFile() which also starts a new transaction.
 *  This level keeps track of whether each XML file in the ZIP file was successfully processed by updating a counter
 *  each time the
 */

@Repository
public class ZIPFileRepository {

    private final DataSource dataSource;
    private final XMLFileRepository xmlFileRepository;

    ZIPFileRepository(DataSource dataSource, XMLFileRepository xmlFileRepository) {
        this.dataSource = dataSource;
        this.xmlFileRepository = xmlFileRepository;
    }


    /**
     * Commit is automatic when returning normally without exceptions.
     * Exceptions may be coming up from lower levels of transactions
     *
     * @param zipFileId                 The database ID of the ZIP file
     * @param COMMIT_BLOCK_MAX_SIZE     A configurable transaction block size for optimizing performance
     * @throws SQLException             Will fail and rollback independent of the lower level transaction
     */
    @Transactional
    public void updateZIPFileMultiTransCommit(Integer zipFileId, int COMMIT_BLOCK_MAX_SIZE ) throws SQLException {
        String sql = "update zip_file set counter = counter + 1 where id = ?";
        List<XMLFile> xmlFiles = xmlFileRepository.selectXMLFiles(zipFileId);
        int countStart = selectXMLCounter(zipFileId);
        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, zipFileId);

            for (; countStart < xmlFiles.size(); countStart++) {
                if (!xmlFileRepository.processXMLFile(xmlFiles.get(countStart), COMMIT_BLOCK_MAX_SIZE)) {
                    return;
                }
                ps.executeUpdate();
            }
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
    }

    @Transactional(readOnly = true)
    public List<ZIPFile> selectZIPFiles() throws SQLException {
        String sqlSelect = "select id, description, counter from zip_file order by id";
        List<ZIPFile> zipFiles = new ArrayList<>();

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sqlSelect)) {
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                ZIPFile zipFile = new ZIPFile(result.getInt("id"), result.getString("description"), result.getInt("counter"));
                zipFiles.add(zipFile);
            }
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return zipFiles;
    }
    
    private Integer selectXMLCounter(Integer zipFileId) throws SQLException {
        String sqlSelect = "select counter from zip_file where id = ? order by id";

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sqlSelect)) {
            ps.setInt(1, zipFileId);

            ResultSet result = ps.executeQuery();
            if (result.next()) {
                return result.getInt("counter");
            }
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return 0;
    }


}

