package org.lapitech.transactions.ui;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Main;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.select.Select;
import com.vaadin.flow.component.shared.SelectionPreservationMode;
import com.vaadin.flow.component.textfield.IntegerField;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.router.Menu;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouteAlias;
import com.vaadin.flow.theme.lumo.LumoUtility;
import org.lapitech.base.ui.component.ViewToolbar;
import org.lapitech.transactions.domain.XMLFile;
import org.lapitech.transactions.domain.XMLFileGame;
import org.lapitech.transactions.domain.ZIPFile;
import org.lapitech.transactions.service.XMLFileGameRepository;
import org.lapitech.transactions.service.XMLFileRepository;
import org.lapitech.transactions.service.ZIPFileRepository;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * This view demonstrates how to handle multilevel transactions in a generic way.
 *
 *
 */

@Route("transactions-demo")
@RouteAlias("")
@PageTitle("Basic Transaction Demo")
@Menu(order = 100, icon = "vaadin:clipboard-check", title = "Transaction Demo")
class TransactionControlView extends Main {

    private final ZIPFileRepository zipfileRepository;
    private final XMLFileRepository xmlfIleRepository;
    private final XMLFileGameRepository xmlFileGameRepository;

    // ZIP File fields
    private IntegerField xmlProcessedCounter;
    private Select<ZIPFile> selectZipFile;

    private IntegerField transactionSize;
    private Button processXMLMultiTransCommitBtn;
    private Grid<XMLFile> xmlFileGrid;
    private Grid<XMLFileGame> xmlFileGameGrid;

    private TextArea textArea;

    TransactionControlView(ZIPFileRepository zipfileRepository, XMLFileRepository xmlfIleRepository, XMLFileGameRepository xmlFileGameRepository) {
        this.zipfileRepository = zipfileRepository;
        this.xmlfIleRepository = xmlfIleRepository;
        this.xmlFileGameRepository = xmlFileGameRepository;

        initUI();

        setSizeFull();
        addClassNames(LumoUtility.BoxSizing.BORDER, LumoUtility.Display.FLEX,
            LumoUtility.FlexDirection.COLUMN,
            LumoUtility.Padding.MEDIUM, LumoUtility.Gap.SMALL);

        HorizontalLayout horizontalLayout = new HorizontalLayout(selectZipFile, xmlProcessedCounter, transactionSize, processXMLMultiTransCommitBtn);
        horizontalLayout.setAlignItems(FlexComponent.Alignment.BASELINE);
        add(new ViewToolbar("Transaction Demo", ViewToolbar.group(horizontalLayout)));
        add(xmlFileGrid);
        add(xmlFileGameGrid);
        add(textArea);

        try {
            buildUI();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    private void initUI() {
        selectZipFile = new Select<>();
        selectZipFile.setLabel("Select a simulated ZIP file");
        selectZipFile.setEmptySelectionAllowed(false);
        selectZipFile.setWidth("20rem");

        xmlProcessedCounter = new IntegerField();
        xmlProcessedCounter.setLabel("XML files fully processed");
        xmlProcessedCounter.setValue(0);
        xmlProcessedCounter.setReadOnly(true);

        transactionSize = new IntegerField();
        transactionSize.setLabel("Inserts per commit");
        transactionSize.setValue(1);
        transactionSize.setMin(1);

        xmlFileGrid = new Grid<>(XMLFile.class);
        xmlFileGrid.setWidthFull();
        xmlFileGrid.setHeight("400px");
        xmlFileGrid.addThemeVariants(GridVariant.LUMO_WRAP_CELL_CONTENT);
        xmlFileGrid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT);
        xmlFileGrid.setSelectionPreservationMode(SelectionPreservationMode.PRESERVE_EXISTING);
        xmlFileGrid.setSelectionMode(Grid.SelectionMode.SINGLE);
        xmlFileGrid.removeAllColumns();
        xmlFileGrid.addColumn(XMLFile::getZipFileId)
                .setFlexGrow(1)
                .setResizable(true)
                .setHeader("ZIP File Id");
        xmlFileGrid.addColumn(XMLFile::getDescription)
                .setFlexGrow(1)
                .setResizable(true)
                .setHeader("Description");
        xmlFileGrid.addColumn(XMLFile::getId)
                .setFlexGrow(1)
                .setResizable(true)
                .setHeader("XML File Id");
        xmlFileGrid.addColumn(XMLFile::getIsProcessed)
                .setFlexGrow(1)
                .setResizable(true)
                .setHeader("Is processed");
        xmlFileGrid.addColumn(XMLFile::getGameProcessedCounter)
                .setFlexGrow(1)
                .setResizable(true)
                .setHeader("Games processed counter");

        xmlFileGameGrid = new Grid<>(XMLFileGame.class);
        xmlFileGameGrid.setWidthFull();
        xmlFileGameGrid.setHeight("400px");
        xmlFileGameGrid.addThemeVariants(GridVariant.LUMO_WRAP_CELL_CONTENT);
        xmlFileGameGrid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT);
        xmlFileGameGrid.setSelectionPreservationMode(SelectionPreservationMode.PRESERVE_EXISTING);
        xmlFileGameGrid.setSelectionMode(Grid.SelectionMode.SINGLE);

        xmlFileGameGrid.removeAllColumns();
        xmlFileGameGrid.addColumn(XMLFileGame::getId)
                .setFlexGrow(1)
                .setResizable(true)
                .setHeader("Game Id");
        xmlFileGameGrid.addColumn(XMLFileGame::getDescription)
                .setFlexGrow(1)
                .setResizable(true)
                .setHeader("Description");
        xmlFileGameGrid.addColumn(XMLFileGame::getXmlFileId)
                .setFlexGrow(1)
                .setResizable(true)
                .setHeader("XML File Id");
        xmlFileGameGrid.addColumn(XMLFileGame::getIsProcessed)
                .setFlexGrow(1)
                .setResizable(true)
                .setHeader("Is processed");
        xmlFileGameGrid.addColumn(XMLFileGame::getFailByRollback)
                .setFlexGrow(1)
                .setResizable(true)
                .setHeader("Fail by rollback");
        xmlFileGameGrid.addColumn(XMLFileGame::getFailByException)
                .setFlexGrow(1)
                .setResizable(true)
                .setHeader("Fail by exception");

        textArea = new TextArea("Array content");

        processXMLMultiTransCommitBtn = new Button("Process Multi Trans Commit", _ -> {
            if (transactionSize.isInvalid()) return;

            int COMMIT_BLOCK_MAX_SIZE = transactionSize.getValue();        // Should be tuned for performance from testing
            try {
                ZIPFile zipFile = selectZipFile.getValue();
                if (zipFile != null) {
                    zipfileRepository.updateZIPFileMultiTransCommit(zipFile.getId(), COMMIT_BLOCK_MAX_SIZE);
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            } finally {
                refreshUI();
            }
        });
        processXMLMultiTransCommitBtn.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
    }

    private void updateZipFilesList() throws SQLException {
        List<ZIPFile> zips =zipfileRepository.selectZIPFiles();
        selectZipFile.setItems(zips);
        selectZipFile.setValue(zips.getFirst());
        xmlFileGrid.setItems(xmlfIleRepository.selectXMLFiles(zips.getFirst().getId()));
        xmlFileGameGrid.setItems(new ArrayList<>());
        xmlProcessedCounter.setValue(zips.getFirst().getCounter());
    }

    private void buildUI() throws SQLException {
        updateZipFilesList();
        selectZipFile.addValueChangeListener(event -> {
            if (event.getValue() != null) {
                xmlFileGrid.setItems(xmlfIleRepository.selectXMLFiles(event.getValue().getId()));
                xmlFileGameGrid.setItems(new ArrayList<>());
                xmlProcessedCounter.setValue(event.getValue().getCounter());
            }
        });

        xmlFileGrid.addSelectionListener(evt -> evt.getFirstSelectedItem().ifPresent(
                xmlFile -> xmlFileGameGrid.setItems(xmlFileGameRepository.selectXMLFileGames(xmlFile.getId()))));

        xmlFileGameGrid.addSelectionListener(evt -> evt.getFirstSelectedItem().ifPresent(xmlFileGame -> {
            StringBuilder buf = new StringBuilder();
            textArea.clear();
            textArea.setReadOnly(true);
            for (BigDecimal year : xmlFileGame.getYears()) {
                buf.append(year).append("\n");
            }
            textArea.setValue(buf.toString());
        })) ;

    }

    private void refreshUI() {
        try {
            xmlFileGrid.setItems(xmlfIleRepository.selectXMLFiles(selectZipFile.getValue().getId()));
            xmlFileGrid.getSelectedItems().stream().findFirst().ifPresentOrElse(
                    xmlFile -> xmlFileGameGrid.setItems(xmlFileGameRepository.selectXMLFileGames(xmlFile.getId())), () -> xmlFileGameGrid.setItems(new ArrayList<>()));
            updateZipFilesList();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
