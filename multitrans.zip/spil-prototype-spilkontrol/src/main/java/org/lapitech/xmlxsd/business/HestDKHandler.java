package org.lapitech.xmlxsd.business;

import dk.skat.spilkontrol.business.model.StandardRecord;
import org.lapitech.xmlxsd.domain.XMLFileWrap;
import org.lapitech.xmlxsd.domain.ZIPFileQueue;
import org.lapitech.xmlxsd.service.HestDKTransStdRecordRepository;
import org.lapitech.xmlxsd.service.TalspilTransStdRecordRepository;
import org.springframework.stereotype.Service;

/**
 * This class handles business requirements and validation at the ZIP file (Token) level
 * specifically for the XSD types of HestDKTransaktionStruktur, HestDKStartStruktur and HestDKSlutStruktur
 *
 */

@Service
public class HestDKHandler {

    private final HestDKTransStdRecordRepository hestDKTransStdRecordRepository;

    public HestDKHandler(HestDKTransStdRecordRepository hestDKTransStdRecordRepository) {
        this.hestDKTransStdRecordRepository = hestDKTransStdRecordRepository;
    }

    public boolean handleHestDK(ZIPFileQueue zipFileQueueItem, XMLFileWrap xmlFileWrap, StandardRecord standardRecord) {

        switch (standardRecord.getStructureType()) {

            // FILL IN THE BLANKS, USE MonopolTalspilHandler AS EXAMPLE
            case HestDKTransaktionStruktur:
                hestDKTransStdRecordRepository.processHestDKTransaktionStdRecord();     // TEMPLATE PLACEHOLDER
                break;
            case HestDKStartStruktur:
                break;
            case HestDKSlutStruktur:
                break;

        }

        return false;       // Should never get here
    }



}
