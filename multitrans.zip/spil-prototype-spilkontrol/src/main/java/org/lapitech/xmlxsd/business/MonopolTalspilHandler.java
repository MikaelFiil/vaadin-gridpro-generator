package org.lapitech.xmlxsd.business;

import dk.skat.spilkontrol.business.model.MonopolTalspilTransaktionStandardRecord;
import dk.skat.spilkontrol.business.model.StandardRecord;
import org.lapitech.xmlxsd.domain.XMLFileWrap;
import org.lapitech.xmlxsd.domain.ZIPFileQueue;
import org.lapitech.xmlxsd.domain.monopol.GameProviderXMLFile;
import org.lapitech.xmlxsd.domain.monopol.TalspilTransaktionStdRecord;
import org.lapitech.xmlxsd.service.TalspilTransStdRecordRepository;
import org.springframework.stereotype.Service;

/**
 * This class handles business requirements and validation at the ZIP file (Token) level
 * specifically for the XSD types of MonopolTalspilTransaktionStrukturType, MonopolTalspilStartStrukturType, MonopolTalspilSlutStruktur and MonopolTalspilEndOfGameStruktur
 *
 */

@Service
public class MonopolTalspilHandler {

    private final TalspilTransStdRecordRepository talspilTransStdRecordRepository;

    public MonopolTalspilHandler(TalspilTransStdRecordRepository talspilTransStdRecordRepository) {
        this.talspilTransStdRecordRepository = talspilTransStdRecordRepository;
    }

    public boolean handleMonopolTalspil(ZIPFileQueue zipFileQueueItem, XMLFileWrap xmlFileWrap, StandardRecord standardRecord) {
        switch (standardRecord.getStructureType()) {
            case MonopolTalspilTransaktionStruktur:

                MonopolTalspilTransaktionStandardRecord monopolTalspilTransaktionStandardRecord = (MonopolTalspilTransaktionStandardRecord) standardRecord;
                String spilUdbyder = zipFileQueueItem.getZipFileName().substring(0, zipFileQueueItem.getZipFileName().indexOf("-"));
                GameProviderXMLFile gameProviderXMLFile = new GameProviderXMLFile(zipFileQueueItem.getZipFileName(), xmlFileWrap.getFileName(), spilUdbyder,
                                monopolTalspilTransaktionStandardRecord.getSpilFilIdentifikation(), monopolTalspilTransaktionStandardRecord.getSpilFilErstatningIdentifikation());
                TalspilTransaktionStdRecord talspilTransaktionStdRecord = new TalspilTransaktionStdRecord(spilUdbyder, monopolTalspilTransaktionStandardRecord);

                // Do any extra validation according to business rules here

                // Start processing the XML file
                return talspilTransStdRecordRepository.processTalspilTransaktionStdRecord(monopolTalspilTransaktionStandardRecord,        // Returns false in case of an error
                        spilUdbyder, gameProviderXMLFile, talspilTransaktionStdRecord);


            case MonopolTalspilStartStruktur:
                break;
            case MonopolTalspilSlutStruktur:
                break;
            case MonopolTalspilEndOfGameStruktur:
                break;
        }

        return false;       // Should never get here
    }


}
