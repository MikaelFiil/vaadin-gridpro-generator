package org.lapitech.xmlxsd.business;

import com.vaadin.signals.SignalFactory;
import dk.skat.spilkontrol.business.model.MonopolTalspilTransaktionStandardRecord;
import org.lapitech.base.ui.component.NotficationWrapper;
import org.lapitech.config.SPMValueProvider;
import org.lapitech.errorlogs.domain.ErrorMessage;
import org.lapitech.errorlogs.service.ErrorMessageRepository;
import org.lapitech.exceptions.ApplicationException;
import org.lapitech.xmlxsd.domain.monopol.TalspilSpilKombinationer;
import org.lapitech.xmlxsd.domain.monopol.TalspilSpillerOgKupon;
import org.lapitech.xmlxsd.service.SpilKombinationerRepository;
import org.springframework.stereotype.Service;

import java.sql.SQLException;

/**
 * This class handles business requirements and validation at the XML File and TalspilTransaktionStdRecord
 * specifically for the XSD types of MonopolTalspilTransaktionStrukturType, MonopolTalspilStartStrukturType, MonopolTalspilSlutStruktur and MonopolTalspilEndOfGameStruktur
 *
 */

@Service
public class MonopolTalspilSpillerOgKuponHandler {

    private final SpilKombinationerRepository spilKombinationerRepository;
    private final ErrorMessageRepository errorMessageRepository;

    public MonopolTalspilSpillerOgKuponHandler(SpilKombinationerRepository spilKombinationerRepository, ErrorMessageRepository errorMessageRepository) {
        this.spilKombinationerRepository = spilKombinationerRepository;
        this.errorMessageRepository = errorMessageRepository;
    }

    public boolean handleTalspilSpillerOgKupon (String spilUdbyder,
            MonopolTalspilTransaktionStandardRecord.SpillerOgKuponType spillerOgKupon,
            TalspilSpillerOgKupon talspilSpillerOgKupon) throws SQLException {

        // Abusing Signals for value sharing across stack and component boundaries
        String spillereInformationIdentifikation = SignalFactory.IN_MEMORY_SHARED.value(SPMValueProvider.SPILLER_INFORMATION_IDENTIFICATION, "").value();
        String spilTransaktionIdentifikation = SignalFactory.IN_MEMORY_SHARED.value(SPMValueProvider.SPIL_TRANSAKTION_IDENTIFICATION, "").value();

        // Process all SpilKombinationer
        for (MonopolTalspilTransaktionStandardRecord.SpillerOgKuponType.Spilkombinationer spilkombinationer : spillerOgKupon.getSpilkombinationerListe()) {
            TalspilSpilKombinationer talspilSpilKombinationer =
                new TalspilSpilKombinationer(spilUdbyder, talspilSpillerOgKupon.getSpilFilIdentifikation(), spillerOgKupon.getSpilTransaktionIdentifikation(),
                    spilkombinationer, talspilSpillerOgKupon.getTxNummerIxmlFil());

            // Validate any business rules here

            // Simulate a logical error - TODO NOT to be part of production code !!
            if (spillerOgKupon.getSpillerInformationIdentifikation().equals(spillereInformationIdentifikation) && talspilSpilKombinationer.getSpilTransaktionIdentifikation().equals(spilTransaktionIdentifikation)) {
                String errorMsg = "Validation error in " +
                        "<SpillerInformationIdentifikation>" + spillereInformationIdentifikation + "</SpillerInformationIdentifikation>" +
                        "<SpilTransaktionIdentifikation> " + spilTransaktionIdentifikation + "</SpilTransaktionIdentifikation>";

                ErrorMessage errorMessage = new ErrorMessage();
                errorMessage.setSpilUdbyder(spilUdbyder);
                errorMessage.setSpilfilIdentifikation(talspilSpillerOgKupon.getSpilFilIdentifikation());
                errorMessage.setOriginatingFrom("MonopolTalspilSpillerOgKuponHandler");
                errorMessage.setErrorMessage("Business validation error");
                errorMessage.setErrorMessageLong(errorMsg);
                try {
                    errorMessageRepository.saveErrorMessage(errorMessage);
                } catch (SQLException ex) {
                    throw new ApplicationException("Failed to update error_log", ex);
                }

                NotficationWrapper.errorNotification(errorMsg);
                return false;
            }
            spilKombinationerRepository.saveSpilKombinationer(talspilSpilKombinationer);
        }

        return true;
    }

}
