package org.lapitech.xmlxsd.business;

import dk.skat.spilkontrol.business.model.MonopolTalspilTransaktionStandardRecord;
import org.lapitech.xmlxsd.domain.monopol.TalspilSpillerOgKupon;
import org.lapitech.xmlxsd.service.TalspilSpillerOgKuponRepository;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

/**
 * This class handles business requirements and validation at the XML File and TalspilTransaktionStdRecord
 * specifically for the XSD types of MonopolTalspilTransaktionStrukturType, MonopolTalspilStartStrukturType, MonopolTalspilSlutStruktur and MonopolTalspilEndOfGameStruktur
 *
 */

@Service
public class MonopolTalspilStandardRecHandler {

    private final TalspilSpillerOgKuponRepository talspilSpillerOgKuponRepository;

    public MonopolTalspilStandardRecHandler(TalspilSpillerOgKuponRepository talspilSpillerOgKuponRepository) {
        this.talspilSpillerOgKuponRepository = talspilSpillerOgKuponRepository;
    }

    public boolean handleTalspilStandardRecord(
            Connection con, PreparedStatement ps,
            long kuponCountStart, String spilUdbyder, String spilFilIdentifikation,
            List<MonopolTalspilTransaktionStandardRecord.SpillerOgKuponType> spillerOgKuponListe) throws SQLException {

        for (; kuponCountStart < spillerOgKuponListe.size(); kuponCountStart++) {
            MonopolTalspilTransaktionStandardRecord.SpillerOgKuponType spillerOgKupon =  spillerOgKuponListe.get((int)kuponCountStart);

            // Add one to kuponStart going from Java List index to human-readable position in XML file
            TalspilSpillerOgKupon talspilSpillerOgKupon = new TalspilSpillerOgKupon(spilUdbyder, spilFilIdentifikation, kuponCountStart+1, false, spillerOgKupon);

            if (!talspilSpillerOgKuponRepository.processSpillerOgKupon(spilUdbyder, spillerOgKupon, talspilSpillerOgKupon)) {
                return false;
            }
            ps.executeUpdate();     // Increment counter
            con.commit();
        }
        return true;
    }


}
