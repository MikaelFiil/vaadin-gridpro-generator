package org.lapitech.xmlxsd.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.math.BigDecimal;

@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GameTransaction {

    @EqualsAndHashCode.Include
    @Id
    private Integer id = null;
    private String description;
    private Boolean isProcessed;
}




