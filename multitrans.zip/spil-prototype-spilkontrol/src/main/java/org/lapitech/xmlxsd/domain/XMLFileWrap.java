package org.lapitech.xmlxsd.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.lapitech.xmlxsd.domain.monopol.TalspilTransaktionStdRecord;
import org.springframework.data.annotation.Id;

import java.io.File;

@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class XMLFileWrap {

    @EqualsAndHashCode.Include
    @Id
    public String getFileName() {
        return file.getName();
    }
    public boolean isCompleted() {return (talspilTransaktionStdRecord != null ? talspilTransaktionStdRecord.getTxComplete() : false); };

    private File file;
    private TalspilTransaktionStdRecord talspilTransaktionStdRecord;

    public long getTxSpillerKuponCounter() {
        return (talspilTransaktionStdRecord!= null ? talspilTransaktionStdRecord.getTxSpillerKuponCounter() : 0);
    }

}




