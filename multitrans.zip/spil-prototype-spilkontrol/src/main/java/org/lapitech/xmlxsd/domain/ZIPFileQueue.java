package org.lapitech.xmlxsd.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.io.File;
import java.util.List;

@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ZIPFileQueue {

    @EqualsAndHashCode.Include
    @Id
    private String zipFileName = "";
    private Integer xmlProcessedCounter;
    private boolean complete = false;
    private List<File> files;

    @Override
    public String toString() {
        return zipFileName;
    }
}
