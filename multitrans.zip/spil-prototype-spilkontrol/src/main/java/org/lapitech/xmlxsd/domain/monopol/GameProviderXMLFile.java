package org.lapitech.xmlxsd.domain.monopol;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * CREATE TABLE TALSPIL.STG_XMLFIL
 * (
 *      ZIP_FILE_NAME                       VARCHAR2 (300 CHAR)  NOT NULL ,
 *      XML_FILE_NAME                       VARCHAR2 (300 CHAR)  NOT NULL ,
 *      SPILUDBYDERNAVN                     VARCHAR2(45 CHAR) NOT NULL ENABLE,
 * 	    SPILFILIDENTIFIKATION               VARCHAR2(300 CHAR) NOT NULL ENABLE,
 * 	    SPILFILERSTATNINGIDENTIFIKATION     VARCHAR2(300 CHAR) NOT NULL ENABLE,
 * 	    CONSTRAINT STG_XMLFIL_PK PRIMARY KEY (SPILUDBYDERNAVN, SPILFILIDENTIFIKATION)
 * );
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GameProviderXMLFile {

    private String zipFileName;
    private String xmlFileName;
    private String spilUdbyderNavn;                                 // VARCHAR2(45 CHAR) NOT NULL ENABLE,
    private String spilFilIdentifikation;                           // VARCHAR2(300 CHAR) NOT NULL ENABLE,
    private String spilFilErstatningsIdentifikation;                  // VARCHAR2(300 CHAR) NOT NULL ENABLE,

}
