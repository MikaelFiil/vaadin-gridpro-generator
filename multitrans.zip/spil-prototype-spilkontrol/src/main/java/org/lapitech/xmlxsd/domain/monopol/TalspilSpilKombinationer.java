package org.lapitech.xmlxsd.domain.monopol;

import dk.skat.spilkontrol.business.model.MonopolTalspilTransaktionStandardRecord;
import lombok.Data;

/**
 *
 * CREATE TABLE "TALSPIL"."STG_MONOPOLTAL_SPILKOMBINATIONERLISTE"
 *    (
 *  SPILUDBYDERNAVN                     VARCHAR2(45 CHAR) NOT NULL ENABLE,
 * 	SPILFILIDENTIFIKATION               VARCHAR2(300 CHAR) NOT NULL ENABLE,
 * 	SPILTRANSAKTIONIDENTIFIKATION       VARCHAR2(45 CHAR) NOT NULL ENABLE,
 * 	RAEKKENUMMER                        NUMBER(18,0) NOT NULL ENABLE,
 * 	RAEKKESPILKOMBINATIONER             VARCHAR2(500 CHAR,
 * 	TX_NUMMER_I_XML_FIL                 NUMBER (18)  NOT NULL
 * 	),
 * 	 CONSTRAINT "STG_MONOPOLTALSPIL_SPILKOMBINATIONERLISTE_PK" PRIMARY KEY ("SPILUDBYDERNAVN", "SPILFILIDENTIFIKATION", "SPILTRANSAKTIONIDENTIFIKATION", "RAEKKENUMMER")
 * ;
 *
 */

@Data
public class TalspilSpilKombinationer {

    private String spilUdbyderNavn;                                 // VARCHAR2(45 CHAR) NOT NULL ENABLE,
    private String spilFilIdentifikation;                           // VARCHAR2(300 CHAR) NOT NULL ENABLE,
    private String spilTransaktionIdentifikation;                   // VARCHAR2(45 CHAR) NOT NULL ENABLE,
    private Long raekkeNummer;                                      // NUMBER(18,0) NOT NULL ENABLE,
    private String raekkeSpilKombinationer;                         // VARCHAR2(500 CHAR),
    private Long  txNummerIXMLFil;                                  // NUMBER (18)  NOT NULL


    public TalspilSpilKombinationer(String spilUdbyder, String spilFilIdentifikation, String spilTransaktionIdentifikation,
                                    MonopolTalspilTransaktionStandardRecord.SpillerOgKuponType.Spilkombinationer spilkombinationer, long idx ) {
        this.spilUdbyderNavn = spilUdbyder;
        this.spilFilIdentifikation = spilFilIdentifikation;
        this.spilTransaktionIdentifikation = spilTransaktionIdentifikation;
        this.raekkeNummer = spilkombinationer.getRaekkeNummer();
        this.raekkeSpilKombinationer = spilkombinationer.getRaekkeSpilkombinationer();
        this.txNummerIXMLFil = idx;
    }
}
