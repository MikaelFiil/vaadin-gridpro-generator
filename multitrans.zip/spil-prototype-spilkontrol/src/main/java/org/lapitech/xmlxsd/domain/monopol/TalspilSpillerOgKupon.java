package org.lapitech.xmlxsd.domain.monopol;

import dk.skat.spilkontrol.business.model.MonopolTalspilTransaktionStandardRecord;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.LocalDateTime;


/**
 *
 *
 * CREATE TABLE STG_MONOPOLTALSPIL_SPILLEROGKUPON
 *     (
 *      SPILUDBYDERNAVN                                        VARCHAR2 (45 CHAR)  NOT NULL ,
 *      SPILFILIDENTIFIKATION                                  VARCHAR2 (300 CHAR)  NOT NULL ,
 *      SPILLERINFORMATIONIDENTIFIKATION                       VARCHAR2 (45 CHAR)  NOT NULL ,
 *      SPILTRANSAKTIONIDENTIFIKATION                          VARCHAR2 (45 CHAR)  NOT NULL ,
 *      MONOPOLTALSPILOVERORDNETSPILTRANSAKTIONSIDENTIFIKATION VARCHAR2 (45 CHAR) ,
 *      SPILKOEBDATOTID                                        DATE ,
 *      SPILSALGSKANAL                                         VARCHAR2 (45 CHAR)  NOT NULL ,
 *      SPILANTALRAEKKER                                       NUMBER (18) ,
 *      SPILINDSKUD                                            NUMBER (20,10) ,
 *      SPILINDSKUDSPIL                                        NUMBER (20,10) ,
 *      MONOPOLTALSPILTYPE                                     VARCHAR2 (20 CHAR) ,
 *      MONOPOLTALSPILKENORAEKKEPRIS                           NUMBER (20,10) ,
 *      VALUTAOPLYSNINGKODE                                    VARCHAR2 (3 CHAR)  NOT NULL ,
 *      SPILTERMINALIDENTIFIKATION                             VARCHAR2 (45 CHAR) ,
 *      SPILHJEMMESIDE                                         VARCHAR2 (100 CHAR) ,
 *      SPILANNULLERING                                        NUMBER (1) ,
 *      SPILANNULLERINGDATOTID                                 DATE ,
 *      ANDEL                                                  NUMBER (20,10),
 *      TX_NUMMER_I_XML_FIL                                    NUMBER (18)  NOT NULL,
 *      TX_COMPLETE                                            NUMBER(1) not null            -- NO boolean in Oracle 19*
 *     )
 * ;
 *
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TalspilSpillerOgKupon {
    String spilUdbyderNavn;                                         // VARCHAR2 (45 CHAR)  NOT NULL ,
    String spilFilIdentifikation;                                   // VARCHAR2 (300 CHAR) NOT NULL ,
    String spillerInformationIdentifikation;                        // VARCHAR2 (45 CHAR)  NOT NULL ,
    String spilTransaktionIdentifikation;                           // VARCHAR2 (45 CHAR)  NOT NULL ,
    String monopolTalspilOverordnetSpilTransaktionsIdentifikation;  // VARCHAR2 (45 CHAR) ,
    LocalDateTime spilKoebDatoTid;                                  // DATE ,
    String spilSalgskanal;                                          // VARCHAR2 (45 CHAR) NOT NULL ,
    Long spilAntalRaekker;                                          // NUMBER (18) ,
    Double spilIndskud;                                             // NUMBER (20,10) ,
    Double spilIindskudSpil;                                        // NUMBER (20,10) ,
    String monopolTalspilType;                                      // VARCHAR2 (20 CHAR) ,
    Double monopolTalspilKenoRaekkePris;                            // NUMBER (20,10) ,
    String valutaOplysningsKode;                                    // VARCHAR2 (3 CHAR) NOT NULL ,
    String spilTerminalIdentifikation;                              // VARCHAR2 (45 CHAR) ,
    String spilHjemmeside;                                          // VARCHAR2 (100 CHAR) ,
    Boolean spilAnnulering;                                         // NUMBER (1) ,
    LocalDateTime spilAnnuleringDatoTid;                            // DATE ,
    Double andel;                                                   // NUMBER (20,10)
    Long txNummerIxmlFil;                                           // NUMBER (18)  NOT NULL,
    Boolean txComplete;                                             // NUMBER(1) not null            -- NO boolean in Oracle 19


    public TalspilSpillerOgKupon(String spilUdbyder, String spilFilIdentifikation, Long txNummerIxmlFil, Boolean txComplete,
                                 MonopolTalspilTransaktionStandardRecord.SpillerOgKuponType spillerOgKupon) {
        this.spilUdbyderNavn = spilUdbyder;
        this.spilFilIdentifikation = spilFilIdentifikation;
        this.spillerInformationIdentifikation = (spillerOgKupon.getSpillerInformationIdentifikation() != null ? spillerOgKupon.getSpillerInformationIdentifikation() : "N/A");       // Some XML files have no data in this field
        this.spilTransaktionIdentifikation = spillerOgKupon.getSpilIdentifikation();
        this.monopolTalspilOverordnetSpilTransaktionsIdentifikation = spillerOgKupon.getMonopolOverordnetSpilTransaktionIdentifikation();
        this.spilKoebDatoTid = (spillerOgKupon.getSpilKoebDatoTid() != null) ? spillerOgKupon.getSpilKoebDatoTid().toLocalDateTime() : null;
        this.spilSalgskanal = spillerOgKupon.getSpilSalgskanal();
        this.spilAntalRaekker = spillerOgKupon.getSpilAntalRaekker();
        this.spilIndskud = spillerOgKupon.getSpilIndskud();

        this.spilIindskudSpil = spillerOgKupon.getSpilIndskudSpil();
        this.monopolTalspilType = spillerOgKupon.getTalSpilType();
        this.monopolTalspilKenoRaekkePris = spillerOgKupon.getKenoRaekkePris();
        this.valutaOplysningsKode = spillerOgKupon.getValutaOplysningKode();
        this.spilTerminalIdentifikation = spillerOgKupon.getSpilTerminalidentification();
        this.spilHjemmeside = spillerOgKupon.getSpilHjemmeside();
        this.spilAnnulering = spillerOgKupon.getSpilAnnullering();
        this.spilAnnuleringDatoTid = (spillerOgKupon.getSpilAnnulleringDatoTid() != null ? spillerOgKupon.getSpilAnnulleringDatoTid().toLocalDateTime() : null);
        this.andel = spillerOgKupon.getAndel();
        this.txNummerIxmlFil = txNummerIxmlFil;
        this.txComplete = txComplete;
    }


}
