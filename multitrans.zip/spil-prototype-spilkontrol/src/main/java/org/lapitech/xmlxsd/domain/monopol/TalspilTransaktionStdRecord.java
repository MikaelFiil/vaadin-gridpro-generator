package org.lapitech.xmlxsd.domain.monopol;

import dk.skat.spilkontrol.business.model.MonopolTalspilTransaktionStandardRecord;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 *
 * CREATE TABLE STG_MONOPOLTALSPIL_STDRECORD
 *     (
 *      SPILUDBYDERNAVN                      VARCHAR2 (45 CHAR)  NOT NULL ,
 *      SPILFILIDENTIFIKATION                VARCHAR2 (300 CHAR)  NOT NULL ,
 *      MONOPOLSPILPRODUKTIDENTIFIKATION     VARCHAR2 (100 CHAR)  NOT NULL ,
 *      SPILCERTIFIKATIDENTIFIKATION         VARCHAR2 (45 CHAR) ,
 *      XSDSKEMANAVN                         VARCHAR2 (45 CHAR)  NOT NULL ,
 *      MONOPOLSPILPRODUKTAABENTNETVAERK     NUMBER (1) ,
 *      MONOPOLSPILPRODUKTNUMMER             NUMBER (18) ,
 *      MONOPOLPULJESPILGEVINSTPULJEPROCENT  NUMBER ,
 *      MONOPOLPULJESPILANTALRESULTATPULJER  NUMBER (18) ,
 *      MONOPOLTALSPILANTALTAL               NUMBER (2) ,
 *      MONOPOLTALSPILRAEKKEPRIS             NUMBER (20,10) ,
 *      MONOPOLTALSPILDRAWNUMMER             NUMBER (18) ,
 *      MONOPOLTALSPILUGENUMMER              NUMBER (18) ,
 *      SPILFORVENTETSLUTDATOTID             DATE ,
 *      VALUTAOPLYSNINGKODE                  VARCHAR2 (3 CHAR)  NOT NULL ,
 *      MONOPOLTALSPILENDOFGAMEDATOTID       DATE ,
 *      MONOPOLTALSPILINDSKUDSPILTILLINDH    NUMBER (20,10) ,
 *      MONOPOLTALSPILINDSKUDSPILTOTAL       NUMBER (20,10) ,
 *      MONOPOLTALSPILINDSKUDJACKPOTTILLINDH NUMBER (20,10) ,
 *      MONOPOLTALSPILINDSKUDJACKPOTTOTAL    NUMBER (20,10) ,
 *      MONOPOLTALSPILANTALRAEKKERTILLINDH   NUMBER (18) ,
 *      MONOPOLTALSPILSAMLETANTALRAEKKER     NUMBER (18) ,
 *      MONOPOLTALSPILGEVINSTPULJEBELOEB     NUMBER (20,10) ,
 *      MONOPOLSPILPRODUKTFAKTISKSLUTDATOTID DATE,
 *      MONOPOLSPILPRODUKTNAVN               VARCHAR2(45),
 *      MONOPOLSPILKATEGORINAVN              varchar2(25),
 *      tx_spiller_kupon_counter             NUMBER(18),
 *      tx_complete                          NUMBER(1)             -- NO boolean in Oracle 1
 *     )
 * ;
 *
 */

@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TalspilTransaktionStdRecord {

    @EqualsAndHashCode.Include
    @Id
    String spilUdbyderNavn;                             // VARCHAR2 (45 CHAR)  NOT NULL ,
    @EqualsAndHashCode.Include
    @Id
    String spilFilIdentifikation;                       // VARCHAR2 (300 CHAR)  NOT NULL ,
    String monopolSpilProduktIdentifikation;            // VARCHAR2 (100 CHAR)  NOT NULL ,
    String spilCertifikatIdentifikation;                // VARCHAR2 (45 CHAR) ,
    String xsdSkemaNavn;                                // VARCHAR2 (45 CHAR)  NOT NULL ,
    Long monopolSpilProduktAabentNetvaerk;              // NUMBER (1) ,
    Long monopolSpilProduktNummer;                      // NUMBER (18) ,
    Long monopolPuljeSpilGevinstPuljeProcent;           // NUMBER ,
    Long monopolPuljeSpilAntalResultatPuljer;           // NUMBER (18) ,
    Long monopolTalSpilAntalTal;                        // NUMBER (2) ,
    BigDecimal monopolTalSpilRaekkePris;                // NUMBER (20,10)
    Long monopolTalSpilDrawNummer;                      // NUMBER (18) ,
    Long monopolTalSpilUgeNummer;                       // NUMBER (18) ,
    LocalDate spilForventetSlutDatoTid;                 // DATE ,
    String valutaOplysningKode;                         // VARCHAR2 (3 CHAR)  NOT NULL ,
    LocalDate monopolTalSpilEndOfGameDatoTid;           // DATE ,
    BigDecimal monopolTalSpilIndskudSpilTillIndh;       // NUMBER (20,10) ,
    BigDecimal monopolTalSpilIndskudSpilTotal;          // NUMBER (20,10) ,
    BigDecimal monopolTalSpilIndskudJackpotTillIndh;    // NUMBER (20,10) ,
    BigDecimal monopolTalSpilIndskudJackpotTotal;       // NUMBER (20,10) ,
    Long monopolTalSpilAntalRaekkerTillIndh;            // NUMBER (18) ,
    Long monopolTalSpilSamletAntalRaekker;              // NUMBER (18) ,
    BigDecimal monopolTalSpilGevinstPuljeBeloeb;        // NUMBER (20,10) ,
    LocalDate  monepolSpilProduktFaktiskSlutDatoTid;    // DATE
    String monepolSpilProduktNavn;                      // VARCHAR2 (45 CHAR)  NOT NULL ,
    String monepolSpilKategoriNavn;                     // VARCHAR2 (25 CHAR)  NOT NULL ,
    Long txSpillerKuponCounter = 0L;                    // NUMBER (18) ,
    Boolean txComplete = false;                         // NUMBER(1)             -- NO boolean in Oracle 1


    public TalspilTransaktionStdRecord(String spilUdbyder, MonopolTalspilTransaktionStandardRecord standardRecord) {
        this.spilUdbyderNavn = spilUdbyder;
        this.spilFilIdentifikation = standardRecord.getSpilFilIdentifikation();
        this.monopolSpilProduktIdentifikation = standardRecord.getSpilProduktIdentifikation();
        this.spilCertifikatIdentifikation = standardRecord.getSpilCertifikatIdentifikation();
        this.xsdSkemaNavn = "MonopolTalspilTransaktionStrukturType";
        this.monopolSpilProduktAabentNetvaerk = null;                   // Explicitly not there
        this.monopolSpilProduktNummer = null;                           // Explicitly not there
        this.monopolPuljeSpilGevinstPuljeProcent = null;                // Explicitly not there
        this.monopolPuljeSpilAntalResultatPuljer = null;                // Explicitly not there

        this.monopolTalSpilAntalTal = 0L;
        this.monopolTalSpilRaekkePris = BigDecimal.ZERO;
        this.monopolTalSpilDrawNummer = 0L;
        this.monopolTalSpilUgeNummer = 0L;
        this.spilForventetSlutDatoTid = LocalDate.now();
        this.valutaOplysningKode = "DKK";
        this.monopolTalSpilEndOfGameDatoTid = LocalDate.now();
        this.monopolTalSpilIndskudSpilTillIndh = BigDecimal.ZERO;
        this.monopolTalSpilIndskudSpilTotal = BigDecimal.ZERO;
        this.monopolTalSpilIndskudJackpotTillIndh = BigDecimal.ZERO;
        this.monopolTalSpilIndskudJackpotTotal = BigDecimal.ZERO;
        this.monopolTalSpilAntalRaekkerTillIndh = 0L;
        this.monopolTalSpilSamletAntalRaekker = 0L;
        this.monopolTalSpilGevinstPuljeBeloeb = BigDecimal.ZERO;
        this.monepolSpilProduktFaktiskSlutDatoTid = LocalDate.now();
        this.monepolSpilProduktNavn = standardRecord.getSpilProduktNavn();
        this.monepolSpilKategoriNavn = standardRecord.getSpilKategoriNavn();
        this.txSpillerKuponCounter = 0L;
        this.txComplete = false;
    }



}
