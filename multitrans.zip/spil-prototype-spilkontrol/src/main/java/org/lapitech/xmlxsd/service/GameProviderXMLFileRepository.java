package org.lapitech.xmlxsd.service;

import org.lapitech.xmlxsd.domain.monopol.GameProviderXMLFile;
import org.lapitech.xmlxsd.domain.monopol.TalspilSpilKombinationer;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *  Demonstration application with specific transaction management.
 *
 *
 */

@Repository
public class GameProviderXMLFileRepository {

    private final DataSource dataSource;

    GameProviderXMLFileRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

/*
CREATE TABLE TALSPIL.STG_XMLFIL
   (
        ZIP_FILE_NAME                       VARCHAR2 (300 CHAR)  NOT NULL ,
        XML_FILE_NAME                       VARCHAR2 (300 CHAR)  NOT NULL ,
        SPILUDBYDERNAVN                     VARCHAR2(45 CHAR) NOT NULL ENABLE,
	    SPILFILIDENTIFIKATION               VARCHAR2(300 CHAR) NOT NULL ENABLE,
	    SPILFILERSTATNINGIDENTIFIKATION     VARCHAR2(300 CHAR) NOT NULL ENABLE,
	    CONSTRAINT STG_XMLFIL_PK PRIMARY KEY (SPILUDBYDERNAVN, SPILFILIDENTIFIKATION)
);
  */

    /**
     * Commit is automatic when returning normally without exceptions.
     * Exceptions may be coming up from lower levels of transactions
     *
     * @throws SQLException             Will fail and rollback
     */
    @Transactional
    public void saveGameProviderXMLFile(GameProviderXMLFile gameProviderXMLFile) throws SQLException {

        // ORA-01400: kan ikke indsætte NULL i ("TALSPIL"."STG_XMLFIL"."SPILFILERSTATNINGIDENTIFIKATION")

        String sql = """
            MERGE INTO STG_XMLFIL t
                USING (SELECT ? AS SPILUDBYDERNAVN, ? as SPILFILIDENTIFIKATION, ? AS SPILFILERSTATNINGIDENTIFIKATION FROM dual) s
                ON (t.SPILUDBYDERNAVN = s.SPILUDBYDERNAVN and t.SPILFILIDENTIFIKATION = s.SPILFILIDENTIFIKATION)
            WHEN MATCHED THEN
                UPDATE SET t.SPILFILERSTATNINGIDENTIFIKATION = s.SPILFILERSTATNINGIDENTIFIKATION
            WHEN NOT MATCHED THEN
                insert (
                    ZIP_FILE_NAME,
                    XML_FILE_NAME,
                    SPILUDBYDERNAVN,
                    SPILFILIDENTIFIKATION,
                    SPILFILERSTATNINGIDENTIFIKATION
                )
                values(?, ?, ?, ?, ?)
        """;

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            int idx = 1;
            ps.setString(idx++, gameProviderXMLFile.getSpilUdbyderNavn());
            ps.setString(idx++, gameProviderXMLFile.getSpilFilIdentifikation());
            ps.setString(idx++, gameProviderXMLFile.getSpilFilErstatningsIdentifikation());

            ps.setString(idx++, gameProviderXMLFile.getZipFileName());
            ps.setString(idx++, gameProviderXMLFile.getXmlFileName());
            ps.setString(idx++, gameProviderXMLFile.getSpilUdbyderNavn());
            ps.setString(idx++, gameProviderXMLFile.getSpilFilIdentifikation());
            ps.setString(idx++, gameProviderXMLFile.getSpilFilErstatningsIdentifikation());

            ps.executeUpdate();
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
    }


}

