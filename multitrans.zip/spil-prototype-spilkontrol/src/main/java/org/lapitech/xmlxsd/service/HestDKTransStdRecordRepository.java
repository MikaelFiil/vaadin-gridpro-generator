package org.lapitech.xmlxsd.service;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;

/**
 *  Demonstration application with specific transaction management.
 *  This is the top level transaction boundary.
 *  Inside the transaction of the method processHestDKTransaktionStdRecord()
 *
 */

@Repository
public class HestDKTransStdRecordRepository {

    private final DataSource dataSource;

    HestDKTransStdRecordRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    // EMPTY TEMPLATE PLACEHOLDER
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public boolean processHestDKTransaktionStdRecord() {
        return true;
    }

}

