package org.lapitech.xmlxsd.service;

import org.lapitech.xmlxsd.domain.monopol.TalspilSpilKombinationer;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *  Demonstration application with specific transaction management.
 *  This is the top level transaction boundary.
 *  Inside the transaction of the method saveSpilKombinationer()
 *
 */

@Repository
public class SpilKombinationerRepository {

    private final DataSource dataSource;

    public SpilKombinationerRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

/*
CREATE TABLE STG_MONOPOLTAL_SPILKOMBINATIONERLISTE
    (
     SPILUDBYDERNAVN                VARCHAR2 (45 CHAR)  NOT NULL ,
     SPILFILIDENTIFIKATION          VARCHAR2 (300 CHAR)  NOT NULL ,
     SPILTRANSAKTIONIDENTIFIKATION  VARCHAR2 (45 CHAR)  NOT NULL ,
     RAEKKENUMMER                   NUMBER (18)  NOT NULL ,
     RAEKKESPILKOMBINATIONER        VARCHAR2 (500 CHAR) ,
     TX_NUMMER_I_XML_FIL           NUMBER (18)  NOT NULL
    );
  */

    /**
     * Commit is automatic when returning normally without exceptions.
     * Exceptions may be coming up from lower levels of transactions
     *
     * @throws SQLException             Will fail and rollback
     */
    @Transactional
    public void saveSpilKombinationer(TalspilSpilKombinationer talspilSpilKombinationer) throws SQLException {
        String sql = """
        insert into STG_MONOPOLTAL_SPILKOMBINATIONERLISTE (
            SPILUDBYDERNAVN,
            SPILFILIDENTIFIKATION,
            SPILTRANSAKTIONIDENTIFIKATION,
            RAEKKENUMMER,
            RAEKKESPILKOMBINATIONER,
            TX_NUMMER_I_XML_FIL
        )
        values(?, ?, ?, ?, ?, ?)
        """;

        Connection con = DataSourceUtils.getConnection(dataSource);
        int idx = 1;
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(idx++, talspilSpilKombinationer.getSpilUdbyderNavn());
            ps.setString(idx++, talspilSpilKombinationer.getSpilFilIdentifikation());
            ps.setString(idx++, talspilSpilKombinationer.getSpilTransaktionIdentifikation());
            ps.setLong(idx++, talspilSpilKombinationer.getRaekkeNummer());
            ps.setString(idx++, talspilSpilKombinationer.getRaekkeSpilKombinationer());
            ps.setLong(idx++, talspilSpilKombinationer.getTxNummerIXMLFil());

            ps.executeUpdate();
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
    }


}

