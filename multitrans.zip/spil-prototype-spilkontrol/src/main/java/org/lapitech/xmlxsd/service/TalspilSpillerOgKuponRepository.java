package org.lapitech.xmlxsd.service;

import dk.skat.spilkontrol.business.model.MonopolTalspilTransaktionStandardRecord;
import org.joda.time.LocalDateTime;
import org.lapitech.errorlogs.domain.ErrorMessage;
import org.lapitech.errorlogs.service.ErrorMessageRepository;
import org.lapitech.exceptions.ApplicationException;
import org.lapitech.xmlxsd.business.MonopolTalspilSpillerOgKuponHandler;
import org.lapitech.xmlxsd.domain.monopol.TalspilSpillerOgKupon;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *  Demonstration application with specific transaction management.
 *  This is the lowest level transaction boundary, starting from the method "processSpillerOgKupon"
 *
 */

@Repository
public class TalspilSpillerOgKuponRepository {

    private final DataSource dataSource;
    private final MonopolTalspilSpillerOgKuponHandler monopolTalspilSpillerOgKuponHandler;
    private final ErrorMessageRepository errorMessageRepository;


    TalspilSpillerOgKuponRepository(DataSource dataSource, MonopolTalspilSpillerOgKuponHandler monopolTalspilSpillerOgKuponHandler,
                                    ErrorMessageRepository errorMessageRepository) {
        this.dataSource = dataSource;
        this.monopolTalspilSpillerOgKuponHandler = monopolTalspilSpillerOgKuponHandler;
        this.errorMessageRepository = errorMessageRepository;
    }

    // Minimum level of transaction is one SpillerOgKupon including Spilkombinationer
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public boolean processSpillerOgKupon(String spilUdbyder,
                                         MonopolTalspilTransaktionStandardRecord.SpillerOgKuponType spillerOgKupon,
                                         TalspilSpillerOgKupon talspilSpillerOgKupon) {
        try {
            if (findSpillerOgKupon(talspilSpillerOgKupon.getSpilUdbyderNavn(), talspilSpillerOgKupon.getSpilFilIdentifikation(), talspilSpillerOgKupon.getSpilTransaktionIdentifikation()).isEmpty()) {
                saveTalspilSpillerOgKupon(talspilSpillerOgKupon);   // Save an anchor and keep it updated, pure SQL no validation rules
            }
            if (!processSpillerOgKuponKombinationer(spilUdbyder, spillerOgKupon, talspilSpillerOgKupon)) {
                return false;
            }
        } catch (SQLException e) {
            ErrorMessage errorMessage = new ErrorMessage();
            errorMessage.setSpilUdbyder(spilUdbyder);
            errorMessage.setSpilfilIdentifikation(talspilSpillerOgKupon.getSpilFilIdentifikation());
            errorMessage.setOriginatingFrom("TalspilTransStdRecordRepository");
            errorMessage.setErrorMessage("SQL Exception - " + e.getMessage());
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            errorMessage.setErrorMessageLong(sw.toString());
            try {
                errorMessageRepository.saveErrorMessage(errorMessage);
            } catch (SQLException ex) {
                throw new ApplicationException("Failed in TalspilSpillerOgKuponRepository", e);
            }
            return false;
        }
        return true;
    }

    // Minimum level of transaction is one SpillerOgKupon including Spilkombinationer
    // Returns false in case of any logical error
    private boolean processSpillerOgKuponKombinationer(String spilUdbyder,
                                        MonopolTalspilTransaktionStandardRecord.SpillerOgKuponType spillerOgKupon,
                                        TalspilSpillerOgKupon talspilSpillerOgKupon) {
        String sql = """
                    update TALSPIL.STG_MONOPOLTALSPIL_SPILLEROGKUPON
                    set tx_complete = 1
                    where SPILUDBYDERNAVN = ? and SPILFILIDENTIFIKATION = ? and SPILTRANSAKTIONIDENTIFIKATION = ?
                """;

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sql)) {

            // Process all SpilKombinationer
            if (!monopolTalspilSpillerOgKuponHandler.handleTalspilSpillerOgKupon(spilUdbyder, spillerOgKupon, talspilSpillerOgKupon)) {
                return false;
            }

            ps.setString(1, spilUdbyder);
            ps.setString(2, talspilSpillerOgKupon.getSpilFilIdentifikation());
            ps.setString(3, spillerOgKupon.getSpilTransaktionIdentifikation());

            ps.executeUpdate();         // All SpilKombinationer have been processed and saved, so set complete = true
        } catch (SQLException e) {
            ErrorMessage errorMessage = new ErrorMessage();
            errorMessage.setSpilUdbyder(spilUdbyder);
            errorMessage.setSpilfilIdentifikation(talspilSpillerOgKupon.getSpilFilIdentifikation());
            errorMessage.setOriginatingFrom("TalspilTransStdRecordRepository");
            errorMessage.setErrorMessage("SQL Exception - " + e.getMessage());
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            errorMessage.setErrorMessageLong(sw.toString());
            try {
                errorMessageRepository.saveErrorMessage(errorMessage);
            } catch (SQLException ex) {
                throw new ApplicationException("Failed to update error_log", e);
            }
            throw new ApplicationException("Failed to update STG_MONOPOLTALSPIL_SPILLEROGKUPON", e);
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return true;
    }



/*
    CREATE TABLE STG_MONOPOLTALSPIL_SPILLEROGKUPON (
        SPILUDBYDERNAVN                                        VARCHAR2 (45 CHAR)  NOT NULL ,
        SPILFILIDENTIFIKATION                                  VARCHAR2 (300 CHAR)  NOT NULL ,
        SPILLERINFORMATIONIDENTIFIKATION                       VARCHAR2 (45 CHAR)  NOT NULL ,
        SPILTRANSAKTIONIDENTIFIKATION                          VARCHAR2 (45 CHAR)  NOT NULL ,
        MONOPOLTALSPILOVERORDNETSPILTRANSAKTIONSIDENTIFIKATION VARCHAR2 (45 CHAR) ,
        SPILKOEBDATOTID                                        DATE ,
        SPILSALGSKANAL                                         VARCHAR2 (45 CHAR)  NOT NULL ,
        SPILANTALRAEKKER                                       NUMBER (18) ,
        SPILINDSKUD                                            NUMBER (20,10) ,
        SPILINDSKUDSPIL                                        NUMBER (20,10) ,
        MONOPOLTALSPILTYPE                                     VARCHAR2 (20 CHAR) ,
        MONOPOLTALSPILKENORAEKKEPRIS                           NUMBER (20,10) ,
        VALUTAOPLYSNINGKODE                                    VARCHAR2 (3 CHAR)  NOT NULL ,
        SPILTERMINALIDENTIFIKATION                             VARCHAR2 (45 CHAR) ,
        SPILHJEMMESIDE                                         VARCHAR2 (100 CHAR) ,
        SPILANNULLERING                                        NUMBER (1) ,
        SPILANNULLERINGDATOTID                                 DATE ,
        ANDEL                                                  NUMBER (20,10),
        TX_NUMMER_I_XML_FIL                                    NUMBER (18) not null,
        TX_COMPLETE                                            NUMBER(1) not null            -- NO boolean in Oracle 19
    )
  */

    /**
     * Commit is automatic when returning normally without exceptions.
     * Exceptions may be coming up from lower levels of transactions
     *
     * @throws SQLException Will fail and rollback
     */
    private void saveTalspilSpillerOgKupon(TalspilSpillerOgKupon talspilSpillerOgKupon) throws SQLException {
        String sql = """
            insert into TALSPIL.STG_MONOPOLTALSPIL_SPILLEROGKUPON (
                SPILUDBYDERNAVN,
                SPILFILIDENTIFIKATION,
                SPILLERINFORMATIONIDENTIFIKATION,
                SPILTRANSAKTIONIDENTIFIKATION,
                MONOPOLTALSPILOVERORDNETSPILTRANSAKTIONSIDENTIFIKATION,
            
                SPILKOEBDATOTID,
                SPILSALGSKANAL,
                SPILANTALRAEKKER,
                SPILINDSKUD,
                SPILINDSKUDSPIL,
            
                MONOPOLTALSPILTYPE,
                MONOPOLTALSPILKENORAEKKEPRIS,
                VALUTAOPLYSNINGKODE,
                SPILTERMINALIDENTIFIKATION,
                SPILHJEMMESIDE,
            
                SPILANNULLERING,
                SPILANNULLERINGDATOTID,
                ANDEL,
                TX_NUMMER_I_XML_FIL,
                TX_COMPLETE
            )
            values(?, ?, ?, ?, ?,  ?, ?, ?, ?, ?,  ?, ?, ?, ?, ?,  ?, ?, ?, ?, ?)
            """;

        Connection con = DataSourceUtils.getConnection(dataSource);
        int idx = 1;
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(idx++, talspilSpillerOgKupon.getSpilUdbyderNavn());
            ps.setString(idx++, talspilSpillerOgKupon.getSpilFilIdentifikation());
            ps.setString(idx++, talspilSpillerOgKupon.getSpillerInformationIdentifikation());
            ps.setString(idx++, talspilSpillerOgKupon.getSpilTransaktionIdentifikation());
            ps.setString(idx++, talspilSpillerOgKupon.getMonopolTalspilOverordnetSpilTransaktionsIdentifikation());

            ps.setDate(idx++, new java.sql.Date(talspilSpillerOgKupon.getSpilKoebDatoTid().toDateTime().getMillis()));
            ps.setString(idx++, talspilSpillerOgKupon.getSpilSalgskanal());
            ps.setLong(idx++, talspilSpillerOgKupon.getSpilAntalRaekker());
            ps.setDouble(idx++, talspilSpillerOgKupon.getSpilIndskud());
            ps.setDouble(idx++, talspilSpillerOgKupon.getSpilIindskudSpil());

            ps.setString(idx++, talspilSpillerOgKupon.getMonopolTalspilType());
            if (talspilSpillerOgKupon.getMonopolTalspilKenoRaekkePris() != null) {
                ps.setDouble(idx++, talspilSpillerOgKupon.getMonopolTalspilKenoRaekkePris());
            } else {
                ps.setNull(idx++, Types.DOUBLE);
            }
            ps.setString(idx++, talspilSpillerOgKupon.getValutaOplysningsKode());
            ps.setString(idx++, talspilSpillerOgKupon.getSpilTerminalIdentifikation());
            ps.setString(idx++, talspilSpillerOgKupon.getValutaOplysningsKode());

            if (talspilSpillerOgKupon.getSpilAnnulering() != null) {
                ps.setInt(idx++, (talspilSpillerOgKupon.getSpilAnnulering() ? 1 : 0));     // Oracle 19 has no boolean, using number(1) in stead
            } else {
                ps.setNull(idx++, Types.INTEGER);
            }
            if (talspilSpillerOgKupon.getSpilAnnuleringDatoTid() != null) {
                ps.setDate(idx++, new java.sql.Date(talspilSpillerOgKupon.getSpilAnnuleringDatoTid().toDateTime().getMillis()));
            } else {
                ps.setNull(idx++, Types.DATE);
            }
            if (talspilSpillerOgKupon.getAndel() != null) {
                ps.setDouble(idx++, talspilSpillerOgKupon.getAndel());
            } else {
                ps.setNull(idx++, Types.DOUBLE);
            }
            ps.setLong(idx++, (talspilSpillerOgKupon.getTxNummerIxmlFil() != null ? talspilSpillerOgKupon.getTxNummerIxmlFil() : -1));
            ps.setLong(idx++, (talspilSpillerOgKupon.getTxComplete() ? 1 : 0));

            ps.executeUpdate();
        } finally {
            // System.out.println("TalspilSpillerOgKuponRepository - saveTalspilSpillerOgKupon() finally");
            DataSourceUtils.releaseConnection(con, dataSource);
        }
    }

    @Transactional(readOnly = true)
    public List<TalspilSpillerOgKupon> findSpillerOgKupon(String SPILUDBYDERNAVN, String SPILFILIDENTIFIKATION, String SPILTRANSAKTIONSIDENTIFIKATION) {
        String sql = """
                select * from TALSPIL.STG_MONOPOLTALSPIL_SPILLEROGKUPON
                where SPILUDBYDERNAVN = ? and SPILFILIDENTIFIKATION = ? and SPILTRANSAKTIONIDENTIFIKATION = ?
                """;
        List<TalspilSpillerOgKupon> talspilSpillerOgKuponListe = new ArrayList<>();

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, SPILUDBYDERNAVN);
            ps.setString(2, SPILFILIDENTIFIKATION);
            ps.setString(3, SPILTRANSAKTIONSIDENTIFIKATION);

            ResultSet result = ps.executeQuery();
            while (result.next()) {
                TalspilSpillerOgKupon talspilSpillerOgKupon = new TalspilSpillerOgKupon(
                    result.getString("SPILUDBYDERNAVN"),
                    result.getString("SPILFILIDENTIFIKATION"),
                    result.getString("SPILLERINFORMATIONIDENTIFIKATION"),
                    result.getString("SPILTRANSAKTIONIDENTIFIKATION"),
                    result.getString("MONOPOLTALSPILOVERORDNETSPILTRANSAKTIONSIDENTIFIKATION"),
                    (result.getTimestamp("SPILKOEBDATOTID") != null ? new LocalDateTime(result.getTimestamp("SPILKOEBDATOTID").getTime()) : null),
                    result.getString("SPILSALGSKANAL"),
                    result.getLong("SPILANTALRAEKKER"),
                    result.getDouble("SPILINDSKUD"),
                    result.getDouble("SPILINDSKUDSPIL"),
                    result.getString("MONOPOLTALSPILTYPE"),
                    result.getDouble("MONOPOLTALSPILKENORAEKKEPRIS"),
                    result.getString("VALUTAOPLYSNINGKODE"),
                    result.getString("SPILTERMINALIDENTIFIKATION"),
                    result.getString("SPILHJEMMESIDE"),
                    result.getBoolean("SPILANNULLERING"),
                    (result.getTimestamp("SPILANNULLERINGDATOTID") != null ? new LocalDateTime(result.getTimestamp("SPILANNULLERINGDATOTID").getTime()) : null),
                    result.getDouble("ANDEL"),
                    result.getLong("tx_nummer_i_xml_fil"),
                    (result.getLong("tx_complete") != 0)
                );
                talspilSpillerOgKuponListe.add(talspilSpillerOgKupon);
            }

        } catch (SQLException e) {
            throw new ApplicationException("Failed to read STG_MONOPOLTALSPIL_SPILLEROGKUPON", e);
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return talspilSpillerOgKuponListe;
    }

    @Transactional(readOnly = true)
    public List<TalspilSpillerOgKupon> listSpillerOgKuponPerXML(String SPILUDBYDERNAVN, String SPILFILIDENTIFIKATION) {
        String sql = """
                select * from TALSPIL.STG_MONOPOLTALSPIL_SPILLEROGKUPON
                where SPILUDBYDERNAVN = ? and SPILFILIDENTIFIKATION = ?
                """;
        List<TalspilSpillerOgKupon> talspilSpillerOgKuponListe = new ArrayList<>();

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, SPILUDBYDERNAVN);
            ps.setString(2, SPILFILIDENTIFIKATION);

            ResultSet result = ps.executeQuery();
            while (result.next()) {
                TalspilSpillerOgKupon talspilSpillerOgKupon = new TalspilSpillerOgKupon(
                    result.getString("SPILUDBYDERNAVN"),
                    result.getString("SPILFILIDENTIFIKATION"),
                    result.getString("SPILLERINFORMATIONIDENTIFIKATION"),
                    result.getString("SPILTRANSAKTIONIDENTIFIKATION"),
                    result.getString("MONOPOLTALSPILOVERORDNETSPILTRANSAKTIONSIDENTIFIKATION"),
                    (result.getTimestamp("SPILKOEBDATOTID") != null ? new LocalDateTime(result.getTimestamp("SPILKOEBDATOTID").getTime()) : null),
                    result.getString("SPILSALGSKANAL"),
                    result.getLong("SPILANTALRAEKKER"),
                    result.getDouble("SPILINDSKUD"),
                    result.getDouble("SPILINDSKUDSPIL"),
                    result.getString("MONOPOLTALSPILTYPE"),
                    result.getDouble("MONOPOLTALSPILKENORAEKKEPRIS"),
                    result.getString("VALUTAOPLYSNINGKODE"),
                    result.getString("SPILTERMINALIDENTIFIKATION"),
                    result.getString("SPILHJEMMESIDE"),
                    result.getBoolean("SPILANNULLERING"),
                    (result.getTimestamp("SPILANNULLERINGDATOTID") != null ? new LocalDateTime(result.getTimestamp("SPILANNULLERINGDATOTID").getTime()) : null),
                    result.getDouble("ANDEL"),
                    result.getLong("tx_nummer_i_xml_fil"),
                    (result.getLong("tx_complete") != 0)
                );
                talspilSpillerOgKuponListe.add(talspilSpillerOgKupon);
            }

        } catch (SQLException e) {
            throw new ApplicationException("Failed to read STG_MONOPOLTALSPIL_SPILLEROGKUPON", e);
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return talspilSpillerOgKuponListe;
    }

}

