package org.lapitech.xmlxsd.service;

import dk.skat.spilkontrol.business.model.MonopolTalspilTransaktionStandardRecord;
import org.lapitech.errorlogs.domain.ErrorMessage;
import org.lapitech.errorlogs.service.ErrorMessageRepository;
import org.lapitech.exceptions.ApplicationException;
import org.lapitech.xmlxsd.business.MonopolTalspilStandardRecHandler;
import org.lapitech.xmlxsd.domain.monopol.GameProviderXMLFile;
import org.lapitech.xmlxsd.domain.monopol.TalspilTransaktionStdRecord;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.*;
import java.util.List;

/**
 *  Demonstration application with specific transaction management.
 *  This is the top level transaction boundary.
 *  Inside the transaction of the method processTalspilTransaktionStdRecord()
 *
 */

@Repository
public class TalspilTransStdRecordRepository {

    private final DataSource dataSource;
    private final MonopolTalspilStandardRecHandler monopolTalspilStandardRecHandler;
    private final GameProviderXMLFileRepository gameProviderXMLFileRepository;
    private final ErrorMessageRepository errorMessageRepository;


    TalspilTransStdRecordRepository(DataSource dataSource,
                                    MonopolTalspilStandardRecHandler monopolTalspilStandardRecHandler,
                                    GameProviderXMLFileRepository gameProviderXMLFileRepository,
                                    ErrorMessageRepository errorMessageRepository) {
        this.dataSource = dataSource;
        this.monopolTalspilStandardRecHandler = monopolTalspilStandardRecHandler;
        this.gameProviderXMLFileRepository = gameProviderXMLFileRepository;
        this.errorMessageRepository = errorMessageRepository;
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public boolean processTalspilTransaktionStdRecord(MonopolTalspilTransaktionStandardRecord monopolTalspilTransaktionStandardRecord,
                                                      String spilUdbyder, GameProviderXMLFile gameProviderXMLFile,
                                                      TalspilTransaktionStdRecord talspilTransaktionStdRecord) {
        try {
             gameProviderXMLFileRepository.saveGameProviderXMLFile(gameProviderXMLFile);         // Merge into table
             if (findTalspilTransaktionStdRecordFromZipXml(gameProviderXMLFile.getZipFileName(), gameProviderXMLFile.getXmlFileName()) == null) {
                 saveTalspilStdRecord(talspilTransaktionStdRecord);                             // Insert into STG_MONOPOLTALSPIL_STDRECORD
             }
            if (!updateTalspilTransaktionStdRecordCounter(spilUdbyder, gameProviderXMLFile.getSpilFilIdentifikation(),
                    talspilTransaktionStdRecord, monopolTalspilTransaktionStandardRecord.getSpillerOgKuponListe())) {
                return false;
            }
        } catch(SQLException e) {
            ErrorMessage errorMessage = new ErrorMessage();
            errorMessage.setSpilUdbyder(spilUdbyder);
            errorMessage.setSpilfilIdentifikation(gameProviderXMLFile.getSpilFilIdentifikation());
            errorMessage.setOriginatingFrom("TalspilTransStdRecordRepository");
            errorMessage.setErrorMessage("SQL Exception - " + e.getMessage());
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            errorMessage.setErrorMessageLong(sw.toString());
            try {
                errorMessageRepository.saveErrorMessage(errorMessage);
            } catch (SQLException ex) {
                throw new ApplicationException("Failed in TalspilTransStdRecordRepository", e);
            }
            return false;
        }
        return true;
    }

    private boolean updateTalspilTransaktionStdRecordCounter(String spilUdbyder, String spilFilIdentifikation,
                                                      TalspilTransaktionStdRecord xmltalspilTransaktionStdRecordFile,
                                                      List<MonopolTalspilTransaktionStandardRecord.SpillerOgKuponType> spillerOgKuponListe) {

        String sql = "update STG_MONOPOLTALSPIL_STDRECORD set tx_spiller_kupon_counter = tx_spiller_kupon_counter + 1 where SPILUDBYDERNAVN = ? and spilFilIdentifikation = ?";
        Connection con = DataSourceUtils.getConnection(dataSource);

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            // 0 based as it is used for an index into the List<> structure
            long kuponCountStart = selectKuponCounter(xmltalspilTransaktionStdRecordFile.getSpilUdbyderNavn(), xmltalspilTransaktionStdRecordFile.getSpilFilIdentifikation()).intValue();

            ps.setString(1, spilUdbyder);
            ps.setString(2, spilFilIdentifikation);

            // Handle business logic
            if (!monopolTalspilStandardRecHandler.handleTalspilStandardRecord(con ,ps, kuponCountStart, spilUdbyder, spilFilIdentifikation, spillerOgKuponListe)) {
                return false;
            }

            updateIsCompleted(spilUdbyder, spilFilIdentifikation);
        }  catch(SQLException e) {
            ErrorMessage errorMessage = new ErrorMessage();
            errorMessage.setSpilUdbyder(spilUdbyder);
            errorMessage.setSpilfilIdentifikation(xmltalspilTransaktionStdRecordFile.getSpilFilIdentifikation());
            errorMessage.setOriginatingFrom("TalspilTransStdRecordRepository");
            errorMessage.setErrorMessage("SQL Exception - " + e.getMessage());
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            errorMessage.setErrorMessageLong(sw.toString());
            try {
                errorMessageRepository.saveErrorMessage(errorMessage);
            } catch (SQLException ex) {
                throw new ApplicationException("Failed to update STG_MONOPOLTALSPIL_STDRECORD", e);
            }
            return false;
        }finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return true;
    }

    private void updateIsCompleted(String spilUdbyder, String spilFilIdentifikation) {
        String sql = "update STG_MONOPOLTALSPIL_STDRECORD set tx_complete = ? where SPILUDBYDERNAVN = ? and spilFilIdentifikation = ?";
        Connection con = DataSourceUtils.getConnection(dataSource);

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, 1);
            ps.setString(2, spilUdbyder);
            ps.setString(3, spilFilIdentifikation);
            ps.executeUpdate();     // Increment counter
        } catch (SQLException e) {
            ErrorMessage errorMessage = new ErrorMessage();
            errorMessage.setSpilUdbyder(spilUdbyder);
            errorMessage.setSpilfilIdentifikation(spilFilIdentifikation);
            errorMessage.setOriginatingFrom("TalspilTransStdRecordRepository");
            errorMessage.setErrorMessage("SQL Exception - " + e.getMessage());
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            errorMessage.setErrorMessageLong(sw.toString());
            try {
                errorMessageRepository.saveErrorMessage(errorMessage);
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
            throw new ApplicationException("Failed to update STG_MONOPOLTALSPIL_STDRECORD", e);
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
    }

        /**
         * Commit is automatic when returning normally without exceptions.
         * Exceptions may be coming up from lower levels of transactions
         *
         * @throws SQLException             Will fail and rollback
         */
    private void saveTalspilStdRecord(TalspilTransaktionStdRecord talspilTransaktionStdRecord) throws SQLException {
        String sql = """
        insert into STG_MONOPOLTALSPIL_STDRECORD (
            SPILUDBYDERNAVN,
            SPILFILIDENTIFIKATION,
            MONOPOLSPILPRODUKTIDENTIFIKATION,
            SPILCERTIFIKATIDENTIFIKATION,
            XSDSKEMANAVN,
    
            MONOPOLSPILPRODUKTAABENTNETVAERK,
            MONOPOLSPILPRODUKTNUMMER,
            MONOPOLPULJESPILGEVINSTPULJEPROCENT,
            MONOPOLPULJESPILANTALRESULTATPULJER,
            MONOPOLTALSPILANTALTAL,

            MONOPOLTALSPILRAEKKEPRIS,
            MONOPOLTALSPILDRAWNUMMER,
            MONOPOLTALSPILUGENUMMER,
            SPILFORVENTETSLUTDATOTID,
            VALUTAOPLYSNINGKODE,

            MONOPOLTALSPILENDOFGAMEDATOTID,
            MONOPOLTALSPILINDSKUDSPILTILLINDH,
            MONOPOLTALSPILINDSKUDSPILTOTAL,
            MONOPOLTALSPILINDSKUDJACKPOTTILLINDH,
            MONOPOLTALSPILINDSKUDJACKPOTTOTAL,

            MONOPOLTALSPILANTALRAEKKERTILLINDH,
            MONOPOLTALSPILSAMLETANTALRAEKKER,
            MONOPOLTALSPILGEVINSTPULJEBELOEB,
            MONOPOLSPILPRODUKTFAKTISKSLUTDATOTID,
            MONOPOLSPILPRODUKTNAVN,

            MONOPOLSPILKATEGORINAVN,
            tx_spiller_kupon_counter,
            tx_complete)
        values(?, ?, ?, ?, ?,  ?, ?, ?, ?, ?,  ?, ?, ?, ?, ?,  ?, ?, ?, ?, ?,  ?, ?, ?, ?, ?,  ?, ?, ?)
        """;

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            int idx = 1;
            ps.setString(idx++, talspilTransaktionStdRecord.getSpilUdbyderNavn());
            ps.setString(idx++, talspilTransaktionStdRecord.getSpilFilIdentifikation());
            ps.setString(idx++, talspilTransaktionStdRecord.getMonopolSpilProduktIdentifikation());
            ps.setString(idx++, talspilTransaktionStdRecord.getSpilCertifikatIdentifikation());
            ps.setString(idx++, talspilTransaktionStdRecord.getXsdSkemaNavn());
            ps.setLong(idx++, (talspilTransaktionStdRecord.getMonopolSpilProduktAabentNetvaerk() != null ? talspilTransaktionStdRecord.getMonopolSpilProduktAabentNetvaerk() : 0) );
            ps.setLong(idx++, (talspilTransaktionStdRecord.getMonopolSpilProduktNummer() != null ? talspilTransaktionStdRecord.getMonopolSpilProduktNummer() : 0) );
            ps.setLong(idx++, (talspilTransaktionStdRecord.getMonopolPuljeSpilGevinstPuljeProcent() != null ? talspilTransaktionStdRecord.getMonopolPuljeSpilGevinstPuljeProcent() : 0) );
            ps.setLong(idx++, (talspilTransaktionStdRecord.getMonopolPuljeSpilAntalResultatPuljer() != null ? talspilTransaktionStdRecord.getMonopolPuljeSpilAntalResultatPuljer() : 0) );
            ps.setLong(idx++, talspilTransaktionStdRecord.getMonopolTalSpilAntalTal());
            ps.setBigDecimal(idx++, talspilTransaktionStdRecord.getMonopolTalSpilRaekkePris());
            ps.setLong(idx++, talspilTransaktionStdRecord.getMonopolTalSpilDrawNummer());
            ps.setLong(idx++, talspilTransaktionStdRecord.getMonopolTalSpilUgeNummer());
            ps.setDate(idx++, Date.valueOf(talspilTransaktionStdRecord.getSpilForventetSlutDatoTid()));
            ps.setString(idx++, talspilTransaktionStdRecord.getValutaOplysningKode());
            ps.setDate(idx++, Date.valueOf(talspilTransaktionStdRecord.getMonopolTalSpilEndOfGameDatoTid()));
            ps.setBigDecimal(idx++, talspilTransaktionStdRecord.getMonopolTalSpilIndskudSpilTillIndh());
            ps.setBigDecimal(idx++, talspilTransaktionStdRecord.getMonopolTalSpilIndskudSpilTotal());
            ps.setBigDecimal(idx++, talspilTransaktionStdRecord.getMonopolTalSpilIndskudJackpotTillIndh());
            ps.setBigDecimal(idx++, talspilTransaktionStdRecord.getMonopolTalSpilIndskudJackpotTotal());
            ps.setLong(idx++, talspilTransaktionStdRecord.getMonopolTalSpilAntalRaekkerTillIndh());
            ps.setLong(idx++, talspilTransaktionStdRecord.getMonopolTalSpilSamletAntalRaekker());
            ps.setBigDecimal(idx++, talspilTransaktionStdRecord.getMonopolTalSpilGevinstPuljeBeloeb());
            ps.setDate(idx++, Date.valueOf(talspilTransaktionStdRecord.getMonepolSpilProduktFaktiskSlutDatoTid()));
            ps.setString(idx++, talspilTransaktionStdRecord.getMonepolSpilProduktNavn());
            ps.setString(idx++, talspilTransaktionStdRecord.getMonepolSpilKategoriNavn());
            ps.setLong(idx++, talspilTransaktionStdRecord.getTxSpillerKuponCounter());
            ps.setLong(idx++, (talspilTransaktionStdRecord.getTxComplete() ? 1 : 0));
            ps.executeUpdate();
            con.commit();
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
    }

    @Transactional(readOnly = true)
    public TalspilTransaktionStdRecord findTalspilTransaktionStdRecordFromZipXml(String zipFileName, String xmlFileNane) {
        String sqlSelect = """
        select
            sms.SPILUDBYDERNAVN,
            sms.SPILFILIDENTIFIKATION,
            MONOPOLSPILPRODUKTIDENTIFIKATION,
            SPILCERTIFIKATIDENTIFIKATION,
            XSDSKEMANAVN,
            MONOPOLSPILPRODUKTAABENTNETVAERK,
            MONOPOLSPILPRODUKTNUMMER,
            MONOPOLPULJESPILGEVINSTPULJEPROCENT,
            MONOPOLPULJESPILANTALRESULTATPULJER,
            MONOPOLTALSPILANTALTAL,
            MONOPOLTALSPILRAEKKEPRIS,
            MONOPOLTALSPILDRAWNUMMER,
            MONOPOLTALSPILUGENUMMER,
            SPILFORVENTETSLUTDATOTID,
            VALUTAOPLYSNINGKODE,
            MONOPOLTALSPILENDOFGAMEDATOTID,
            MONOPOLTALSPILINDSKUDSPILTILLINDH,
            MONOPOLTALSPILINDSKUDSPILTOTAL,
            MONOPOLTALSPILINDSKUDJACKPOTTILLINDH,
            MONOPOLTALSPILINDSKUDJACKPOTTOTAL,
            MONOPOLTALSPILANTALRAEKKERTILLINDH,
            MONOPOLTALSPILSAMLETANTALRAEKKER,
            MONOPOLTALSPILGEVINSTPULJEBELOEB,
            MONOPOLSPILPRODUKTFAKTISKSLUTDATOTID,
            MONOPOLSPILPRODUKTNAVN,
            MONOPOLSPILKATEGORINAVN,
            TX_SPILLER_KUPON_COUNTER,
            TX_COMPLETE
        from STG_MONOPOLTALSPIL_STDRECORD sms
        join STG_XMLFIL sx on sms.SPILUDBYDERNAVN = sx.SPILUDBYDERNAVN and sms.SPILFILIDENTIFIKATION = sx.SPILFILIDENTIFIKATION
        where sx.ZIP_FILE_NAME = ? and sx.XML_FILE_NAME = ?
        """;

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sqlSelect)) {
            ps.setString(1, zipFileName);
            ps.setString(2, xmlFileNane);

            ResultSet result = ps.executeQuery();
            if (result.next()) {
                return new TalspilTransaktionStdRecord(
                    result.getString("SPILUDBYDERNAVN"),
                    result.getString("SPILFILIDENTIFIKATION"),
                    result.getString("MONOPOLSPILPRODUKTIDENTIFIKATION"),
                    result.getString("SPILCERTIFIKATIDENTIFIKATION"),
                    result.getString("XSDSKEMANAVN"),
                    result.getLong("MONOPOLSPILPRODUKTAABENTNETVAERK"),
                    result.getLong("MONOPOLSPILPRODUKTNUMMER"),
                    result.getLong("MONOPOLPULJESPILGEVINSTPULJEPROCENT"),
                    result.getLong("MONOPOLPULJESPILANTALRESULTATPULJER"),
                    result.getLong("MONOPOLTALSPILANTALTAL"),
                    result.getBigDecimal("MONOPOLTALSPILRAEKKEPRIS"),
                    result.getLong("MONOPOLTALSPILDRAWNUMMER"),
                    result.getLong("MONOPOLTALSPILUGENUMMER"),
                    result.getDate("SPILFORVENTETSLUTDATOTID").toLocalDate(),
                    result.getString("VALUTAOPLYSNINGKODE"),
                    result.getDate("MONOPOLTALSPILENDOFGAMEDATOTID").toLocalDate(),
                    result.getBigDecimal("MONOPOLTALSPILINDSKUDSPILTILLINDH"),
                    result.getBigDecimal("MONOPOLTALSPILINDSKUDSPILTOTAL"),
                    result.getBigDecimal("MONOPOLTALSPILINDSKUDJACKPOTTILLINDH"),
                    result.getBigDecimal("MONOPOLTALSPILINDSKUDJACKPOTTOTAL"),
                    result.getLong("MONOPOLTALSPILANTALRAEKKERTILLINDH"),
                    result.getLong("MONOPOLTALSPILSAMLETANTALRAEKKER"),
                    result.getBigDecimal("MONOPOLTALSPILGEVINSTPULJEBELOEB"),
                    result.getDate("MONOPOLSPILPRODUKTFAKTISKSLUTDATOTID").toLocalDate(),
                    result.getString("MONOPOLSPILPRODUKTNAVN"),
                    result.getString("MONOPOLSPILKATEGORINAVN"),
                    result.getLong("tx_spiller_kupon_counter"),
                    (result.getLong("tx_complete") != 0)
                );
            }
        }  catch (SQLException e) {
            throw new ApplicationException("Failed to read STG_MONOPOLTALSPIL_STDRECORD", e);
        }finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return null;
    }

    @Transactional(readOnly = true)
    public Long selectKuponCounter(String spilUdbyderNavn, String spilFilIdentifikation) throws SQLException {
        String sqlSelect = """
            select tx_spiller_kupon_counter
            from STG_MONOPOLTALSPIL_STDRECORD
            where SPILUDBYDERNAVN = ? and SPILFILIDENTIFIKATION = ?
            order by SPILUDBYDERNAVN, SPILFILIDENTIFIKATION
        """;
        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sqlSelect)) {
            ps.setString(1, spilUdbyderNavn);
            ps.setString(2, spilFilIdentifikation);

            ResultSet result = ps.executeQuery();
            if (result.next()) {
                return result.getLong("tx_spiller_kupon_counter");
            }
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return 0L;
    }

}

