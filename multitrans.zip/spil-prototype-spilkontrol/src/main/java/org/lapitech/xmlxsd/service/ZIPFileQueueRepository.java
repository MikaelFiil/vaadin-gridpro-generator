package org.lapitech.xmlxsd.service;

import dk.skat.spilkontrol.business.model.StandardRecord;
import dk.skat.spilkontrol.datalayer.xml.util.WontCloseBufferedInputStream;
import dk.skat.spilkontrol.validate.XmlFileProcessor;
import org.lapitech.errorlogs.domain.ErrorMessage;
import org.lapitech.errorlogs.service.ErrorMessageRepository;
import org.lapitech.exceptions.ApplicationException;
import org.lapitech.xmlxsd.business.HestDKHandler;
import org.lapitech.xmlxsd.business.MonopolTalspilHandler;
import org.lapitech.xmlxsd.domain.XMLFileWrap;
import org.lapitech.xmlxsd.domain.ZIPFileQueue;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.xml.sax.SAXException;

import javax.sql.DataSource;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *  Demonstration application with specific transaction management.
 *  This is the top level transaction boundary.
 *  Inside the transaction of the method updateZIPFileMultiTransCommit() calls are made to the next level
 *  of handling in the method xmlFileRepository.processXMLFile() which also starts a new transaction.
 *  This level keeps track of whether each XML file in the ZIP file was successfully processed by updating a counter
 *  each time the next XML file was successfully processed
 */

@Repository
public class ZIPFileQueueRepository {

    private final DataSource dataSource;
    private final MonopolTalspilHandler monopolTalspilHandler;
    private final HestDKHandler hestDKHandler;
    private final TalspilTransStdRecordRepository talspilTransStdRecordRepository;
    private final ErrorMessageRepository errorMessageRepository;
    private XmlFileProcessor xmlFileProcessor;


    ZIPFileQueueRepository(DataSource dataSource, MonopolTalspilHandler monopolTalspilHandler,
                           HestDKHandler hestDKHandler,
                           TalspilTransStdRecordRepository talspilTransStdRecordRepository,
                           ErrorMessageRepository errorMessageRepository) {
        this.dataSource = dataSource;
        this.monopolTalspilHandler = monopolTalspilHandler;
        this.hestDKHandler = hestDKHandler;
        this.talspilTransStdRecordRepository = talspilTransStdRecordRepository;
        this.errorMessageRepository = errorMessageRepository;
        xmlFileProcessor = new XmlFileProcessor();
    }


    /**
     * Commit is automatic when returning normally without exceptions.
     * Exceptions and validation errors may be coming up from lower levels of transactions.
     * There are basically 3 types of errors;
     *    1. Errors parsing the XML file - Previous XML files are commited, current and following XML files are aborted
     *    2. Logical errors handling the values of the XML file. Previous XML files are commited, then it depends :-)
     *    3. Programming errors - Previous XML files are commited, current and following XML files are aborted
     * @param zipFileQueueItem          The ZIP file item to process
     */
    @Transactional
    public ZIPFileQueue updateZIPFileMultiTransCommit(ZIPFileQueue zipFileQueueItem) {
        String sql = "update zip_file_queue set xml_processed_counter = xml_processed_counter + 1 where filename = ?";
        long countStart = selectXMLCounter(zipFileQueueItem);

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, zipFileQueueItem.getZipFileName());

            List<XMLFileWrap> xmlFileWraps = listXMLFiles(zipFileQueueItem);
            for (; countStart < xmlFileWraps.size(); countStart++) {

                xmlFileProcessor = new XmlFileProcessor();
                XMLFileWrap xmlFileWrap = xmlFileWraps.get((int) countStart);

                // Parsing may throw exceptions. In that case it will abort the transaction as well as the handling of the rest of the XML files in the ZIP file
                // Any parsing error means the XML file is basically corrupt, hence it will result in a completely unprocessed XML file.
                StandardRecord standardRecord = parseAndGetStandardRecord(xmlFileWrap.getFile());

                // After parsing the XML file, the StandardRecord contains the type of structure, so we must branch out. This is to be expanded for full coverage in production code
                switch (standardRecord.getStructureType()) {
                    case MonopolTalspilTransaktionStruktur,
                        MonopolTalspilStartStruktur,
                        MonopolTalspilEndOfGameStruktur,
                        MonopolTalspilSlutStruktur:

                            if (!monopolTalspilHandler.handleMonopolTalspil(zipFileQueueItem, xmlFileWrap, standardRecord)) {   // Returns false in case of an error
                                return mergeZIPFile(zipFileQueueItem);      // Stop further processing
                            }

                        break;

                    case HestDKSlutStruktur,
                        HestDKTransaktionStruktur,
                        HestDKStartStruktur:

                            if (!hestDKHandler.handleHestDK(zipFileQueueItem, xmlFileWrap, standardRecord)) {   // Returns false in case of an error
                                return mergeZIPFile(zipFileQueueItem);      // Stop further processing
                            }

                        break;

                    // ********** F U R T H E R   X S D   S T R U C T U R E S   G O E S   H E R E

                }
                ps.executeUpdate(); // Increment XML processed counter
                con.commit();       // And commit that transaction
                zipFileQueueItem.setXmlProcessedCounter(zipFileQueueItem.getXmlProcessedCounter()+1);   // Increment counter without reloading from database

            }       // for (; countStart < xmlFileWraps.size(); countStart++) {

            setZipFileComplete(zipFileQueueItem);
            return mergeZIPFile(zipFileQueueItem);

        } catch (SQLException e) {
            throw new ApplicationException("Failed to update zip_file_queue table", e);
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }

    }

    private ZIPFileQueue mergeZIPFile(ZIPFileQueue zipFileQueueItem) throws SQLException {
        String sqlSelect = "select filename, xml_processed_counter, complete from zip_file_queue where filename = ?";

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sqlSelect)) {
            ps.setString(1, zipFileQueueItem.getZipFileName());
            ResultSet result = ps.executeQuery();
            if (result.next()) {
                zipFileQueueItem.setXmlProcessedCounter( result.getInt("xml_processed_counter"));
                zipFileQueueItem.setComplete(result.getInt("complete") != 0);
                return zipFileQueueItem;
            }
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return null;
    }

    @Transactional(readOnly = true)
    public List<ZIPFileQueue> selectZIPFiles() throws SQLException {
        String sqlSelect = "select filename, xml_processed_counter, complete from zip_file_queue order by filename";
        List<ZIPFileQueue> zipFiles = new ArrayList<>();

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sqlSelect)) {
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                ZIPFileQueue zipFile = new ZIPFileQueue(result.getString("filename"),
                        result.getInt("xml_processed_counter"), (result.getInt("complete") != 0), null);
                zipFiles.add(zipFile);
            }
        } finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return zipFiles;
    }

    private Long selectXMLCounter(ZIPFileQueue zipFile) {
        String sqlSelect = "select xml_processed_counter from zip_file_queue where filename = ?";

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sqlSelect)) {
            ps.setString(1, zipFile.getZipFileName());

            ResultSet result = ps.executeQuery();
            if (result.next()) {
                return result.getLong("xml_processed_counter");
            }
        } catch (SQLException e) {
            throw new ApplicationException("Failed to read zip_file_queue table", e);
        }
        finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
        return 0L;
    }


    private void setZipFileComplete(ZIPFileQueue zipFile) {
        String sqlSelect = "update zip_file_queue set complete = 1 where filename = ?";

        Connection con = DataSourceUtils.getConnection(dataSource);
        try (PreparedStatement ps = con.prepareStatement(sqlSelect)) {
            ps.setString(1, zipFile.getZipFileName());

            ps.executeUpdate();     // Increment counter
        } catch (SQLException e) {
            throw new ApplicationException("Failed to read zip_file_queue table", e);
        }
        finally {
            DataSourceUtils.releaseConnection(con, dataSource);
        }
    }

    public List<XMLFileWrap> listXMLFiles(ZIPFileQueue zipFileQueue) {
        List<XMLFileWrap> xmlFiles = new ArrayList<>();
        for (File file : zipFileQueue.getFiles()) {
            XMLFileWrap xmlFileWrap = new XMLFileWrap(file, null);
            xmlFileWrap.setTalspilTransaktionStdRecord(talspilTransStdRecordRepository.findTalspilTransaktionStdRecordFromZipXml(zipFileQueue.getZipFileName(), file.getName()));
            xmlFiles.add(xmlFileWrap);
        }
        return xmlFiles;
    }


    private StandardRecord parseAndGetStandardRecord(File selectedFile)  {
        try (WontCloseBufferedInputStream bis = new WontCloseBufferedInputStream(new FileInputStream(selectedFile.getAbsolutePath()))) {
                return xmlFileProcessor.getStardardRecord(bis);
        } catch (IOException | ParserConfigurationException | SAXException e) {
            ErrorMessage errorMessage = new ErrorMessage();
            errorMessage.setSpilUdbyder("N/A");
            errorMessage.setSpilfilIdentifikation("N/A");
            errorMessage.setOriginatingFrom("File: " + selectedFile.getName());
            errorMessage.setErrorMessage("File " + selectedFile.getAbsolutePath() + " has an invalid XML format! - " + e.getMessage());
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            errorMessage.setErrorMessageLong(sw.toString());
            try {
                errorMessageRepository.saveErrorMessage(errorMessage);
            } catch (SQLException ex) {
                throw new ApplicationException("Failed to update error_log table", e);
            }

            throw new ApplicationException("File " + selectedFile.getAbsolutePath() + " has an invalid XML format!", e);
        }
    }
}

