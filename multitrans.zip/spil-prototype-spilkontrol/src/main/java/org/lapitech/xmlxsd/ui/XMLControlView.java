package org.lapitech.xmlxsd.ui;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.H4;
import com.vaadin.flow.component.html.Hr;
import com.vaadin.flow.component.html.Main;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.select.Select;
import com.vaadin.flow.component.shared.SelectionPreservationMode;
import com.vaadin.flow.component.textfield.IntegerField;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Menu;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.theme.lumo.LumoUtility;
import com.vaadin.signals.SignalFactory;
import org.lapitech.base.ui.component.NotficationWrapper;
import org.lapitech.base.ui.component.ViewToolbar;
import org.lapitech.config.SPMValueProvider;
import org.lapitech.exceptions.ApplicationException;
import org.lapitech.xmlxsd.domain.XMLFileWrap;
import org.lapitech.xmlxsd.domain.ZIPFileQueue;
import org.lapitech.xmlxsd.domain.monopol.TalspilSpillerOgKupon;
import org.lapitech.xmlxsd.service.TalspilSpillerOgKuponRepository;
import org.lapitech.xmlxsd.service.ZIPFileQueueRepository;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.*;


@Route("xml-parser")
@PageTitle("XML Parser Demo")
@Menu(order = 200, icon = "vaadin:clipboard-check", title = "XML Parser Demo")
class XMLControlView extends Main {

    private final SPMValueProvider spmValueProvider;
    private final ZIPFileQueueRepository zipFileQueueRepository;
    private final TalspilSpillerOgKuponRepository talspilSpillerOgKuponRepository;

    // ZIP File fields
    private Select<ZIPFileQueue> selectZipFile;
    private IntegerField xmlFileCounter;
    private Checkbox zipIsComplete;
    private Button processXMLMultiTransCommitBtn;
    private Grid<XMLFileWrap> xmlFileGrid;
    private Grid<TalspilSpillerOgKupon> spillerOgKuponGrid;
    private TextArea textArea;
    private Button saveXMLFile;
    private Span xmlFileFullPath;
    private TextField spillerInformationIdentifikationField;
    private TextField spilTransaktionIdentifikationField;


    XMLControlView(SPMValueProvider spmValueProvider, ZIPFileQueueRepository zipFileQueueRepository,
                   TalspilSpillerOgKuponRepository talspilSpillerOgKuponRepository) {
        this.spmValueProvider = spmValueProvider;
        this.zipFileQueueRepository = zipFileQueueRepository;
        this.talspilSpillerOgKuponRepository = talspilSpillerOgKuponRepository;

        initUI();
        setSizeFull();
        addClassNames(LumoUtility.BoxSizing.BORDER, LumoUtility.Display.FLEX,
            LumoUtility.FlexDirection.COLUMN, LumoUtility.Padding.MEDIUM, LumoUtility.Gap.SMALL);

        try {
            selectZipFile.setItems(findZIPQueueDirs());
            buildUX();
        } catch (SQLException | URISyntaxException e) {
            throw new RuntimeException(e);
        }
        processXMLMultiTransCommitBtn.addThemeVariants(ButtonVariant.LUMO_PRIMARY);

        HorizontalLayout horizontalLayout1 = new HorizontalLayout(selectZipFile,  xmlFileCounter, zipIsComplete, processXMLMultiTransCommitBtn);
        horizontalLayout1.setAlignItems(FlexComponent.Alignment.BASELINE);

        HorizontalLayout horizontalLayout2 = new HorizontalLayout(
            new Span("Simulating SpillerKupon Error"), spillerInformationIdentifikationField, spilTransaktionIdentifikationField);
        horizontalLayout2.setAlignItems(FlexComponent.Alignment.BASELINE);

        add(new ViewToolbar("ZIP File Demo", ViewToolbar.group(horizontalLayout1)), new Hr());
        add(new H4("XML file status"), xmlFileGrid, new Hr());
        add(new H4("Spiller og kupon status"), horizontalLayout2, new Hr(), spillerOgKuponGrid);

        HorizontalLayout horizontalLayout3 = new HorizontalLayout(new Span("XML file content"), saveXMLFile, xmlFileFullPath);
        horizontalLayout3.setAlignItems(FlexComponent.Alignment.BASELINE);

        add(horizontalLayout3);
        add(textArea);
    }

    private List<ZIPFileQueue> findZIPQueueDirs() throws URISyntaxException, SQLException {
        List<ZIPFileQueue> zipFiles = zipFileQueueRepository.selectZIPFiles();
        String xmlRootDir = spmValueProvider.getXmlRootDir();
        for (ZIPFileQueue zipFileQueue : zipFiles) {
            List<File> files = Arrays.stream(Objects.requireNonNull(Paths.get(xmlRootDir + "/" + zipFileQueue.getZipFileName()).toFile().listFiles())).toList() ;
            zipFileQueue.setFiles(files);
        }
        return zipFiles;
    }

    private void initUI() {
        selectZipFile = new Select<>();
        selectZipFile.setLabel("Select a ZIP file");
        selectZipFile.setEmptySelectionAllowed(false);
        selectZipFile.setWidth("30rem");

        xmlFileCounter = new IntegerField("Completed XML files");
        xmlFileCounter.setValue(0);
        xmlFileCounter.setReadOnly(true);
        zipIsComplete = new Checkbox("Is Complete");
        zipIsComplete.setValue(false);
        zipIsComplete.setReadOnly(true);

        xmlFileGrid = new Grid<>(XMLFileWrap.class);
        xmlFileGrid.removeAllColumns();
        xmlFileGrid.addColumn(XMLFileWrap::getFileName)
            .setSortable(true)
            .setResizable(true)
            .setHeader("XML file name");
        xmlFileGrid.addColumn(XMLFileWrap::getTxSpillerKuponCounter)
            .setSortable(true)
            .setResizable(true)
            .setHeader("SpillerKuponCounter");
        xmlFileGrid.addColumn(XMLFileWrap::isCompleted)
                .setSortable(true)
                .setResizable(true)
                .setHeader("Is Completed");

        xmlFileGrid.setWidthFull();
        xmlFileGrid.setMinHeight("400px");
        xmlFileGrid.setMaxHeight("400px");
        xmlFileGrid.setEmptyStateText("No XML files found");
        xmlFileGrid.addThemeVariants(GridVariant.LUMO_WRAP_CELL_CONTENT);
        xmlFileGrid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT);
        xmlFileGrid.setSelectionPreservationMode(SelectionPreservationMode.PRESERVE_EXISTING);
        xmlFileGrid.setSelectionMode(Grid.SelectionMode.SINGLE);

        spillerOgKuponGrid = new Grid<>(TalspilSpillerOgKupon.class);
        spillerOgKuponGrid.removeAllColumns();
        spillerOgKuponGrid.addColumn(TalspilSpillerOgKupon::getSpillerInformationIdentifikation)
            .setSortable(true)
            .setResizable(true)
            .setHeader("SpillerInformationIdentifikation");
        spillerOgKuponGrid.addColumn(TalspilSpillerOgKupon::getSpilTransaktionIdentifikation)
            .setSortable(true)
            .setResizable(true)
            .setHeader("SpilTransaktionIdentifikation");
        spillerOgKuponGrid.addColumn(TalspilSpillerOgKupon::getSpilKoebDatoTid)
            .setSortable(true)
            .setResizable(true)
            .setHeader("SpilKøbDatoTid");
        spillerOgKuponGrid.addColumn(TalspilSpillerOgKupon::getSpilAntalRaekker)
            .setSortable(true)
            .setResizable(true)
            .setHeader("AntalRækker");
        spillerOgKuponGrid.addColumn(TalspilSpillerOgKupon::getTxNummerIxmlFil)
            .setSortable(true)
            .setResizable(true)
            .setHeader("Nummer i XML Fil");
        spillerOgKuponGrid.addColumn(TalspilSpillerOgKupon::getTxComplete)
            .setSortable(true)
            .setResizable(true)
            .setHeader("Is complete");

        spillerOgKuponGrid.setWidthFull();
        spillerOgKuponGrid.setMinHeight("300px");
        spillerOgKuponGrid.setMaxHeight("300px");
        spillerOgKuponGrid.setEmptyStateText("No SpillerOgKupon found");
        spillerOgKuponGrid.addThemeVariants(GridVariant.LUMO_WRAP_CELL_CONTENT);
        spillerOgKuponGrid.addThemeVariants(GridVariant.LUMO_ROW_STRIPES, GridVariant.LUMO_COMPACT);
        spillerOgKuponGrid.setSelectionPreservationMode(SelectionPreservationMode.PRESERVE_EXISTING);
        spillerOgKuponGrid.setSelectionMode(Grid.SelectionMode.SINGLE);

        xmlFileFullPath = new Span();
        textArea = new TextArea();
        textArea.setMinHeight("400px");

        spillerInformationIdentifikationField = new TextField("SpillerInformationIdentifikation");
        spillerInformationIdentifikationField.setWidth("20rem");
        spilTransaktionIdentifikationField = new TextField("SpilTransaktionIdentifikation");
        spilTransaktionIdentifikationField.setWidth("25rem");
    }

    private void buildUX() throws SQLException {

        selectZipFile.addValueChangeListener(event -> {
            if (event.getValue() != null) {
                xmlFileCounter.setValue(event.getValue().getXmlProcessedCounter());
                zipIsComplete.setValue(event.getValue().isComplete());
                xmlFileGrid.setItems(zipFileQueueRepository.listXMLFiles(event.getValue()));
                spillerOgKuponGrid.setItems(new ArrayList<>());
                textArea.setValue("");
                xmlFileFullPath.setText("");
            }
        });

        // Start processing selected ZIP file
        processXMLMultiTransCommitBtn = new Button("Process XML Multi Trans Commit", _ -> {
            ZIPFileQueue zipFileQueueItem = selectZipFile.getValue();
            if (zipFileQueueItem != null) {

                // Using Signals for value sharing across stack and component boundaries
                SignalFactory.IN_MEMORY_SHARED.value(SPMValueProvider.SPILLER_INFORMATION_IDENTIFICATION, "").value(spillerInformationIdentifikationField.getValue());
                SignalFactory.IN_MEMORY_SHARED.value(SPMValueProvider.SPIL_TRANSAKTION_IDENTIFICATION, "").value(spilTransaktionIdentifikationField.getValue());

                System.out.println("Processing ZIP file: " + zipFileQueueItem.getZipFileName());
                try {
                    zipFileQueueItem = zipFileQueueRepository.updateZIPFileMultiTransCommit(zipFileQueueItem);
                } catch (ApplicationException ae) {
                    NotficationWrapper.errorNotification(ae.getMessage(), ae.getEx());
                }
                xmlFileCounter.setValue(zipFileQueueItem.getXmlProcessedCounter());
                zipIsComplete.setValue(zipFileQueueItem.isComplete());

                System.out.println("Finished processing ZIP file");
                xmlFileGrid.setItems(zipFileQueueRepository.listXMLFiles(zipFileQueueItem));
                spillerOgKuponGrid.setItems(new ArrayList<>());
                textArea.setValue("");
                xmlFileFullPath.setText("");
            }
        });

        xmlFileGrid.addSelectionListener(item -> {
            Optional<XMLFileWrap> xmlFileWrap = item.getFirstSelectedItem();
            if (xmlFileWrap.isPresent()) {
                if (xmlFileWrap.get().getTalspilTransaktionStdRecord() != null) {
                    spillerOgKuponGrid.setItems(talspilSpillerOgKuponRepository.listSpillerOgKuponPerXML(
                            xmlFileWrap.get().getTalspilTransaktionStdRecord().getSpilUdbyderNavn(),
                            xmlFileWrap.get().getTalspilTransaktionStdRecord().getSpilFilIdentifikation()));
                } else {
                    spillerOgKuponGrid.setItems(new ArrayList<>());
                }
                File selectedFile = item.getFirstSelectedItem().get().getFile();
                try {
                    textArea.setValue(new String(Files.readAllBytes(selectedFile.toPath())));
                    xmlFileFullPath.setText(spmValueProvider.getXmlRootDir() + "/" + selectZipFile.getValue().getZipFileName()
                            + "/" + xmlFileGrid.getSelectedItems().stream().toList().getFirst().getFileName());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });


        saveXMLFile = new Button("Save XML File", _ -> {
            XMLFileWrap xmlFileWrap =  xmlFileGrid.getSelectedItems().stream().toList().getFirst();
            File selectedFile = xmlFileWrap.getFile();
            Notification notification = new Notification();
            notification.setPosition(Notification.Position.MIDDLE);
            notification.setDuration(3000);

            try (FileWriter fw = new FileWriter(selectedFile.getAbsoluteFile(), false)) {
                BufferedWriter bw = new BufferedWriter(fw);
                String txt = textArea.getValue();
                bw.write(txt);
                bw.flush();
            } catch (IOException e) {
                notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
                notification.setText("Could not save XML file");
                notification.open();
                throw new RuntimeException(e);
            }
            notification.addThemeVariants(NotificationVariant.LUMO_SUCCESS);
            notification.setText("XML file saved successfully");
            notification.open();
        });
    }

}
