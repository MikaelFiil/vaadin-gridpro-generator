
-- Demo data for the schema file 'schema-basic-trans.sql'
-- The demonstration view is in the file TransactionControlView.java
-- At the end are useful DML sentences to reset the data after a test
--

insert into zip_file (description, counter)
	values('ZIP File 1', 0);
insert into zip_file (description, counter)
	values('ZIP File 2', 0);
insert into zip_file (description, counter)
	values('ZIP File 3', 0);


insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(1, 'XML File 1', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(1, 'XML File 2', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(1, 'XML File 3', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(1, 'XML File 4', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(1, 'XML File 5', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(1, 'XML File 6', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(1, 'XML File 7', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(1, 'XML File 8', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(1, 'XML File 9', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(1, 'XML File 10', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(2, 'XML File 1', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(2, 'XML File 2', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(2, 'XML File 3', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(2, 'XML File 4', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(2, 'XML File 5', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(2, 'XML File 6', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(2, 'XML File 7', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(2, 'XML File 8', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(2, 'XML File 9', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(2, 'XML File 10', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(3, 'XML File 1', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(3, 'XML File 2', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(3, 'XML File 3', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(3, 'XML File 4', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(3, 'XML File 5', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(3, 'XML File 6', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(3, 'XML File 7', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(3, 'XML File 8', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(3, 'XML File 9', 0, 0);
insert into xml_file (zip_file_id, description, is_processed, game_processed_counter)
	values(3, 'XML File 10', 0, 0);


insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(1, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(1, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027, 2028, 2029, 2030, 2031));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(1, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027, 2028, 2029, 2030, 2031, 2032));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(1, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(1, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027, 2028, 2029));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (2, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(2, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(2, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(2, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(2, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (2, 'Spille transaktion 6', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(2, 'Spille transaktion 7', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(2, 'Spille transaktion 8', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(2, 'Spille transaktion 9', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(2, 'Spille transaktion 10', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (3, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(3, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(3, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(3, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(3, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (3, 'Spille transaktion 6', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(3, 'Spille transaktion 7', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(3, 'Spille transaktion 8', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(3, 'Spille transaktion 9', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(3, 'Spille transaktion 10', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (3, 'Spille transaktion 11', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(3, 'Spille transaktion 12', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(3, 'Spille transaktion 13', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(3, 'Spille transaktion 14', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(3, 'Spille transaktion 15', 0, 0, 0, year_array(2025, 2026, 2027));


insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (4, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (4, 'Spille transaktion 6', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 7', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 8', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 9', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 10', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (4, 'Spille transaktion 11', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 12', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 13', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 14', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 15', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (4, 'Spille transaktion 16', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 17', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 18', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 19', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(4, 'Spille transaktion 20', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (5, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (5, 'Spille transaktion 6', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 7', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 8', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 9', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 10', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (5, 'Spille transaktion 11', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 12', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 13', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 14', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 15', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (5, 'Spille transaktion 16', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 17', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 18', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 19', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 20', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (5, 'Spille transaktion 21', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 22', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 23', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 24', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(5, 'Spille transaktion 25', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (6, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(6, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(6, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(6, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(6, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (7, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(7, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(7, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(7, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(7, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (8, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(8, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(8, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(8, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(8, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (9, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(9, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(9, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(9, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(9, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (10, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(10, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(10, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(10, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(10, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (11, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(11, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(11, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(11, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(11, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (12, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(12, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(12, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(12, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(12, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (13, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(13, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(13, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(13, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(13, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (14, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(14, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(14, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(14, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(14, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (15, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(15, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(15, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(15, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(15, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (16, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(16, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(16, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(16, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(16, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (17, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(17, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(17, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(17, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(17, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (18, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(18, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(18, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(18, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(18, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (19, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(19, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(19, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(19, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(19, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (20, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(20, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(20, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(20, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(20, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (21, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(21, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(21, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(21, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(21, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (22, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(22, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(22, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(22, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(22, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (23, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(23, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(23, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(23, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(23, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (24, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(24, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(24, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(24, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(24, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (25, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(25, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(25, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(25, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(25, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (26, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(26, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(26, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(26, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(26, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (27, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(27, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(27, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(27, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(27, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (28, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(28, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(28, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(28, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(28, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (29, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(29, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(29, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(29, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(29, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));

insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values (30, 'Spille transaktion 1', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(30, 'Spille transaktion 2', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(30, 'Spille transaktion 3', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(30, 'Spille transaktion 4', 0, 0, 0, year_array(2025, 2026, 2027));
insert into xml_file_game (xml_file_id, description, is_processed, fail_by_rollback, fail_by_exception, years)
    values(30, 'Spille transaktion 5', 0, 0, 0, year_array(2025, 2026, 2027));



-- ******************************  DML  **************************
-- ********************************** Clearing data to do another test  ***********************************

UPDATE zip_file
SET counter = 0;

UPDATE xml_file
SET is_processed = 0, game_processed_counter = 0;

UPDATE xml_file_game
SET is_processed = 0, fail_by_rollback = 0, fail_by_exception = 0;


UPDATE xml_file_game
SET fail_by_rollback = 0
WHERE id = 52

UPDATE xml_file_game
SET fail_by_exception = 0
WHERE id = 88
