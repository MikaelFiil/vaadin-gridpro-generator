
-- Demo data for the schema file 'schema.sql'
-- The demonstration view is in the file XMLControlView.java

-- *******************************   Basis Data for Martins Stage database design   *******************************
INSERT INTO valuta v (VALUTAKODE) values('DKK');

INSERT INTO SPILSALGSKANAL (SPILSALGSKANAL) VALUES('Mobil');
INSERT INTO SPILSALGSKANAL (SPILSALGSKANAL) VALUES('Forhandler');
INSERT INTO SPILSALGSKANAL (SPILSALGSKANAL) VALUES('Internet');

INSERT INTO SPILUDBYDER (SPILUDBYDERNAVN)
VALUES ('DLOLoerdagsLotto');

INSERT INTO SPILKATEGORI (SPILKATEGORINAVN)
VALUES ('MonopolLoerdagsLotto');

INSERT INTO SPILPRODUKT (SPILUDBYDERNAVN, SPILKATEGORINAVN, SPILPRODUKTNAVN)
VALUES ('DLOLoerdagsLotto', 'MonopolLoerdagsLotto', 'Lotto');

INSERT INTO XSDSKEMA (XSDSKEMANAVN)
VALUES ('MonopolTalspilTransaktionStrukturType');

INSERT INTO zip_file_queue (filename, xml_processed_counter, complete)
VALUES ('DLOLoerdagsLotto-1691583\Talspil\2020-12-01', 0, 0);
INSERT INTO zip_file_queue (filename, xml_processed_counter, complete)
VALUES ('DLOLoerdagsLotto-1691583\Talspil\2020-12-02', 0, 0);

INSERT INTO zip_file_queue (filename, xml_processed_counter, complete)
VALUES ('DLOLoerdagsLotto-2112592\Talspil\2025-10-31', 0, 0);
INSERT INTO zip_file_queue (filename, xml_processed_counter, complete)
VALUES ('DLOLoerdagsLotto-2112592\Talspil\2025-11-01', 0, 0);

INSERT INTO zip_file_queue (filename, xml_processed_counter, complete)
VALUES ('DLOLoerdagsLotto-2112633\Talspil\2025-11-01', 0, 0);


-- ********************************** Clearing data to do another test  ***********************************

DELETE FROM STG_MONOPOLTAL_SPILKOMBINATIONERLISTE;
DELETE FROM STG_MONOPOLTALSPIL_SPILLEROGKUPON;
DELETE FROM STG_MONOPOLTALSPIL_STDRECORD;
DELETE FROM STG_XMLFIL;

UPDATE ZIP_FILE_QUEUE SET XML_PROCESSED_COUNTER = 0, COMPLETE= 0;

