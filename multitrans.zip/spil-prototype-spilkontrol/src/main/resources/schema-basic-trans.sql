
-- Schema used for testing multilevel transactions without domain specific knowledge

delete from xml_file_game;
delete from xml_file;
delete from zip_file;

drop table xml_file_game;
drop table xml_file;
drop table zip_file;


-- Demonstrating array columns, note that Oracle converts all numbers to BigDecimal in Java-JDBC
create or replace TYPE year_array as VARRAY(20) of integer;


-- Oracle or PostgreSQL Demo
create table zip_file (
    id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    description varchar(100) not null,
    counter integer not null
);

create table xml_file (
    id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    zip_file_id integer not null,
    description varchar(100) not null,
    is_processed number(1) default 0 not null,
    game_processed_counter integer not null,
    foreign key(zip_file_id) references zip_file(id) on delete cascade
);

create table xml_file_game (
    id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    xml_file_id integer not null,
    description varchar(100) not null,
    is_processed number(1) default 0 not null,
    fail_by_rollback number(1) default 0 not null,
    fail_by_exception number(1) default 0 not null,
    years year_array,                                                           -- Demonstrating array columns, note that Oracle converts all numbers to BigDecimal in Java-JDBC
    foreign key(xml_file_id) references xml_file(id) on delete cascade
);
