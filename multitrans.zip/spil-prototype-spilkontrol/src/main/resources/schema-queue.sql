-- **********************************************
-- G R A N T I N G   R I G H T S
-- **********************************************

# Fra en terminal på test_db (docker)

export ORACLE_PDB_SID=XEPDB1
sqlplus / as sysdba

GRANT CREATE TYPE TO talspil;
GRANT EXECUTE ON DBMS_AQADM TO talspil;
GRANT EXECUTE ON DBMS_AQ TO talspil;

-- *********************************************
-- D R O P S

-- First stop the queue
BEGIN
DBMS_AQADM.STOP_QUEUE(queue_name => 'TAMPER_TOKEN_MSG_QUEUE');
END;

BEGIN
DBMS_AQADM.DROP_QUEUE(queue_name => 'TAMPER_TOKEN_MSG_QUEUE');
END;

BEGIN
DBMS_AQADM.DROP_QUEUE_TABLE(queue_table => 'TAMPER_TOKEN_QT');
END;

DROP TYPE tamper_token_zip_queue_type;

DROP PROCEDURE queue_tampertoken;
DROP PROCEDURE next_tampertoken;

-- Verify
SELECT * FROM DBA_QUEUE_TABLES WHERE QUEUE_TABLE = 'TAMPER_TOKEN_QT';
SELECT * FROM DBA_QUEUES WHERE QUEUE_TABLE = 'TAMPER_TOKEN_QT';


-- **********************************************
-- C O N S T R U C T I N G    Q U E U E
-- **********************************************


-- C R E A T E S
CREATE TYPE tamper_token_zip_queue_type AS OBJECT (
    SPILUDBYDERNAVN                     VARCHAR2 (45 CHAR),
    SPILFILIDENTIFIKATION               VARCHAR2 (300 CHAR),
    ZIP_FILE_NAME                       VARCHAR2 (300 CHAR),
    CREATED                             TIMESTAMP
);

-- Verification
SELECT * FROM USER_OBJECTS WHERE object_name LIKE '%TAMPER%'


BEGIN
    DBMS_AQADM.CREATE_QUEUE_TABLE(
        queue_table => 'TAMPER_TOKEN_QT',
        queue_payload_type => 'TAMPER_TOKEN_ZIP_QUEUE_TYPE'
    );

    DBMS_AQADM.CREATE_QUEUE (
        queue_name => 'TAMPER_TOKEN_MSG_QUEUE',
        queue_table => 'TAMPER_TOKEN_QT'
    );

    DBMS_AQADM.START_QUEUE('TAMPER_TOKEN_MSG_QUEUE');
END;

-- Verification
SELECT * FROM DBA_QUEUES WHERE owner LIKE '%TALSPIL%';
SELECT * FROM DBA_QUEUE_TABLES WHERE owner LIKE '%TALSPIL%';



-- **********************************************
-- C O N S T R U C T I N G    Q U E U E    A P I
-- **********************************************

-- ENQUEUE a TAMPER_TOKEN_ZIP_QUEUE_TYPE message
CREATE OR REPLACE PROCEDURE queue_tampertoken (
	payloadToken IN TAMPER_TOKEN_ZIP_QUEUE_TYPE,
	message_id OUT VARCHAR2)
IS
	message_handle RAW(16);
	local_message_properties DBMS_AQ.MESSAGE_PROPERTIES_T;
BEGIN
   	DBMS_AQ.ENQUEUE(
      queue_name      => 'TAMPER_TOKEN_MSG_QUEUE',
      enqueue_options => DBMS_AQ.ENQUEUE_OPTIONS_T(),
      message_properties => local_message_properties,
      payload         => payloadToken,
      msgid           => message_handle
   	);
	message_id := RAWTOHEX(message_handle);
END;

-- DEQUEUE a TAMPER_TOKEN_ZIP_QUEUE_TYPE message
CREATE OR REPLACE PROCEDURE next_tampertoken (
	spiludbyder IN VARCHAR2,
	tamper_token OUT TAMPER_TOKEN_ZIP_QUEUE_TYPE)
IS
	local_dequeue_options DBMS_AQ.DEQUEUE_OPTIONS_T;
	local_message_properties DBMS_AQ.MESSAGE_PROPERTIES_T;
	payloadOut TAMPER_TOKEN_ZIP_QUEUE_TYPE;
	msg_id RAW(16);
BEGIN
	-- Set dequeue options
	local_dequeue_options.wait := DBMS_AQ.NO_WAIT;
	local_dequeue_options.navigation := DBMS_AQ.FIRST_MESSAGE;		-- Must be set to be able to change correlation between calls to dequeue
    local_dequeue_options.deq_condition := 'tab.user_data.SPILUDBYDERNAVN = '''|| spiludbyder||'''';

   	-- Dequeue the message
	DBMS_AQ.DEQUEUE(
      queue_name => 'TAMPER_TOKEN_MSG_QUEUE',
      dequeue_options => local_dequeue_options,
      message_properties => local_message_properties,
      payload => tamper_token,
      msgid => msg_id);

END;


-- **********************************************
-- U S I N G    Q U E U E
-- **********************************************

-- Calling queue_tampertoken()
DECLARE
	payloadToken TAMPER_TOKEN_ZIP_QUEUE_TYPE := TAMPER_TOKEN_ZIP_QUEUE_TYPE('LOTTO', 'FIL1234567894', 'ZIP1234567894', CURRENT_TIMESTAMP);
	msgId VARCHAR2(100);
BEGIN
	queue_tampertoken(payloadToken, msgId);
	DBMS_OUTPUT.PUT_LINE(msgId);
END;


-- Calling next_tampertoken()
DECLARE
	payload TAMPER_TOKEN_ZIP_QUEUE_TYPE;
BEGIN
	next_tampertoken('LOTTO', payload);
	DBMS_OUTPUT.PUT_LINE(payload.SPILUDBYDERNAVN);
	DBMS_OUTPUT.PUT_LINE(payload.SPILFILIDENTIFIKATION);
	DBMS_OUTPUT.PUT_LINE(payload.ZIP_FILE_NAME);
	DBMS_OUTPUT.PUT_LINE(payload.CREATED);
END;





